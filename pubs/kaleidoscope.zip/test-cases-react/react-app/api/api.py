from flask import Flask, render_template, request, json, make_response
# from app import app
import pandas as pd
import numpy as np
import os
import tensorflow_hub as hub
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans
from scipy.stats import ttest_ind, ttest_rel, wilcoxon
import fasttext  
import re
import random
import string
from urllib.parse import unquote
import nlpaug.augmenter.char as nac
import nlpaug.augmenter.word as naw
import nlpaug.augmenter.sentence as nas
import nlpaug.flow as nafc
import string
from collections import Counter
from detoxify import Detoxify
import tweetnlp
import math 

app = Flask(__name__, static_folder='../build', static_url_path='/')


EMBEDDING_FPATH = os.environ['EMBEDDING_FPATH']
embed = hub.load(EMBEDDING_FPATH + "universal-sentence-encoder_4/") # change path here
stopwords = {'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 
'she\'s', 'her', 'hers', 'herself', 'it', 'it\'s', 'its', 'itself', 'they', 'them', 
'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 
'that', 'that\'ll', 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be',
'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing',
'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until',
'while', 'of', 'at', 'i', 'i\'m', 'i\'ll', 'i\'d', 'my', 'me', 'so', 'to', 'such', 'in',
'you','for','on','with','like','not','just','all','don\'t','about','can','get','people','would',
'one','from','you','edit:','out','up','when','more','&nbsp;','think','know','there','by',
'some','how','we','will','no','|','only','than','it.','even','really','then','see','got',
'you\'re', 'that\'s', 'make', ''}

# task = 'reddit'
# DATA_FPATH = 'data/%s/' % task
# MODEL_FPATH = 'models/%s/' % task

# if task == 'reddit':
#     subreddit = "funny"
#     embeddings = np.load(DATA_FPATH + subreddit + '/embs.npy')
#     models = {s: fasttext.load_model(MODEL_FPATH + "%s_model.bin" % s) for s in ["funny"]}
#     projection_df = pd.read_csv(DATA_FPATH + subreddit + '/projection_df')

# elif task == 'sentiment':
#     embeddings = np.load(DATA_FPATH + '/embs.npy')
#     models = {s: fasttext.load_model(MODEL_FPATH + "%s_model.bin" % s) for s in ["amazon"]}
#     projection_df = pd.read_csv(DATA_FPATH + '/projection_df')

# comments = np.array(projection_df['comment'])
# labels = np.array(projection_df['label']).astype(int)
# preds = np.array(projection_df['pred']).astype(float)
# comment_ids = np.array(projection_df['comment_id']).astype(int)


# @app.route('/')
# @app.route('/index')
# def index():
#     print("reading example set cookies in index", json.loads(request.cookies.get('exampleSets')))
#     if request.cookies.get('transformationFunctions'):
#         transformation_funcs_temp = json.loads(request.cookies.get('transformationFunctions'))
#     if request.cookies.get('/exampleSets'):
#         example_sets = json.loads(request.cookies.get('exampleSets'))
#     return render_template('index.html', example_sets=example_sets)

@app.route('/getProjectionDf', methods=['GET'])
def getProjectionDf():
    print(request.args.get('task'))
    global task
    task = request.args.get('task')
    data = request.args.get('data')
    projection_df = loadDataForTask(task, data)

    lower_bound_quantile = 0.0
    upper_bound_quantile = 1.0
    umap_bounds = [[projection_df.umap_x.quantile(lower_bound_quantile), projection_df.umap_x.quantile(upper_bound_quantile)],
                   [projection_df.umap_y.quantile(lower_bound_quantile), projection_df.umap_y.quantile(upper_bound_quantile)]]
    tsne_bounds = [[projection_df.tsne_x.quantile(lower_bound_quantile), projection_df.tsne_x.quantile(upper_bound_quantile)],
                   [projection_df.tsne_y.quantile(lower_bound_quantile), projection_df.tsne_y.quantile(upper_bound_quantile)]]
    pca_bounds = [[projection_df.pca_x.quantile(lower_bound_quantile), projection_df.pca_x.quantile(upper_bound_quantile)],
                   [projection_df.pca_y.quantile(lower_bound_quantile), projection_df.pca_y.quantile(upper_bound_quantile)]]
    bounds = {'umap': umap_bounds, 'tsne': tsne_bounds, 'pca': pca_bounds}
    return json.jsonify(data_json=projection_df.to_json(orient='records'), bounds=bounds)

def loadDataForTask(task, data):
    DATA_FPATH = 'data/%s/' % task
    MODEL_FPATH = 'models/%s/' % task

    global comments, labels, comment_ids, embeddings, projection_df, models, detoxify_preds, tweetnlp_preds
    if task == 'moderation':
        subreddit = data
        embeddings = np.load(DATA_FPATH + subreddit + '/embs.npy')
        model_1 = Detoxify('original')
        model_2 = tweetnlp.load('offensive')
        models = {'model1': model_1, 'model2': model_2}
        projection_df = pd.read_csv(DATA_FPATH + subreddit + '/projection_df')

    elif task == 'sentiment':
        embeddings = np.load(DATA_FPATH + '/embs.npy')
        models = {s: fasttext.load_model(MODEL_FPATH + "%s_model.bin" % s) for s in ["amazon"]}
        projection_df = pd.read_csv(DATA_FPATH + '/projection_df')

    comments = np.array(projection_df['comment'])
    labels = np.array(projection_df['label']).astype(int)
    comment_ids = np.array(projection_df['comment_id']).astype(int)
    detoxify_preds = np.array(projection_df['detoxify_preds']).astype(int)
    tweetnlp_preds = np.array(projection_df['tweetnlp_preds']).astype(int)

    print(projection_df.head())

    return projection_df


@app.route('/getExample', methods=['GET'])
def getExample():
    idx = json.loads(request.args.get('idx'))
    return json.jsonify(example=comments[idx])

@app.route('/addExample', methods=['POST'])
def addExample():
    return "added"

    # print(request)
    # exampleId = int(json.loads(request.form.get('exampleId')))
    # exampleString = json.loads(request.form.get('exampleString'))

    # exampleVec = np.array(embed([exampleString]))
    # examplePred = float(getModelPredsHelper([exampleString])[0])

    # global comments, labels, preds, comment_ids, embeddings
    # comments = np.concatenate((comments, [exampleString]))
    # labels = np.concatenate((labels, [2]))
    # preds = np.concatenate((preds, [examplePred]))
    # comment_ids = np.concatenate((comment_ids, [exampleId]))
    # embeddings = np.concatenate((embeddings, exampleVec))
    # print('post complete', comments.shape, embeddings.shape)
    # return "successfully added example"

@app.route('/clusterExamples', methods=['POST'])
def clusterExamples():
    allExampleIds = np.array(json.loads(request.form['allExampleIds']))
    allExampleStrings = np.array(json.loads(request.form['allExampleStrings']))
    # allExampleStrings = np.array(json.loads(request.args.get('allExampleStrings')))
    existingEmbeddings = embeddings[allExampleIds[allExampleIds <= comment_ids.max()]]
    allEmbeddings = existingEmbeddings

    # newStrings = allExampleStrings[allExampleIds > comment_ids.max()]
    # if len(newStrings) > 0: 
    #     newEmbeddings = embed(allExampleStrings[allExampleIds > comment_ids.max()])
    #     allEmbeddings = np.concatenate((existingEmbeddings, newEmbeddings))
    # else: 
    #     allEmbeddings = existingEmbeddings

    kmeans = KMeans(n_clusters=3, random_state=0).fit(allEmbeddings)

    sortedIdx = []
    for c in range(3):
        clusterIdx = np.where(kmeans.labels_ == c)[0]
        clusterEmbeddings = allEmbeddings[clusterIdx]
        distance_to_center = cdist(
            [kmeans.cluster_centers_[c]], clusterEmbeddings)[0]
        sortedClusterIdx = clusterIdx[np.argsort(distance_to_center)]
        sortedIdx.extend(sortedClusterIdx)

    clusters = kmeans.labels_[sortedIdx]
    examples = allExampleStrings[sortedIdx]

    print(clusters, examples)

    clusterTopWords = getTopWordsForClusters(examples, clusters)

    clusters = [int(c) for c in clusters]
    
    matched_ids = [int(i) for i in np.array(allExampleIds)[sortedIdx]]

    return json.jsonify(matchedIds=matched_ids, clusters=clusters, clusterTopWords=clusterTopWords)



@app.route('/getSimilarExamples', methods=['POST'])
def getSimilarExamples():
    allExampleIds = np.array(json.loads(request.form['allExampleIds']))
    allExampleStrings = np.array(json.loads(request.form['allExampleStrings']))
    model = models[request.form['model']]

    print(allExampleIds, allExampleStrings)
    print(allExampleIds[allExampleIds <= comment_ids.max()])
    print(allExampleStrings[allExampleIds > comment_ids.max()])

    existingEmbeddings = embeddings[allExampleIds[allExampleIds <= comment_ids.max()]]

    print(existingEmbeddings)

    newStrings = allExampleStrings[allExampleIds > comment_ids.max()]
    if len(newStrings) > 0: 
        newEmbeddings = embed(allExampleStrings[allExampleIds > comment_ids.max()])
        allEmbeddings = np.concatenate((existingEmbeddings, newEmbeddings))
    else: 
        allEmbeddings = existingEmbeddings

    embeddingMean = np.mean(allEmbeddings, axis=0)
    filters = request.args.get('filters')
    if filters is not None:
        filters = json.loads(filters)
        queryString = json.loads(filters['queryString'])
        similarExamples, labels, clusters, clusterTopWords = getKNNFromVector(embeddingMean, allExampleIds, model, queryString)
    else:
        similarExamples, labels, clusters, clusterTopWords = getKNNFromVector(embeddingMean, allExampleIds, model)
    
    print(similarExamples)
    return json.jsonify(similarExampleIds=similarExamples, labels=labels, clusters=clusters, clusterTopWords=clusterTopWords)

@app.route('/getAllExamples', methods=['POST'])
def getAllExamples():
    print("in getAllExamples")
    print(projection_df.head())

    model = models[request.form['model']]
    filters = json.loads(request.form['filters'])
    queryString = json.loads(filters['queryString'])


    stringQueryIdx = [True if re.match(r'.*\b%s\b.*' % queryString, c, re.IGNORECASE) else False for c in comments]
    filteredIdx = np.where(stringQueryIdx)
    filteredEmbeddings = embeddings[filteredIdx]

    if len(filteredEmbeddings) == 0:
      return json.jsonify(matchedExamples=[], matchedIds=[], modelPreds=[], labels=[], clusters=[])

    kmeans = KMeans(n_clusters=3, random_state=0).fit(filteredEmbeddings)

    sortedIdx = []
    for c in range(3):
        clusterIdx = np.where(kmeans.labels_ == c)[0]
        clusterEmbeddings = filteredEmbeddings[clusterIdx]
        distance_to_center = cdist(
            [kmeans.cluster_centers_[c]], clusterEmbeddings)[0]
        sortedClusterIdx = clusterIdx[np.argsort(distance_to_center)]
        sortedIdx.extend(sortedClusterIdx)

    clusters = kmeans.labels_[sortedIdx]
    matched_comments = np.array(comments)[filteredIdx][sortedIdx]

    clusterTopWords = getTopWordsForClusters(matched_comments, clusters)

    clusters = [int(c) for c in clusters]
    matched_comments = [c for c in matched_comments]
    
    matched_labels = np.array(labels)[filteredIdx][sortedIdx]
    matched_labels = [int(l) for l in matched_labels]

    sorted_idx = [int(idx) for idx in sortedIdx]

    matched_ids = [int(i) for i in np.array(comment_ids)[filteredIdx][sortedIdx]]

    return json.jsonify(matchedExamples=matched_comments, matchedIds=matched_ids, labels=matched_labels, clusters=clusters, clusterTopWords=clusterTopWords)


@app.route('/getModelPreds', methods=['GET'])
def getModelPreds():
    # print(request.cookies.get('exampleSets'))
    allExamples = json.loads(request.args.get('allExamples'))
    probs = getModelPredsHelper(allExamples, model, None, True)
    return json.jsonify(predProbs=probs)

def getModelPredsHelper(allExamples, model, example_ids=None, return_string=False):
    if type(model) == fasttext.FastText._FastText: 
        exampleList = [x.replace('\n', ' ') for x in allExamples]
        preds = model.predict(exampleList)
        if task == 'moderation':
            preds_int = np.array([1 if 'positive' in p[0] else 0 for p in preds[0]])
        else: 
            preds_int = np.array([1 if '2' in p[0] else 0 for p in preds[0]])

        preds_prob = np.array([p[0] for p in preds[1]])
        probs = np.array([1 - p if preds_int[i] == 0 else p for (i,p) in enumerate(preds_prob)])

    elif type(model) == Detoxify:
        if example_ids == None: 
            probs = model.predict(allExamples)['toxicity']
        else: 
            probs = np.zeros(len(allExamples))
            example_ids = np.array(example_ids)
            max_id = projection_df.comment_id.max()
            existing_examples_idx = np.where(example_ids <= max_id)
            existing_examples_probs = np.array(projection_df[projection_df.comment_id.isin(example_ids[existing_examples_idx])]['detoxify_preds'])
            probs[existing_examples_idx] = existing_examples_probs

            new_examples_idx = np.where(example_ids > max_id)[0]
            print("NEW EXAMPLES IDX:", new_examples_idx)
            if new_examples_idx.size != 0:  
                new_examples = [ allExamples[i] for i in new_examples_idx] 
                new_examples_probs = model.predict(new_examples)['toxicity']
                probs[new_examples_idx] = new_examples_probs

    elif type(model) == tweetnlp.model_text_classification.model.Offensive:
        if example_ids == None: 
            probs_dict = model.predict(allExamples)
            probs = [p['probability'] if p['label']=='offensive' else 1 - p['probability'] for p in probs_dict]
        else: 
            probs = np.zeros(len(allExamples))
            example_ids = np.array(example_ids)
            max_id = projection_df.comment_id.max()
            existing_examples_idx = np.where(example_ids <= max_id)
            existing_examples_probs = np.array(projection_df[projection_df.comment_id.isin(example_ids[existing_examples_idx])]['tweetnlp_preds'])
            probs[existing_examples_idx] = existing_examples_probs

            new_examples_idx = np.where(example_ids > max_id)[0]
            print("NEW EXAMPLES IDX:", new_examples_idx)
            if new_examples_idx.size != 0:  
                new_examples = [ allExamples[i] for i in new_examples_idx] 
                new_examples_probs_dict = model.predict(new_examples)
                new_examples_probs = [p['probability'] if p['label']=='offensive' else 1 - p['probability'] for p in new_examples_probs_dict]
                probs[new_examples_idx] = new_examples_probs

    if return_string: 
        return [str(np.round(p,3)) for p in probs]
    else: 
        return np.round(probs,3)

def batchPredict(allExamples, model, example_ids=None, return_string=False):
    all_probs = []
    batch_size = 50
    for batch_idx in range(math.ceil(len(allExamples)/batch_size)):
        if batch_idx % 10 == 0: print(batch_idx)
        batch_comments = allExamples[batch_idx*batch_size : min(len(allExamples), (batch_idx+1)*batch_size)]
        if example_ids: 
            batch_example_ids = example_ids[batch_idx*batch_size : min(len(allExamples), (batch_idx+1)*batch_size)]
        else: 
            batch_example_ids = None
        batch_probs = getModelPredsHelper(batch_comments, model, batch_example_ids, return_string)
        all_probs.extend(batch_probs)
    return np.array(all_probs)


def getTopWordsForClusters(examples, clusters):
    clusterTopWords = dict()
    for c in np.unique(clusters):
        cluster_examples = examples[np.where(clusters==c)]
        topWords = getTopWords(list(cluster_examples), helperRequest=True)
        clusterTopWords[int(c)] = topWords
    return clusterTopWords


@app.route('/getTopWords', methods=['POST'])
def getTopWords(inputExamples=None, helperRequest=False):
    modified_punc = '!"#$%&()*+,./:;<=>?@[\\]^_`{|}~'
    r = re.compile(r'[\s{}]+'.format(re.escape(modified_punc)))
    if helperRequest: 
        examples = inputExamples
    else: 
        examples = list(json.loads(request.form['allExamples']))
    split = r.split(" ".join(examples))
    filtered = [word.lower() for word in split if word.lower() not in stopwords]

    counter = Counter(filtered)
    most_occur = counter.most_common(10)
    most_occur_dict = [{"word": word, "count": count} for (word,count) in most_occur]
    print("in get top words", most_occur_dict)
    if helperRequest:
        return most_occur_dict
    else: 
        return json.jsonify(topWords=most_occur_dict)

@app.route('/transformationFunction', methods=['POST', 'DELETE'])
def transformationFunction():
    if request.method == 'POST':
        transformation_func_name = request.form.get("name")
        transformation_funcs_data = json.loads(request.form.get("funcs"))
        transformation_funcs[transformation_func_name] = transformation_funcs_data
    if request.method == 'DELETE':
        del transformation_funcs[request.form.get("name")]
    res = make_response("Transformation functions updated")
    res.set_cookie("transformationFunctions", value=json.dumps(transformation_funcs), max_age=None)
    return res

def getKNNFromVector(vec, allExampleIds, model, queryString="", n=50):
    print(queryString)
    
    nonDuplicateIdx = [i not in allExampleIds for i in comment_ids]
    print('here, non dup idx')
    print(np.where(np.array(nonDuplicateIdx)==False))
    print(np.array(comments)[np.where(np.array(nonDuplicateIdx)==False)])

    stringQueryIdx = [True if re.match(r'.*\b%s\b.*' % queryString, c, re.IGNORECASE) else False for c in comments]


    filteredIdx = np.where(np.array(stringQueryIdx) & np.array(nonDuplicateIdx))

    # print(stringQueryIdx)

    filteredEmbeddings = embeddings[filteredIdx]

    dist_vec = cdist([vec], filteredEmbeddings, 'cosine')
    top_vec_idx = np.argsort(dist_vec[0])[1:n+1]
    print(top_vec_idx)
    
    top_vecs = filteredEmbeddings[top_vec_idx]
    kmeans = KMeans(n_clusters=3, random_state=0).fit(top_vecs)
    clusters = [int(c) for c in kmeans.labels_]

    top_comment_ids = [int(i) for i in filteredIdx[0][np.array(top_vec_idx).astype(int)]]
    print("***** here", top_comment_ids)

    top_comments = np.array(comments)[filteredIdx][top_vec_idx]
    clusterTopWords = getTopWordsForClusters(top_comments, kmeans.labels_)

    top_comments = [c for c in top_comments]
    
    top_labels = np.array(labels)[filteredIdx][top_vec_idx]
    top_labels = [int(l) for l in top_labels]


    return top_comment_ids, top_labels, clusters, clusterTopWords

@app.route('/runTest', methods=['POST'])
def run_test():
    # print("example sets from cookies: " , json.loads(unquote(request.cookies.get('exampleSets'))))
    # all_example_sets = json.loads(unquote(request.cookies.get('exampleSets')))
    print(request.form)

    test_info = json.loads(request.form['test_info'])
    print("test_info = ", test_info)

    selected_model = request.form["model"]
    print("model = ", selected_model)

    # test_info = json.loads(request.args.get('test_info'))
    example_set_names = test_info['example_set_names']
    example_sets = test_info['example_sets']
    example_set_ids = test_info['example_set_ids']
    print(example_set_names, example_sets, example_set_ids)
    # example_sets = list(map(lambda x: list(filter(lambda y: y['name'] == x, all_example_sets))[0]['sentences'], example_set_names))

    if test_info['direction']:
        direction = 'increase' if 'Higher' in test_info['direction'] else 'decrease'
    else: 
        direction = None

    transformed_examples = None
    transformed_idx = None
    transformation_applied = True
    mean_diff = None
    pval = None

    print("running test", test_info)

    if test_info['granularity'] == 'instance-level':
        res, preds, transformed_examples, transformed_idx, mean_diff, pval = paired_test(
                    example_set_1=example_sets[0],
                    # transformation_function_names=test_info['transformation_function_names'],
                    transformation_functions=test_info['transformation_functions'],
                    model=models[selected_model],
                    test_type=test_info['test_type'],
                    direction=direction,
                    example_set_names=test_info['example_set_names'],
                    example_ids=example_set_ids)
        if len(transformed_examples) == 0: transformation_applied = False
    elif test_info['granularity'] == 'concept-level': 
        res, preds, mean_diff, pval = distributional_test(example_sets=example_sets,
                            model=models[selected_model],
                            test_type=test_info['test_type'],
                            direction=direction,
                            example_set_names=test_info['example_set_names'],
                            example_ids=example_set_ids)
    else:
        res, preds = output_test(example_sets=example_sets,
                          model=models[selected_model],
                          desired_output=test_info['desired_output'],
                          example_set_names=test_info['example_set_names'],
                          example_ids=example_set_ids)

    transformed_examples_to_return = [t.tolist() for t in transformed_examples] if transformed_examples else []
    res_short = "pass" if "PASS" in res else "fail"

    return json.jsonify(res_short=res_short, res_string=res, preds=preds, transformed_examples=transformed_examples_to_return, transformed_idx=transformed_idx, transformation_applied=transformation_applied, mean_diff=mean_diff, pval=pval)

def output_test(example_sets, model, desired_output="Moderated (1)", example_set_names=['set 1'], example_ids=None):
    preds_1 = batchPredict(example_sets[0], model, example_ids=example_ids[0], return_string=False)
    rounded_preds = np.round(preds_1)
    desired_output_int = 1 if "(1)" in desired_output else 0
    percent_correct = len(np.where(rounded_preds == desired_output_int)[0]) / float(len(preds_1)) * 100
    print(percent_correct, example_set_names[0], desired_output)
    return "%.1f%% of predictions in %s have the prediction %s." % (percent_correct, example_set_names[0], desired_output), preds_1.tolist()


def distributional_test(example_sets, model, test_type='invariance', direction='increase', epsilon=0.05, example_set_names=['set 1', 'set 2', 'set 3'], example_ids=None):
    preds_1 = batchPredict(example_sets[0], model, example_ids=example_ids[0], return_string=False)
    preds_2 = batchPredict(example_sets[1], model, example_ids=example_ids[1], return_string=False)
    ttest_result = ttest_ind(preds_1, preds_2)
    mean_diff = np.mean(preds_2) - np.mean(preds_1)

    preds_list = [preds_1.tolist(), preds_2.tolist()]

    if test_type == 'invariance':
        if ttest_result.pvalue >= 0.05 or abs(mean_diff) <= epsilon: 
            result_string = "✓ PASS : Predictions are not significantly different."
        else: 
            result_string = "✗ FAIL: Predictions for %s and %s are significantly different (pval = %.3f)" % (example_set_names[0], example_set_names[1], ttest_result.pvalue)

    elif test_type == 'directionality':
        if ttest_result.pvalue >= 0.05 or abs(mean_diff) <= epsilon: 
            result_string = "✗ FAIL : Predictions are not significantly different."
        else: 
            diff = "increase" if mean_diff > 0 else "decrease"
            operator = "higher" if diff == "decrease" else "lower"
            result = "✓ PASS" if diff == direction else "✗ FAIL"
            result_string = "%s: P(moderated) for %s is *%s* than for %s (pval = %.3f)" % (result, example_set_names[0], operator, example_set_names[1], ttest_result.pvalue)

    # elif test_type == 'relative similarity':
    #     preds_3 = getModelPredsHelper(example_sets[2], model, return_string=False)
    #     preds_list.append(preds_3.tolist())
    #     diff_1_2 = np.array([[abs(x - y) for x in preds_1] for y in preds_2]).flatten()
    #     diff_1_3 = np.array([[abs(x - y) for x in preds_1] for y in preds_3]).flatten()
    #     ttest_result = ttest_ind(diff_1_2, diff_1_3)
        
    #     if ttest_result.pvalue >= 0.05 or abs(ttest_result.statistic) <= epsilon: 
    #         result_string = """✗ FAIL : Prediction similarity between %s and %s is not significantly different than 
    #               between %s and %s.""" % (example_set_names[0], example_set_names[1], example_set_names[0], example_set_names[2])
    #     elif ttest_result.statistic < 0: 
    #         result_string = "✓ PASS: predictions for %s are *more* similar to %s than %s." % (example_set_names[0], example_set_names[1], example_set_names[2])
    #     elif ttest_result.statistic > 0: 
    #         result_string = "✗ FAIL : predictions for %s are *less* similar to %s than %s." % (example_set_names[0], example_set_names[1], example_set_names[2])    
        
    print(result_string)
    mean_diff = np.mean(preds_2) - np.mean(preds_1)
    pval = ttest_result.pvalue
    return result_string, preds_list, mean_diff, pval

def paired_test(example_set_1, transformation_functions, model, test_type='invariance', direction='increase', epsilon=0.05, transformation_function_names=["transformation 1", "transformation 2"], example_set_names=['set 1'], example_ids=None):
    transformation_function_list = build_transformation_funcs(transformation_functions[0])
    example_set_2 = [x for x in example_set_1]
    for func in transformation_function_list: 
        example_set_2 = func(example_set_2)

    transformed_idx = [i for i in range(len(example_set_1)) if example_set_1[i] != example_set_2[i]]
    if (len(transformed_idx) == 0):
        result_string = "✓ PASS : The transformation function did not apply any changes so predictions did not change."
        return result_string, [], [], 0, 0

    example_set_1_filtered = np.array(example_set_1)[transformed_idx]
    example_set_2_filtered = np.array(example_set_2)[transformed_idx]
    example_set_1_ids = np.array(example_ids[0])[transformed_idx]

    transformed_example_sets = [example_set_1_filtered, example_set_2_filtered]

    preds_1 = batchPredict(list(example_set_1_filtered), model, example_ids=list(example_set_1_ids), return_string=False)
    preds_2 = batchPredict(list(example_set_2_filtered), model, example_ids=None, return_string=False)
    preds_list = [preds_1.tolist(), preds_2.tolist()]
    
    # if np.all(((np.array(preds_1) >= 0.5).astype(int) - (np.array(preds_2) >= 0.5).astype(int)) == 0):
    #     result_string = "✓ PASS : Predictions are not significantly different after applying the transformation to %s." % (example_set_names[0])

    # else: 
    # ttest_result = wilcoxon(
    #     (np.array(preds_1) >= 0.5).astype(int), 
    #     (np.array(preds_2) >= 0.5).astype(int)
    # )

    ttest_result = wilcoxon(preds_1, preds_2)
    mean_diff = np.mean(preds_2 - preds_1)
    print("in paired ttest", ttest_result)

    if test_type == 'invariance':
        if np.array_equal(preds_1, preds_2):
            result_string = "✓ PASS : The transformation function did not apply any changes so predictions did not change."
        elif ttest_result.pvalue >= 0.05 or abs(mean_diff) <= epsilon: 
            result_string = "✓ PASS : Predictions are not significantly different after applying the transformation to %s." % (example_set_names[0])
        else: 
            result_string  = "✗ FAIL: Predictions are significantly different after applying the transformation to %s (pval = %.3f)" % (example_set_names[0], ttest_result.pvalue)
    
    elif test_type == 'directionality':
        if np.array_equal(preds_1, preds_2): 
            result_string = "✗ FAIL : The transformation function did not apply any changes so predictions did not change."
        elif ttest_result.pvalue >= 0.05 or abs(mean_diff) <= epsilon: 
            result_string = "✗ FAIL : Predictions are not significantly different."
        else: 
            diff = "increase" if mean_diff > 0 else "decrease"
            result = "✓ PASS" if diff == direction else "✗ FAIL"
            result_string = "%s: Predictions %s after applying the transformation to %s (pval = %.3f)" % (result, diff, example_set_names[0], ttest_result.pvalue)
    
    # elif test_type == 'relative similarity':
    #     transformation_function_list_2 = build_transformation_funcs(transformation_functions[1])
    #     example_set_3 = [x for x in example_set_1]
    #     for func in transformation_function_list_2: 
    #         example_set_3 = func(example_set_3)

    #     transformed_idx_2 = [i for i in range(len(example_set_1)) if (example_set_1[i] != example_set_3[i]) and (example_set_1[i] != example_set_2[i])]
    #     if (len(transformed_idx_2) == 0):
    #         result_string = "✗ FAIL : The transformation functions did not apply changes to any of the same examples so predictions did not change."
    #         return result_string, [], []

    #     example_set_1_filtered = np.array(example_set_1)[transformed_idx_2]
    #     example_set_2_filtered = np.array(example_set_2)[transformed_idx_2]
    #     example_set_3_filtered = np.array(example_set_3)[transformed_idx_2]

    #     transformed_example_sets = [example_set_1_filtered, example_set_2_filtered, example_set_3_filtered]

    #     preds_3 = getModelPredsHelper(example_set_3_filtered, model, return_string=False)
    #     preds_list.append(preds_3.tolist())
    #     preds_1, preds_2, preds_3 = [np.array(p) for p in [preds_1, preds_2, preds_3]]
    #     diff_1_2 = abs(preds_1 - preds_2)
    #     diff_1_3 = abs(preds_1 - preds_3)
    #     ttest_result = wilcoxon(diff_1_2, diff_1_3)

    #     if np.array_equal(preds_1, preds_2) and np.array_equal(preds_2, preds_3):
    #         result_string = "✗ FAIL : Neither transformation function applied any changes so predictions did not change."
    #     elif np.array_equal(preds_1, preds_2):
    #         result_string = "✓ PASS : %s did not apply any changes to %s while %s did." % (transformation_function_names[0], example_set_names[0], transformation_function_names[1])
    #     elif np.array_equal(preds_1, preds_3):
    #         result_string = "✗ FAIL : %s did not apply any changes to %s while %s did." % (transformation_function_names[1], example_set_names[0], transformation_function_names[0])

    #     elif ttest_result.pvalue >= 0.05 or abs(ttest_result.statistic) <= epsilon: 
    #         result_string = """✗ FAIL : Prediction similarity is not significantly different after 
    #               %s vs %s applied to %s.""" % (transformation_function_names[0], transformation_function_names[1], example_set_names[0])
    #     elif ttest_result.statistic < 0: 
    #         result_string = "✓ PASS: predictions are *more* similar after applying %s vs %s to %s." % (transformation_function_names[0], transformation_function_names[1], example_set_names[0])
    #     elif ttest_result.statistic > 0: 
    #         result_string = "✗ FAIL : predictions are *less* similar after applying %s vs %s to %s." % (transformation_function_names[0], transformation_function_names[1], example_set_names[0])       

    print(result_string)
    pval = ttest_result.pvalue
    return result_string, preds_list, transformed_example_sets, transformed_idx, mean_diff, pval

# BEGIN TRANSFORMATION FUNCTIONS HERE

def parse_transformation_func(input_list, transformations=[]):
    for transformation in transformations:
        output_list = transformation(input_list)
    return output_list

def build_transformation_funcs(transformation_funcs_data):
    # transformation_funcs = json.loads(unquote(request.cookies.get('transformationFunctions')))
    lambdas = []
    for transformation_func in transformation_funcs_data:
        params = [transformation_func["param1"], transformation_func["param2"]]
        params = list(filter(None, params))
        lambdas.append(build_transformation_func(transformation_func["functionType"].lower(), params))
    return lambdas

def build_transformation_func(transformation_type, params=[]):
    if transformation_type == 'replace':
        return lambda l: replace(l, params[0], params[1])
    if transformation_type == 'add':
        return lambda l: add(l, params[0])
    if transformation_type == 'ocr_typo':
        return lambda l: ocr_typo(l)
    if transformation_type == 'typo':
        return lambda l: keyboard_typo(l)
    if transformation_type == 'insert_typo':
        return lambda l: insert_typo(l)
    if transformation_type == 'swap_typo':
        return lambda l: swap_typo(l)
    if transformation_type == 'substitute_typo':
        return lambda l: substitute_typo(l)
    if transformation_type == 'delete_typo':
        return lambda l: delete_typo(l)
    if transformation_type == 'delete':
        return lambda l: delete(l, params[0])
    if transformation_type == 'synonym':
        return lambda l: synonym(l)
    if transformation_type == 'antonym':
        return lambda l: antonym(l)

# helper to replace words in input
def replace_word(input_list, string_to_replace="", string_to_replace_with=""):
    return [re.sub(string_to_replace, string_to_replace_with, string, flags=re.IGNORECASE) for string in input_list]

# can be used to replace words in input
def replace(input_list, strings_to_replace=None, strings_to_replace_with=None, one_to_one_replace=False):
    if strings_to_replace is None:
        strings_to_replace = []
    if strings_to_replace_with is None:
        strings_to_replace_with = []
    if len(strings_to_replace) != len(strings_to_replace_with) and one_to_one_replace:
        raise RuntimeError("strings_to_replace and strings_to_replace_with must be the same length when one-to-one replacing")
    returned = []
    for string in input_list:
        modified_string = string
        for i in range(len(strings_to_replace)):
            string_to_replace = strings_to_replace[i]
            if one_to_one_replace:
                modified_string = replace_word([modified_string], string_to_replace, strings_to_replace_with[i])[0]
            else:
                modified_string = replace_word([modified_string], string_to_replace, random.choice(strings_to_replace_with))[0]
        returned.append(modified_string)
    return returned

# helper to add words in input
def add_word(input_list, string_to_add=""):
    if string_to_add == "":
        for _ in range(random.randint(20)):
            string_to_add += random.choice(string.ascii_letters + string.digits + string.punctuation)
    return [string + " " + string_to_add for string in input_list]

# can be used to add positive/negative sentiment to input, default adds random
def add(input_list, strings_to_add=None):
    if strings_to_add is None:
        aug = naw.ContextualWordEmbsAug(model_path='bert-base-uncased', model_type='bert', aug_max=1, action="insert")
        return aug.augment(input_list)
    returned = []
    for string in input_list:
        returned.extend(add_word([string], random.choice(strings_to_add)))
    return returned

# helper to remove words in input
def delete_word(input_list, string_to_delete=""):
    return ["".join(re.split(string_to_delete, string, flags=re.IGNORECASE)) for string in input_list]

# can be used to remove strings in input
def delete(input_list, strings_to_delete=None):
    if strings_to_delete is None:
        aug = naw.RandomWordAug(aug_max=1)
        return aug.augment(input_list)
    for string_to_delete in strings_to_delete:
        input_list = delete_word(input_list, string_to_delete.lower())
    return input_list

# typos by keyboard proximity
def keyboard_typo(input_list):
    aug = nac.KeyboardAug(include_special_char=False, include_numeric=False, include_upper_case=False, aug_char_max=1, aug_word_max=1)
    return aug.augment(input_list)

# typos by visual recognition
def ocr_typo(input_list):
    aug = nac.OcrAug(aug_char_max=1, aug_word_max=1)
    return aug.augment(input_list)

# typo caused by inserting a random character
def insert_typo(input_list):
    aug = nac.RandomCharAug(action="insert", include_numeric=False, include_upper_case=False, aug_char_max=1, aug_word_max=1, spec_char="")
    return aug.augment(input_list)

# typo caused by substituting a random character
def substitute_typo(input_list):
    aug = nac.RandomCharAug(action="substitute", include_numeric=False, include_upper_case=False, aug_char_max=1, aug_word_max=1, spec_char="")
    return aug.augment(input_list)

# typo caused by swapping two random adjacent characters
def swap_typo(input_list):
    aug = nac.RandomCharAug(action="swap", include_numeric=False, include_upper_case=False, aug_char_max=1, aug_word_max=1, spec_char="")
    return aug.augment(input_list)

# typo caused by deleting a random character
def delete_typo(input_list):
    aug = nac.RandomCharAug(action="delete", include_numeric=False, include_upper_case=False, aug_char_max=1, aug_word_max=1, spec_char="")
    return aug.augment(input_list)
    
def synonym(input_list):
    aug = naw.SynonymAug(aug_src='wordnet', aug_min=1, aug_max=1)
    augmented_list = aug.augment(input_list)
    cleaned_list = [x.replace(" ' ", "'") for x in augmented_list]
    return cleaned_list

def antonym(input_list):
    aug = naw.AntonymAug(aug_min=1, aug_max=1)
    augmented_list = aug.augment(input_list)
    cleaned_list = [x.replace(" ' ", "'") for x in augmented_list]
    return cleaned_list