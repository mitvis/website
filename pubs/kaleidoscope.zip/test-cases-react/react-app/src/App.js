import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import {
  TestingLayout,
  SelectTask,
  SelectModerationModel,
  SelectSentimentModel
} from './components/layout/TestingLayout.js';

import './App.css';

function App() {
  const dataOptions = ['news', 'gaming', 'movies', 'askreddit',
                   'funny', 'tifu', 'getmotivated', 'technology',
                   'futurology']
  let routes = []
  for (let i = 0; i < dataOptions.length; i++) {
    let path = "/moderation/" + dataOptions[i] 
    routes.push(
      <Route path={path} element={<TestingLayout selectedTask='moderation' selectedModel={'model1'} selectedData={dataOptions[i]}/>} />
    )
  }

  return (
    <BrowserRouter>
      <Routes>

        <Route path="/" element={<TestingLayout selectedTask='moderation' selectedModel='model1' selectedData = 'funny'/>} />
        <Route path="/sentiment/amazon" element={<TestingLayout selectedTask='sentiment' selectedModel='amazon'/>} />
        {routes}

      </Routes>
    </BrowserRouter>
  );
}

export default App;
