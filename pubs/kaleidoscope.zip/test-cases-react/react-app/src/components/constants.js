export const selectAnOption = "Select an option";

export const output = "Output";
export const invariance = "Invariance";
export const directionality = "Directionality";
export const relativeSimilarity = "Relative Similarity";
export const testTypes = [output, invariance, directionality];

export const singular = "Singular";
export const distributional = "Concept-level";
export const paired = "Instance-level";

export const replace = "Replace";
export const add = "Add";
export const delete_ = "Delete";
export const synonym = "Synonym";
export const antonym = "Antonym";
export const hypernym = "Hypernym";
export const hyponym = "Hyponym";

export const pcutoff = 0.05;
export const epsilon = 0.02;

export const colors = ['#ef8a62','#67a9cf'];
export const colorsRGB = [[239,138,98], [103,169,207]];

export const transformationFuncsNoParam = new Set([synonym, antonym]);
export const transformationFuncsOneParam = new Set([replace, add, delete_]);
export const transformationFuncsTwoParam = new Set([replace]);

export const divergingColorScale = ['#8e0152','#c51b7d','#de77ae','#7fbc41','#4d9221'];
export const sequentialColorScale = ['#8c96c6','#8c6bb1','#88419d','#810f7c','#4d004b'];
