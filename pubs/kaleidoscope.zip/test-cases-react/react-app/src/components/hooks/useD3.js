import React from 'react';
import * as d3 from 'd3';

// export const useD3 = (renderChartFn, dependencies) => {
//     const ref = React.createRef();

//     React.useEffect(() => {
//     	let isCancelled = false;
//     	if (!isCancelled) {
//     		renderChartFn(d3.select(ref.current));
//     	}
        
//         return () => {
//         	isCancelled = true;
//         };
//       }, dependencies);

//     return ref;
// }

export const useD3 = (renderChartFn, dependencies) => {
    const ref = React.useRef();

    React.useEffect(() => {
        renderChartFn(d3.select(ref.current));
        return () => {};
      }, dependencies);
    return ref;
}