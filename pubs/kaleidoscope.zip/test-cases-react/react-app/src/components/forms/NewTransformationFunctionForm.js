import React, { Component } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { BsFillPlusCircleFill } from "react-icons/bs";
import HelpTooltip from '../layout/HelpTooltip.js';
import {
  replace,
  add,
  delete_,
  synonym,
  antonym,
  transformationFuncsOneParam,
  transformationFuncsTwoParam
} from '../constants.js';

export default class NewTransformationFunctionForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      validated: false,
      addingNewFunction: false,
      showParam1: false,
      showParam2: false,
      transformations: this.props.transformations ?? [],
      newFunctionType: null,
      newFunctionParam1: null,
      newFunctionParam2: null
    };
  }

  getParamNames(functionType) {
    if (functionType === replace) {
        return ['Word(s) to replace', 'Replace with'];
    } else if (functionType === add) {
        return ['Word(s) to add'];
    } else if (functionType === delete_) {
        return ['Word(s) to delete'];
    } else if (functionType === synonym) {
        return ["Word(s) to replace with synonym (if empty, replace random words)"]
    } else if (functionType === antonym) {
        return ["Word(s) to replace with antonym (if empty, replace random words)"]
    }
    return "";
  }

  onSubmitForm = (e) => {
    e.preventDefault();
    
    this.props.addTransformationCallback({name: this.state.transformationName, functions: this.state.transformations});

    // if (this.validateForm()) {
    //     console.log("validated");
    //     this.props.addTransformationCallback({name: this.state.transformationName, functions: this.state.transformations});
    // }
  }

  onChangeTransformationName = (e) => {
      this.setState({transformationName: e.target.value});
  }

  onChangeParamInput = (val, param1) => {
    if (param1) {
      this.setState({
        newFunctionParam1: val.split(",")
      });
    }
    else {
      this.setState({
        newFunctionParam2: val.split(",")
      });
    }
  }

  onChangeTransformation = (e, i) => {
    const newTransformations = this.state.transformations;
    const ithNewTransformation = newTransformations[i];
    ithNewTransformation.functionType = e.target.value;
    ithNewTransformation.param1 = transformationFuncsOneParam.has(e.target.value) ? [] : null;
    ithNewTransformation.param2 = transformationFuncsTwoParam.has(e.target.value) ? [] : null;
    newTransformations[i] = ithNewTransformation;
    this.setState({
      transformations: newTransformations
    });
  }

  onAddNewTransformation = (e) => {
    const newTransformations = this.state.transformations;
    newTransformations.push({
      functionType: e.target.value,
      param1: transformationFuncsOneParam.has(e.target.value) ? [] : null,
      param2: transformationFuncsTwoParam.has(e.target.value) ? [] : null,
    });
    this.setState({
      transformations: newTransformations
    });
  }

  validateForm() {
    if (!this.state.transformationName || !this.state.transformations.length) return false;
    for (let i = 0; i < this.state.transformations.length; i ++ ) {
        let transformation = this.state.transformations[i];
        if (transformation.param1 !== null && !transformation.param1.length) return false;
        if (transformation.param2 !== null && !transformation.param2.length) return false;
    }
    return true;
  }

  commitFnForm = () => {
    const newTransformationFn = {
      functionType: this.state.newFunctionType,
      param1: this.state.newFunctionParam1,
      param2: this.state.newFunctionParam2
    };
    const newTransformations = this.state.transformations;
    newTransformations.push(newTransformationFn);
    this.setState({
      addingNewFunction: false,
      transformations: newTransformations,
      showParam1: false,
      showParam2: false,
      newFunctionType: null,
      newFunctionParam1: null,
      newFunctionParam2: null
    });
    this.props.updateTransformations(newTransformations);
  }

  showNewFnForm() {
    this.setState({
      addingNewFunction: true
    });
  }
  
  addNewFunctionButton() {
    return (
      <Button variant="outline-primary" style={{marginLeft: "20px"}} onClick={() => this.showNewFnForm()}>
        <BsFillPlusCircleFill style={{"margin-right": "5px"}} />Add Function
      </Button>
    );
  }

  functionTypeDropdown = (i) => {
    return (
      <>
        <Form.Group className="mb-3" controlId={i ? "transformationFormNewTransformation" + i : "transformationFormNewTransformation"}>
          <Form.Select value={this.state.newFunctionType ?? "Function Type"} onChange={(e) => this.onShowParams(e)}>
            <option value="Function Type">Function Type</option>
            <option value="Replace">Replace</option>
            <option value="Add">Add</option>
            <option value="Delete">Delete</option>
            <option value="Typo">Typo</option>
            <option value="Synonym">Replace Synonym</option>
            <option value="Antonym">Replace Antonym</option>
          </Form.Select>
        </Form.Group>
      </>
    );
  }

  onShowParams = (e) => {
    this.setState({
      showParam1: transformationFuncsOneParam.has(e.target.value),
      showParam2: transformationFuncsTwoParam.has(e.target.value),
      newFunctionType: e.target.value,
      newFunctionParam1: transformationFuncsOneParam.has(e.target.value) ? [] : null,
      newFunctionParam2: transformationFuncsTwoParam.has(e.target.value) ? [] : null
    });
  }

  param1 = (i) => {
    return (
      <>
        <Form.Group className="mb-3" controlId={"transformationFormTransformationParam1" + i}>
          <Form.Label>{this.getParamNames(this.state.newFunctionType)[0]}: {this.state.newFunctionParam1?.toString()}</Form.Label>
          <Form.Control type="text" onChange={(e) => this.onChangeParamInput(e.target.value, true)} />
        </Form.Group>
      </>
    );
  }

  param2 = (i) => {
    return (
      <>
        <Form.Group className="mb-3" controlId={"transformationFormTransformationParam2" + i}>
          <Form.Label>{this.getParamNames(this.state.newFunctionType)[1]}: {this.state.newFunctionParam2?.toString()}</Form.Label>
          <Form.Control type="text" onChange={(e) => this.onChangeParamInput(e.target.value, false)} />
        </Form.Group>
      </>
    );
  }

  newFunctionForm(i) {
    return (
      <>
        {this.functionTypeDropdown(i)}
        {this.state.showParam1 ? this.param1(i) : <></>}
        {this.state.showParam2 ? this.param2(i) : <></>}
        <Button onClick={this.commitFnForm}>Done</Button>
      </>
    );
  }

  existingFunction(transformation, i) {
    return (
      <li>
        {transformation.functionType} {transformation.param1 ? transformation.param1.map(i => "\"" + i + "\"").join(", ") : <></>} {transformation.param2 ? <>with {transformation.param2.map(i => "\"" + i + "\"").join(", ")}</> : <></>}
      </li>
    );
  }

  existingFunctionsList() {
    if (this.state.transformations.length > 0) {
      return (
        <ul>
          {this.state.transformations.map((transformation, i) => 
            this.existingFunction(transformation, i)
          )}
        </ul>
      );
    } else {
      return <></>
    }
  }

  render() {
    return (
      <Form onSubmit={(e) => this.onSubmitForm(e)}>
        {this.existingFunctionsList()}
        {this.state.addingNewFunction ? this.newFunctionForm(this.state.transformations.length) : this.addNewFunctionButton()}
      </Form>
    );
  }
}