import React, { Component } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import HelpTooltip from '../layout/HelpTooltip';

import {
  selectAnOption,
  output,
  invariance,
  directionality,
  relativeSimilarity,
  testTypes,
  distributional,
  paired
} from '../constants.js';
import NewTransformationFunctionForm from './NewTransformationFunctionForm.js';

export default class NewTestForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      formComplete: false,
      testType: this.props.testType ?? selectAnOption,
      directionality: this.props.directionality ?? selectAnOption,
      granularity: this.props.granularity ?? selectAnOption,
      selectedExampleSets: this.props.selectedExampleSets ?? [],
      selectedTransformationFns: this.props.selectedTransformationFns ?? [],
      desiredBehavior: this.props.desiredBehavior ?? selectAnOption
    };
  }

  selected = (val) => {
    return val != null && val !== selectAnOption && val !== [];
  }

  selectedExampleSets = (vals) => {
    return this.state.selectedExampleSets.length >= vals.length && vals.every((i) => this.selected(this.state.selectedExampleSets.at(i)));
  }

  selectedTransformationFns = (vals) => {
    return this.state.selectedTransformationFns.length >= vals.length && vals.every((i) => this.selected(this.state.selectedTransformationFns.at(i)));
  }

  selectedByGranularity = () => {
    const type = this.state.testType;
    const granularity = this.state.granularity;

    switch (granularity) {
      case distributional:
        if (type === relativeSimilarity) {
          return this.selectedExampleSets([0, 1, 2]);
        } else {
          return this.selectedExampleSets([0, 1]);
        }
      case paired:
        if (type === relativeSimilarity) {
          return this.selectedExampleSets([0]) && this.selectedTransformationFns([0, 1]);
        } else {
          return this.selectedExampleSets([0]) && this.selectedTransformationFns([0]);
        }
      default:
        return false;
    }
  }

  isFormComplete = () => {
    const testName = this.state.testName;
    if (testName === "") {
      return false;
    }

    const type = this.state.testType;
    if (!this.selected(type)) {
      return false;
    }
    
    switch (type) {
      case output:
        return this.selectedExampleSets([0]) && this.selected(this.state.desiredBehavior);
      case invariance:
        return this.selectedByGranularity();
      case directionality:
        return this.selected(this.state.directionality) && this.selectedByGranularity();
      case relativeSimilarity:
        return this.selectedByGranularity();
      default:
        return false;
    }
  }

  updateFormComplete = () => {
    this.setState({
      formComplete: this.isFormComplete()
    });
  };

  handleChangeTestCaseName = (event) => {
    this.setState({
      testName: event.target.value,
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeType = (event) => {
    this.setState({
      testType: event.target.value,
      directionality: selectAnOption,
      granularity: selectAnOption,
      selectedExampleSets: [],
      selectedTransformationFns: [],
      desiredBehavior: selectAnOption
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeDirectionality = (event) => {
    this.setState({
      directionality: event.target.value
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeGranularity = (event) => {
    this.setState({
      granularity: event.target.value
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeExampleSets = (event, ix) => {
    const newExampleSets = [...Array((Math.max(this.state.selectedExampleSets.length, ix+1)))].map((_e, i) => {
      if (i === ix) {
        return event.target.value;
      } else if (i > this.state.selectedExampleSets.length) {
        return null;
      } else {
        return this.state.selectedExampleSets.at(i);
      }
    });

    this.setState({
      selectedExampleSets: newExampleSets
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeTransformationFn = (event, ix) => {
    const newTransformationFns = [...Array((Math.max(this.state.selectedTransformationFns.length, ix+1)))].map((_e, i) => {
      if (i === ix) {
        return event.target.value;
      } else if (i > this.state.selectedTransformationFns.length) {
        return null;
      } else {
        return this.state.selectedTransformationFns.at(i);
      }
    });

    this.setState({
      selectedTransformationFns: newTransformationFns
    }, () => {
      this.updateFormComplete();
    });
  }

  updateTransformations = (transformIdx, updatedTransformationFn) => {
    var newTransformationFns = this.state.selectedTransformationFns;
    newTransformationFns[transformIdx] = updatedTransformationFn;

    this.setState({
      selectedTransformationFns: newTransformationFns
    }, () => {
      this.updateFormComplete();
    });
  }

  handleChangeDesiredModelBehavior = (event) => {
    this.setState({
      desiredBehavior: event.target.value
    }, () => {
      this.updateFormComplete();
    });
  }

  enterTestNameTextBox = () => {
    return (
      <Form.Group className="mb-3">
        <Form.Label>Test Name</Form.Label>
        <Form.Control
          placeholder="Name of Test Case"
          type="text"
          onChange={(e) => this.handleChangeTestCaseName(e)}
          value={this.state.testName}
        />
      </Form.Group>
    );
  }

  selectTestTypeDropdown = () => {
    return (
      <Form.Group className="mb-3" controlId="formTestType">
        <Form.Label>Test Type <HelpTooltip text={[
          "Output: tests whether the model has the",
          "desired output for a particular example set.",
          "Invariance: tests that predictions do not",
          "significantly change between two sets.",
          "Directionality: tests that predictions *do* change,",
          "and in a particular direction",
        ]}/></Form.Label>
        <Form.Select onChange={this.handleChangeType} value={this.state.testType}>
          <option>{selectAnOption}</option>
          {testTypes.map((type) => <option>{type}</option>)}
        </Form.Select>
      </Form.Group>
    );
  }

  selectDirectionalityDropdownPaired = () => {
    return (
      <Form.Group className="mb-3">
        <Form.Label>Predictions should be ____ after applying the transformation(s):</Form.Label>
        <Form.Select
          onChange={this.handleChangeDirectionality}
          value={this.state.directionality}>
          <option>{selectAnOption}</option>
          <option>Higher</option>
          <option>Lower</option>
        </Form.Select>
      </Form.Group>
    );
  }

  selectDirectionalityDropdownDistributional = () => {
    return (
      <Form.Group className="mb-3">
        <Form.Label>The probability of moderation for for Example Set 2 should be ____ than for Example Set 1:</Form.Label>
        <Form.Select
          onChange={this.handleChangeDirectionality}
          value={this.state.directionality}>
          <option>{selectAnOption}</option>
          <option>Higher</option>
          <option>Lower</option>
        </Form.Select>
      </Form.Group>
    );
  }

  selectGranularityDropdown = (options) => {
    return (
      <Form.Group className="mb-3">
        <Form.Label>Granularity <HelpTooltip text={[
          "Distributional: tests aggregate changes", 
          "across two example sets",
          "Paired: tests paired changes across one example set", 
          "and a transformation to it",
        ]}/></Form.Label>
        <Form.Select
          onChange={this.handleChangeGranularity}
          value={this.state.granularity}>
          {options.length > 1 ? <option>{selectAnOption}</option> : <></>}
          {options.map(o => <option>{o}</option>)}
        </Form.Select>
      </Form.Group>
    );
  }

  selectExampleSetsDropdown = (numExampleSets) => {
    return (
      <>
        {[...Array(numExampleSets)].map((_e, i) => {
          return (
            <Form.Group className="mb-3">
              <Form.Label>Example Set {numExampleSets !== 1 ? i+1 : <></>}</Form.Label>
              <Form.Select onChange={(event) => {this.handleChangeExampleSets(event, i);}}>
                <option>{selectAnOption}</option>
                {this.props.exampleSets.map((exampleSet) => 
                  <option value={exampleSet.name} selected={this.state.selectedExampleSets.at(i) === exampleSet.name}>
                    {exampleSet.name} ({exampleSet.sentences.length} examples)
                  </option>
                )}
              </Form.Select>
            </Form.Group>
          );
        })}
      </>
    );
  }

  selectTransformationFnsInput = (numTranformationFns) => {
    return (
      <>
        {[...Array(numTranformationFns)].map((_e, i) => {
          return (
            <Form.Group className="mb-3">
              <Form.Label>Transformation {numTranformationFns !== 1 ? i+1 : <></>}</Form.Label>
              <br></br>
              <NewTransformationFunctionForm 
                updateTransformations={(updatedTransformationFn) => this.updateTransformations(i, updatedTransformationFn)}
                transformations={this.props.selectedTransformationFns ? this.props.selectedTransformationFns.at(i) : null}
              />
            </Form.Group>
          );
        })}
      </>
    );
  }

  selectExampleSetsTransformFns = (numExampleSets, numTranformationFns) => {
    return (
      <>
        {this.selectExampleSetsDropdown(numExampleSets)}
        {this.selectTransformationFnsInput(numTranformationFns)}
      </>
    );
  }

  selectDesiredModelBehaviorDropdown = () => {
    const moderatedText = "Moderated (1)";
    const unmoderatedText = "Unmoderated (0)";

    return (
      <Form.Group className="mb-3">
        <Form.Label>Desired Model Behavior</Form.Label>
        <Form.Select onChange={this.handleChangeDesiredModelBehavior}>
          <option>{selectAnOption}</option>
          <option selected={this.state.desiredBehavior === moderatedText}>{moderatedText}</option>
          <option selected={this.state.desiredBehavior === unmoderatedText}>{unmoderatedText}</option>
        </Form.Select>
      </Form.Group>
    );
  }

  typeSpecificFormSection() {
    const type = this.state.testType;

    switch (type) {
      case output:
        return (
          <>
            {this.selectExampleSetsTransformFns(1, 0)}
            {this.selectDesiredModelBehaviorDropdown()}
            <br></br>
          </>
        );
      case invariance:
        return (
          <>
            {this.selectGranularityDropdown([distributional, paired])}
            {this.selected(this.state.granularity) && this.state.granularity === distributional ? this.selectExampleSetsTransformFns(2, 0) : <></>}
            {this.selected(this.state.granularity) && this.state.granularity === paired ? this.selectExampleSetsTransformFns(1, 1) : <></>}
            <br></br>
          </>
        );
      case directionality:
        return (
          <>
            {this.selectGranularityDropdown([distributional, paired])}
            {this.selected(this.state.granularity) && this.state.granularity === distributional ? this.selectExampleSetsTransformFns(2, 0) : <></>}
            {this.selected(this.state.granularity) && this.state.granularity === paired ? this.selectExampleSetsTransformFns(1, 1) : <></>}
            {this.selected(this.state.granularity) && this.state.granularity === distributional && this.selected(this.state.selectedExampleSets) ? this.selectDirectionalityDropdownDistributional() : <></>}
            {this.selected(this.state.granularity) && this.state.granularity === paired && this.selected(this.state.selectedTransformationFns) ? this.selectDirectionalityDropdownPaired() : <></>}
            <br></br>
          </>
        );
      case relativeSimilarity:
        return (
          <>
            {this.selectGranularityDropdown([distributional, paired])}
            {this.selected(this.state.granularity) && this.state.granularity === distributional ? this.selectExampleSetsTransformFns(3, 0) : <></>}
            {this.selected(this.state.granularity) && this.state.granularity === paired ? this.selectExampleSetsTransformFns(1, 2) : <></>}
            <br></br>
          </>
        );
      default:
        return <></>;
    }
  }

  getTestObject = () => {
    const name = this.state.testName;
    const type = this.state.testType;
    const granularity = this.state.granularity;

    switch (type) {
      case output:
        return {
          name: name,
          type: type,
          exampleSets: [this.state.selectedExampleSets.at(0)],
          desiredBehavior: this.state.desiredBehavior,
          runTestIdx: 0
        };
      case invariance:
        switch (granularity) {
          case distributional:
            return {
              name: name,
              type: type,
              granularity: granularity,
              exampleSets: [this.state.selectedExampleSets.at(0), this.state.selectedExampleSets.at(1)],
              runTestIdx: 0
            };
          case paired:
            return {
              name: name,
              type: type,
              granularity: granularity,
              exampleSet: this.state.selectedExampleSets.at(0),
              transformationFunction: this.state.selectedTransformationFns.at(0),
              runTestIdx: 0
            };
          default:
            return {};
        }
      case directionality:
        switch (granularity) {
          case distributional:
            return {
              name: name,
              type: type,
              directionality: this.state.directionality,
              granularity: granularity,
              exampleSets: [this.state.selectedExampleSets.at(0), this.state.selectedExampleSets.at(1)],
              runTestIdx: 0
            };
          case paired:
            return {
              name: name,
              type: type,
              directionality: this.state.directionality,
              granularity: granularity,
              exampleSet: this.state.selectedExampleSets.at(0),
              transformationFunction: this.state.selectedTransformationFns.at(0),
              runTestIdx: 0
            };
          default:
            return {};
        }
      case relativeSimilarity:
        switch (granularity) {
          case distributional:
            return {
              name: name,
              type: type,
              granularity: granularity,
              exampleSets: [this.state.selectedExampleSets.at(0), this.state.selectedExampleSets.at(1), this.state.selectedExampleSets.at(2)],
              runTestIdx: 0
            };
          case paired:
            return {
              name: name,
              type: type,
              granularity: granularity,
              exampleSet: this.state.selectedExampleSets.at(0),
              transformationFunctions: [this.state.selectedTransformationFns.at(0), this.state.selectedTransformationFns.at(1)],
              runTestIdx: 0
            };
          default:
            return {};
        }
      default:
        return {};
    }
  }

  onSubmitForm = (e) => {
    e.preventDefault();

    const testObject = this.getTestObject();
    console.log("HERE", testObject)
    this.props.addTestCallback(testObject);

    this.setState({
      formComplete: false,
      testType: selectAnOption,
      directionality: selectAnOption,
      granularity: selectAnOption,
      selectedExampleSets: [],
      selectedTransformationFns: [],
      desiredBehavior: selectAnOption
    });
  }

  onCancelForm = (e) => {
    e.preventDefault();

    this.props.cancelForm();

    this.setState({
      formComplete: false,
      testType: selectAnOption,
      directionality: selectAnOption,
      granularity: selectAnOption,
      selectedExampleSets: [],
      selectedTransformationFns: [],
      desiredBehavior: selectAnOption
    });
  }

  submitButton = () => {
    return (
      <Button className="button-color" variant="primary" type="submit" disabled={!this.state.formComplete} onClick={this.onSubmitForm}>
        Submit
      </Button>
    );
  }

  cancelButton = () => {
    return (
      <Button variant="secondary" type="button" style={{marginLeft: "10px"}} onClick={this.onCancelForm}>
        Cancel
      </Button>
    );
  }

  render() {
    return (
      <>
        {this.enterTestNameTextBox()}
        {this.selectTestTypeDropdown()}
        {this.typeSpecificFormSection()}
        {this.submitButton()}
        {this.cancelButton()}
      </>
    );
  }
}