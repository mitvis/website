import React, { Component } from 'react';
import * as d3 from 'd3';
import { rectContains, rectIntersects } from 'vis-utils';
import Dropdown from 'react-bootstrap/Dropdown';

export default class ProjectionPlot extends Component {
	constructor(props) {
    super(props);

    this.state = {
      x: null,
      y: null,
      data: null,
      quadtree: null,
      brushedIds: new Set(),
      brushObject: null,
			projectionType: "tsne",
    }

    this.margin = {top: 0, right: 0, bottom: 0, left: 0};
    this.width = 400 - this.margin.left - this.margin.right;
    this.height = 400 - this.margin.top - this.margin.bottom;
		this.transform = null;
		this.projectionTypes = ["tsne", 'pca', "umap"];
		this.clusterColors = ["#f28e2b", "#e15759", "#76b7b2"]
  }

  componentDidMount() {
    let data = JSON.parse(this.props.data_and_bounds.data_json);
    this.setState({
      data: data
    }, () => {
      this.createAxes(true)
    });

    // this.createAxes();
    // this.updatePoints();
  }

  // Whenever the component updates, select the <g> from the DOM, and use D3 to manipulte circles
  componentDidUpdate(prevProps, prevState) {
		if (prevState.projectionType !== this.state.projectionType) {
			this.createAxes(false);
			d3.select(this.brush).call(this.state.brushObject.move, null);
		}

		if (prevProps.clusterIds !== this.props.clusterIds) { // if clusters have changed
			if (!this.props.clusterIds) {
				if (prevProps.clusterIds) { // if there are no longer visible clusters, unhighlight all previous cluster points
					for (let i = 0; i < prevProps.clusterIds.length; i++) { 
						this.highlightPoints(Array.from(prevProps.clusterIds[i]), new Set())
					}
				}
			} else {
				if (!prevProps.clusterIds) { // if there are visible clusters (but there weren't any before), highlight all new points
					for (let i = 0; i < this.props.clusterIds.length; i++) {
						this.highlightPoints(new Set(), Array.from(this.props.clusterIds[i]), this.clusterColors[i])
					}
				} else {
					for (let i = 0; i < prevProps.clusterIds.length; i++) { // if there were clusters before, unhighlight those points and highlight the new ones
						this.highlightPoints(Array.from(prevProps.clusterIds[i]), Array.from(this.props.clusterIds[i]), this.clusterColors[i])
					}
				}
			}
		}

    if (prevProps.expandedIds !== this.props.expandedIds) {
      let unhighlightIds = this.difference(prevProps.expandedIds, this.props.expandedIds);
      this.highlightPoints(Array.from(unhighlightIds), Array.from(this.props.expandedIds));
    }

    if (prevState.brushedIds !== this.state.brushedIds) {
      this.props.updateBrushedPoints(this.state.brushedIds);
      // let unbrushIds = this.difference(prevState.brushedIds, this.state.brushedIds);
      // this.highlightPoints(Array.from(unbrushIds), Array.from(this.state.brushedIds));
    }

    if (prevProps.exampleSource !== this.props.exampleSource) {
      if (this.props.exampleSource !== "brushedIds") {
        d3.select(this.brush).call(this.state.brushObject.move, null);
      }
    }
  }

  difference(setA, setB) {
    let _difference = new Set(setA);
    for (let elem of setB) {
        _difference.delete(elem);
    }
    return _difference;
	}

  createAxes(addPointsAfter=true) {
    let bounds = this.props.data_and_bounds.bounds;
    let projection_type = this.state.projectionType;

    const x = d3.scaleLinear()
      .domain([bounds[projection_type][0][0], bounds[projection_type][0][1]])
      .range([ 0, this.width ]);
			
		const xAxis = (g) => 
				g.attr("transform", "translate(" + this.margin.left + "," + (this.margin.top + this.height/2) + ")")
				.call(d3.axisBottom(x).tickValues([]).tickSizeOuter(0));

		d3.select(this.xAxis).call(xAxis);

		// Add Y axis
		const y = d3.scaleLinear()
			.domain([bounds[projection_type][1][0], bounds[projection_type][1][1]])
			.range([ this.height, 0]);
			
		const yAxis = (g) => 
			g.attr("transform", "translate(" + (this.margin.left + this.width/2) + "," + this.margin.top + ")")
			.call(d3.axisLeft(y).tickValues([]).tickSizeOuter(0));

		d3.select(this.yAxis).call(yAxis);

		let data = this.state.data;
		let x_coord_name = this.state.projectionType + "_x";
		let y_coord_name = this.state.projectionType + "_y";
		const quadtree = d3.quadtree()
		  .x(d => x(d[x_coord_name]))
		  .y(d => y(d[y_coord_name]))
		  .addAll(data);

		this.setState({
			x: x,
			y: y,
			quadtree: quadtree
		}, () => {
      if (addPointsAfter) {this.addPoints()} else {this.updatePoints()}
    });
  }

  addPoints() {
    let x = this.state.x;
    let y = this.state.y;
    let width = this.width; 
    let height = this.height; 
    let data = this.state.data;

    // create the d3-brush generator
		const brush = d3.brush()
  			.extent([[0, 0], [width, height]])
  			.on('end', this.updateBrush.bind(this));

    this.setState({
      brushObject: brush
    });

    // attach the brush to the chart
		// const gBrush = d3.select(this.brush)
		//   .attr('class', 'brush')
		//   .call(brush);

    // Add the tooltip container to the vis container
    // it's invisible and its position/contents are defined during mouseover
    var tooltip = d3.select(this.tooltip)
        .attr("class", "tooltip")
        .style("opacity", 0);

    // tooltip mouseover event handler
    var tipMouseover = function(event, d) {
      let x = this.state.x;
      let y = this.state.y;
      let x_coord_name = this.state.projectionType + "_x";
			let y_coord_name = this.state.projectionType + "_y";
      var html = d.comment;

			tooltip.html(html)
        .style("left", (x(d[x_coord_name]) + 20) + "px")
        .style("top", (y(d[y_coord_name]) + 40) + "px")
        .transition()
        .duration(200) // ms
        .style("opacity", .9) // started as 0!
    }.bind(this);

    // tooltip mouseout event handler
    var tipMouseout = function(d) {
      tooltip.transition()
        .duration(300) // ms
        .style("opacity", 0); // don't care about position!
    };

		// zoom
		// var zoom = d3.zoom().on("zoom", e => {
		// 	console.log(e.transform);
		// 	d3.select(this.chartArea).attr("transform", (this.transform = e.transform));
		// 	d3.select(this.chartArea).style("stroke-width", 3 / Math.sqrt(this.transform.k));
		// 	d3.select(this.chartArea).attr("r", 3 / Math.sqrt(this.transform.k));

		// 	d3.select(this.xAxis)
		// 	.attr("transform", "translate(" + (this.margin.left) + "," + (this.margin.top + this.height/2 + this.transform.y  * this.transform.k) + ")")
		// 	.call(d3.axisBottom(x).tickValues([]).tickSizeOuter(0));
		// 	d3.select(this.yAxis)
		// 	.attr("transform", "translate(" + (this.margin.left + this.width/2 + this.transform.x * this.transform.k) + "," + this.margin.top + ")")
		// 	.call(d3.axisLeft(y).tickValues([]).tickSizeOuter(0));
		// });

		// d3.select(this.chartArea).call(zoom);

		d3.select(this.chartArea).selectAll('dot').remove();
		let x_coord_name = this.state.projectionType + "_x";
		let y_coord_name = this.state.projectionType + "_y";
    let dots = d3.select(this.chartArea)
      .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")")
      .selectAll('dot')
      .data(data)
      .enter()
      .append("circle")
      .attr("cx", function (d) { return x(d[x_coord_name]); } )
      .attr("cy", function (d) { return y(d[y_coord_name]); } )
      .attr("r",  1.5 )
      .attr("exampleId", function(d) { return d.comment_id; })
      .attr("text", function(d) { return d.comment; })
      .style("fill", "#89909F" )
      .style("opacity", .1 )
      .on("mouseover", tipMouseover)
      .on("mouseout", tipMouseout);

		dots.exit().remove(); 
  }

  updateBrush(event) {
    const { selection } = event;

		if (!selection) {
			this.setState({
				brushedIds: new Set()
			});
      return;
    }

		// begin an array to collect the brushed nodes
		const brushedNodeIds = new Set();
		let x_coord_name = this.state.projectionType + "_x";
		let y_coord_name = this.state.projectionType + "_y";

		// traverse the quad tree, skipping branches where we do not overlap
		// with the brushed selection box
		this.state.quadtree.visit((node, x1, y1, x2, y2) => {
      // check that quadtree node intersects
      const overlaps = rectIntersects(selection, [[x1, y1], [x2, y2]]);

      // skip if it doesn't overlap the brush
      if (!overlaps) {
        return true;
      }

      // if this is a leaf node (node.length is falsy), verify it is within the brush
      // we have to do this since an overlapping quadtree box does not guarantee
      // that all the points within that box are covered by the brush.
      if (!node.length) {
        const d = node.data;
        const dx = this.state.x(d[x_coord_name]);
        const dy = this.state.y(d[y_coord_name]);
        if (rectContains(selection, [dx, dy])) {
          brushedNodeIds.add(d.comment_id);
        }
      }

      // return false so that we traverse into branch (only useful for non-leaf nodes)
      return false;
		});

    // update the highlighted brushed nodes
    this.setState({
			brushedIds: brushedNodeIds
		});
  }

  updatePoints() {
    let data = this.state.data;
    let x = this.state.x;
    let y = this.state.y;
    let x_coord_name = this.state.projectionType + "_x";
		let y_coord_name = this.state.projectionType + "_y";

    d3.select(this.chartArea)
      .selectAll("circle")
      .data(data)
      .attr("cx", function (d) { return x(d[x_coord_name]); } )
		  .attr("cy", function (d) { return y(d[y_coord_name]); } )
		  .attr("r", 1.5)
		  .style("fill", "#89909F" )
		  .style("opacity", .1 )
		  .attr("exampleId", function(d) { return d.comment_id; });

		for (let i = 0; i < this.props.clusterIds.length; i++) {
			this.highlightPoints(new Set(), Array.from(this.props.clusterIds[i]), this.clusterColors[i])
		}
  }

  highlightPoints(unhighlightIds, expandedIds, color="#4e79a7") {
    for (let i = 0; i < unhighlightIds.length; i++) {
			d3.select('circle[exampleId="' + unhighlightIds[i] + '"]')
			 .attr("r", 1.5)
			 .style("fill", "#89909F")
			 .style("opacity", .1);
    }

    for (let j = 0; j < expandedIds.length; j++) {
			d3.select('circle[exampleId="' + expandedIds[j] + '"]')
		   	 .style("fill", color)
			 .style("opacity", "1")
			 .attr("r", 2)
			 .raise();
    }
  }

	changeProjectionType(newProjectionType) {
		this.setState({
      projectionType: newProjectionType
    });
	}

  render() {
    return(
      <>
    		<div>
			    <span style={{'float': 'left', 'margin': '4px'}}>Projection type:</span> 
			    <Dropdown>
            <Dropdown.Toggle id="dropdown-basic" style={{'padding': '0.2rem 0.3rem', 'float': 'left'}}>
              {this.state.projectionType}
            </Dropdown.Toggle>

            <Dropdown.Menu>
              {this.projectionTypes.map((projectionType) => 
              <Dropdown.Item active={projectionType === this.state.projectionType} onClick={() => this.changeProjectionType(projectionType)}>
                {projectionType}
              </Dropdown.Item>
              )}
            </Dropdown.Menu>
			    </Dropdown>
			  </div>
			  <br></br>
        <svg ref={(node) => {this.svg = node; }}
          className="chart" 
          width={this.width + this.margin.left + this.margin.right} 
          height={this.height + this.margin.top + this.margin.bottom}>

          {/* Axes */}
          <g ref={(node) => {this.brush = node; }} />
          <g ref={(node) => { this.xAxis = node; }} />
          <g ref={(node) => { this.yAxis = node; }} />
          <g ref={(node) => { this.chartArea = node; }} />
        </svg>
        <div ref={(node) => { this.tooltip = node; }} />
        <div className="plotDescription">
          Each point in this plot represenents a comment from r/funny, projected into 
          a 2d space where similar comments are close to each other.
          Drag over a set of examples to populate the "Search and Explore" tab.
        </div>
      </>
    );
  }
}
