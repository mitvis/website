import React, { PureComponent, Component } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import Button from 'react-bootstrap/Button';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ListGroup from 'react-bootstrap/ListGroup';
import { Pencil, Trash, Check, ExclamationTriangle, ArrowUp, ArrowDown } from 'react-bootstrap-icons';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import TestOutput from './TestOutput.js';

import {
  epsilon,
  pcutoff,
  distributional,
  output,
  invariance,
  directionality,
  relativeSimilarity,
  paired,
  divergingColorScale,
  sequentialColorScale
} from '../constants.js';
import NewTestForm from '../forms/NewTestForm.js';

var $;
$ = require('jquery');

export default class DefinedTestsSection extends Component {
	
	constructor(props) {
		super(props);
		this.state = {};
	}

	render() {
		return(
			<>
        <h3>Tests</h3>
      	<DefinedTestsList 
          addTestCallback={newTest => this.props.addTestCallback(newTest)}
          updateTestResult={this.props.updateTestResult}
          exampleSets={this.props.exampleSets}
					definedTests={this.props.definedTests}
          removeDefinedTest={i => this.props.removeDefinedTest(i)}
          editDefinedTest={(i, newTest) => this.props.editDefinedTest(i, newTest)}
          selectedModel={this.props.selectedModel}
          updateExpandedTest={this.props.updateExpandedTest}
          removeExpandedTest={this.props.removeExpandedTest}
          setTestAsRunning={this.props.setTestAsRunning}
				/>
			</>
		)
	}
}

class DefinedTestsList extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      addingTestCase: false,
      newTestName: "",
    };
  }


  removeDefinedTest(i, e) {
    e.preventDefault();
    e.stopPropagation();
    this.props.removeExpandedTest(i, 'test')
    this.props.removeDefinedTest(i);
  }

  editAddTestCase() {
    this.setState({
      addingTestCase: true,
    });
  }

  runSingleTest(testIdx) {
    var exampleSetNames = this.props.definedTests[testIdx].exampleSet ?
                            [this.props.definedTests[testIdx].exampleSet] : 
                              this.props.definedTests[testIdx].exampleSets ?
                                this.props.definedTests[testIdx].exampleSets : null;

    var allExampleSets = this.props.exampleSets;
    var exampleSetSentences = exampleSetNames.map(
        exSetName => allExampleSets.filter(
          exampleSet => exampleSet.name === exSetName)[0].sentences);
    var exampleSetIds = exampleSetNames.map(
        exSetName => allExampleSets.filter(
          exampleSet => exampleSet.name === exSetName)[0].exampleIds);
    var transformationFunctions = this.props.definedTests[testIdx].transformationFunction ? 
                                        [this.props.definedTests[testIdx].transformationFunction] : 
                                          this.props.definedTests[testIdx].transformationFunctions ?
                                            this.props.definedTests[testIdx].transformationFunctions : null;


    let testInfo = {
      'granularity': this.props.definedTests[testIdx].granularity ? this.props.definedTests[testIdx].granularity.toLowerCase() : null,
      'test_type': this.props.definedTests[testIdx].type.toLowerCase(),
      'example_set_names': exampleSetNames,
      'example_sets': exampleSetSentences,
      'example_set_ids': exampleSetIds,
      'direction': this.props.definedTests[testIdx].directionality ? this.props.definedTests[testIdx].directionality : null,
      'desired_output': this.props.definedTests[testIdx].desiredBehavior ? this.props.definedTests[testIdx].desiredBehavior : null,
      // 'transformation_function_names': transformationFunctionNames,
      'transformation_functions': transformationFunctions
    }

    // const exampleSetSentences = this.props.allExampleSets.filter(exampleSet => exampleSet.name === this.props.definedTest.exampleSet)[0].sentences;
    this.props.setTestAsRunning(testIdx)

    $.post(
      '/api/runTest',
      {test_info: JSON.stringify(testInfo), model: this.props.selectedModel},
      function(result) {
        this.props.updateTestResult(
          this.props.definedTests[testIdx].name,
          result.res_string,
          result.preds,
          result.transformed_examples,
          result.transformation_applied,
          result.transformed_idx, 
          result.mean_diff,
          result.pval
        );
      }.bind(this)
    );

    // $("#testResult" + testIdx.toString()).toggle(500, function() {
    //     $(this).toggle(500)
    // });
  }

  runAll() {
    for (let testIdx = 0; testIdx < this.props.definedTests.length; testIdx++) {
      if (!this.props.definedTests[testIdx].deactivated) {
        this.runSingleTest(testIdx);
      }
    }

    // $(".testResult").each(function() {
    //   $(this).toggle(500, function() {
    //     console.log("toggled once")
    //     $(this).toggle(500)
    //   })
    // })
  }

  toggleSelected(index) {
    console.log(index);
  }

  render() {
    let numDefinedTests = this.props.definedTests.length;
    let definedTestTypes = this.props.definedTests.map((definedTest, i) => definedTest.type);
    definedTestTypes.reverse();
    let uniqueTestTypes = new Set(definedTestTypes);
    let definedTestComponents = this.props.definedTests.slice(0).reverse().map((definedTest, i) =>
      <DefinedTest
        index={numDefinedTests - i - 1}
        key={numDefinedTests - i - 1}
        definedTest={definedTest}
        updateTestResult={this.props.updateTestResult}
        exampleSets={this.props.exampleSets}
        removeDefinedTest={e => this.removeDefinedTest(numDefinedTests - i - 1, e)}
        editDefinedTest={(newTest) => this.props.editDefinedTest(numDefinedTests - i - 1, newTest)}
        runSingleTest={() => this.runSingleTest(numDefinedTests - i - 1)}
        addTestCallback={newTest => this.props.addTestCallback(newTest)}
        toggleSelected={(index) => this.props.updateExpandedTest(index, 'test')}
      />
    );

    return (
      <>

      <Button style={{'width': 'auto', 'marginBottom': '10px'}} onClick={() => this.runAll()}>
        Run all tests
      </Button>
      <Button variant="light" style={{'width': 'auto', 'marginBottom': '10px', 'marginLeft': '20px'}} onClick={() => this.editAddTestCase()}>
        + Add new test
      </Button>

      {this.state.addingTestCase ?
        <Accordion defaultActiveKey={['0']} alwaysOpen>
          <Accordion.Item eventKey="0">
            <Accordion.Body>
              <NewTestForm
                cancelForm={() => {
                  this.setState({
                    addingTestCase: false,
                    newTestName: ""
                  });
                }}
                addTestCallback={newTest => {
                  this.props.addTestCallback(newTest);
                  this.setState({
                    addingTestCase: false,
                    newTestName: ""
                  });
                }}
                exampleSets={this.props.exampleSets}
              />
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      : <></>}

      {uniqueTestTypes.has(output) ? (
        <>
          <div className="test-header">Output tests</div>
          <Accordion alwaysOpen={false}>
            {definedTestComponents.filter((definedTest, i) => definedTestTypes[i] === output)}
          </Accordion>
        </>) : <></>
      }
    
      {uniqueTestTypes.has(invariance) ? (
        <>
          <div className="test-header">Invariance tests</div>
          <Accordion alwaysOpen={false}>
            {definedTestComponents.filter((definedTest, i) => definedTestTypes[i] === invariance)}
          </Accordion>
        </>) : <></>
      }

      {uniqueTestTypes.has(directionality) ? (
        <>
          <div className="test-header">Directionality tests</div>
          <Accordion alwaysOpen={false}>
            {definedTestComponents.filter((definedTest, i) => definedTestTypes[i] === directionality)}
          </Accordion>
        </>) : <></>
      }

      </>
    );
  }
}

class DefinedTest extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      editing: false,
      newName: "",
    }
  }

  editDefinedTest(e) {
    this.setState({newName: e.target.value});
  }

  startEditDefinedTest(e) {
    e.stopPropagation();
    e.preventDefault();
    this.setState({
      editing: true
    });
  }

  endEditDefinedTest() {
    let testObj = this.props.definedTest
    testObj['name'] = this.state.newName ? this.state.newName : this.props.definedTest.name
    this.props.editDefinedTest(testObj);
    this.setState({
      editing: false,
      newName: ""
    });
  }

  typeParam() {
    return (
      <ListGroup.Item>
        <b>Type:</b> {this.props.definedTest.type}
      </ListGroup.Item>
    );
  }

  directionalityParam() {
    return (
      <ListGroup.Item>
        <b>Directionality:</b> {this.props.definedTest.directionality}
      </ListGroup.Item>
    );
  }

  granularityParam() {
    return (
      <ListGroup.Item>
        <b>Granularity:</b> {this.props.definedTest.granularity}
      </ListGroup.Item>
    );
  }

  exampleSetParam() {
    return (
      <ListGroup.Item>
        <b>Example Set:</b> {this.props.definedTest.exampleSet}
      </ListGroup.Item>
    );
  }

  exampleSetsParam() {
    return (
      <ListGroup.Item>
        <b>Example Sets:</b> {this.props.definedTest.exampleSets.join(", ")}
      </ListGroup.Item>
    );
  }

  transformationToString(transformation) {
    let stringOne = transformation.param1 ? transformation.param1.map(i => "\"" + i + "\"").join(", ") : "";
    let stringTwo = transformation.param2 ? "with " + transformation.param2.map(i => "\"" + i + "\"").join(", ") : "";
    return transformation.functionType + " " + stringOne + " " + stringTwo;
  }

  transformationFunctionParam() {
    let transformations = this.props.definedTest.transformationFunction;
    return (
      <ListGroup.Item>
        <b>Transformation Function:</b> {transformations.map((transform, i) => this.transformationToString(transform)).join(", ")}
      </ListGroup.Item>
    );
  }

  transformationFunctionsParam() {
    let transformationsList = this.props.definedTest.transformationFunctions;

    return (
      <ListGroup.Item>
        <b>Transformation Functions:</b>
        {transformationsList.map((transformations, i) => 
          (i+1).toString() + ". " + transformations.map((transform, i) => this.transformationToString(transform)).join(", ")).join("; ") 
        }
      </ListGroup.Item>
    );
  }

  desiredModelBehaviorParam() {
    return (
      <ListGroup.Item>
        <b>Desired Model Behavior:</b> {this.props.definedTest.desiredBehavior}
      </ListGroup.Item>
    );
  }

  testParams() {
    const type = this.props.definedTest.type;

    if (type === output) {
      return (<>
        {this.typeParam()}
        {this.exampleSetsParam()}
        {this.desiredModelBehaviorParam()}
      </>);
    } else if (type === invariance) {
      return (<>
        {this.typeParam()}
        {this.granularityParam()}
        {this.props.definedTest.granularity === paired ? this.exampleSetParam() : this.exampleSetsParam()}
        {this.props.definedTest.granularity === paired ? this.transformationFunctionParam() : <></>}
      </>);
    } else if (type === directionality) {
      return (<>
        {this.typeParam()}
        {this.directionalityParam()}
        {this.granularityParam()}
        {this.props.definedTest.granularity === paired ? this.exampleSetParam() : this.exampleSetsParam()}
        {this.props.definedTest.granularity === paired ? this.transformationFunctionParam() : <></>}
      </>);
    } else if (type === relativeSimilarity) {
      return (<>
        {this.typeParam()}
        {this.granularityParam()}
        {this.props.definedTest.granularity === paired ? this.exampleSetParam() : this.exampleSetsParam()}
        {this.props.definedTest.granularity === paired ? this.transformationFunctionsParam() : <></>}
      </>);
    } else {
      return <p className='error'>Unknown type {type}</p>;
    }
  }

  getResultString(definedTest) {
    if (this.props.definedTest.type === directionality) {
      return this.getDirectionalityResultString();
    }
  }

  getDirectionalityResultString() {
    let res_string = "";

    if (this.props.definedTest.granularity === distributional) {
      let beginning = (<>You specified that the examples in {this.props.definedTest.exampleSets[1]} should be
          {this.props.definedTest.directionality === 'Higher' ? 'more' : 'less'} likely to be moderated than 
          {this.props.definedTest.exampleSets[0]}</>)

      if ((this.props.definedTest.pval >= pcutoff) || (Math.abs(this.props.definedTest.mean_diff) <= epsilon)) {
        res_string = (<span>{beginning}, but there’s actually *no significant difference* in moderation between the two.</span>)
      } else {
        let meanDiffDirection = this.props.definedTest.meanDiff > 0 ? "Higher" : "Lower"
        if (meanDiffDirection === this.props.definedTest.directionality) {
          res_string = (<span>{beginning}, and the probability of moderation according to the model is indeed 
            {this.props.definedTest.meanDiff} {this.props.definedTest.directionality === 'Higher' ? 'lower' : 'higher'}  
            on average.</span>)
        } else {
          res_string = (<span>{beginning}. However, the probability of moderation for {this.props.definedTest.exampleSets[1]}
          is actually {this.props.definedTest.meanDiff} {this.props.definedTest.directionality === 'Higher' ? 'lower' : 'higher'} 
          on average.</span>)
        }
      }
    }

    return res_string;
  }

  getOutputResultLabel() {
    const textId = "testResult" + this.props.index;
    var valString = this.props.definedTest.result.split(" ")[0].replace(/% ?/g, "");
    let colorQuantile = Math.floor(valString/20)*20/10;
    let colorIdx = Math.min(colorQuantile/2, 4);
    let textColor = divergingColorScale[colorIdx];
    let resultText = this.props.definedTest.result.split(" ")[0];

    return <span id={textId} className="testResult" style={{'color': textColor, 'fontWeight': 'bold'}}>{resultText}</span>;
  }

  getInvarianceResultLabel() {
    let diffQuantile = Math.floor(Math.abs(this.props.definedTest.meanDiff) * 10) / 10;
    let diffIndex = diffQuantile*10;
    let textColor = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4];
    // var hue = (parseFloat(1 - Math.abs(this.props.definedTest.meanDiff)) / 1.0 * 1200).toString(10);
    // let textColor = ["hsl(",hue,",100%,40%)"].join("");
    const textId = "testResult" + this.props.index;

    let label = null;
    if (this.props.definedTest.pval < pcutoff) {
      if (this.props.definedTest.meanDiff > epsilon) {
        label = <b><ArrowUp /> {(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}%</b>;
      } else if (this.props.definedTest.meanDiff < -1*epsilon) {
        label = <b><ArrowDown /> {(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}%</b>;
      } else {
        label = <b>==</b>;
      }
    } else {
      label = <b>==</b>;
    }

    return <span id={textId} className="testResult" style={{'color': textColor}}>{label}</span>
  }


  getDirectionalityResultLabel() {
    let diffQuantile = Math.floor(Math.abs(this.props.definedTest.meanDiff) * 10) / 10;
    let diffIndex = diffQuantile*10;
    let textColor = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4];

    const textId = "testResult" + this.props.index;

    let label = null;

    if (this.props.definedTest.pval < pcutoff) {
      if (this.props.definedTest.meanDiff > epsilon) {
        label = <b><ArrowUp /> {(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}%</b>;
      } else if (this.props.definedTest.meanDiff < -1*epsilon) {
        label = <b><ArrowDown /> {(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}%</b>;
      } else {
        label = <b>==</b>;
      }
    } else {
      label = <b>==</b>;
    }

    return (
      <span id={textId} className="testResult" style={{'color': textColor}}>{label}</span>
    );
  }

  getNotRunLabel() {
    const textId = "testResult" + this.props.index;
    let textColor = 'gray';
    let resultText = "NOT RUN";
    return <span id={textId} className="testResult" style={{'color': textColor, 'fontWeight': 'bold'}}>{resultText}</span>;
  }

  testLabel() {
    if (this.props.definedTest.running) {
      return <span style={{'font-weight': 'bold', 'color': 'grey'}}>. . .</span>
    } else if (this.props.definedTest.deactivated) {
      return <ExclamationTriangle />;
    } else if (this.props.definedTest.result) {
      switch (this.props.definedTest.type) {
        case output: return this.getOutputResultLabel();
        case invariance: return this.getInvarianceResultLabel();
        default: return this.getDirectionalityResultLabel();
      }
    } else {
      return this.getNotRunLabel();
    }
  }

  render() {
    var opacityVal = (this.props.definedTest.deactivated) ? 0.5 : 1;

    const checkButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.endEditDefinedTest()}>
        <Check />
      </Button>
    );

    const editButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.startEditDefinedTest(e)}>
        <Pencil />
      </Button>
    );

    const trashButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.props.removeDefinedTest(e)}>
        <Trash />
      </Button>
    );

 
    return (

      <Accordion.Item eventKey={this.props.index}>
        <Accordion.Header style={{'opacity': opacityVal}} onClick={() => this.props.toggleSelected(this.props.index)}>
          <Container>
            <Row>
              <Col sm={3} style={{padding: '0', display: 'flex', alignItems: 'center'}}>
                {this.testLabel()}
              </Col>
              <Col sm={7} style={{padding: '0', display: 'flex', alignItems: 'center'}}>
                {this.state.editing ?
                  <ListGroup.Item>
                    <Form onSubmit={() => this.endEditDefinedTest()}>
                      <Form.Control
                        type="text"
                        defaultValue={this.props.definedTest.name}
                        onChange={(e) => this.editDefinedTest(e)}
                      />
                    </Form>
                  </ListGroup.Item> 
                  : <div>{this.props.definedTest.name}</div>
                }
              </Col>
              <Col sm={2}>
                <ButtonGroup>
                  {this.state.editing ? checkButton : editButton}
                  {trashButton}
                </ButtonGroup>
              </Col>
            </Row>
          </Container>
        </Accordion.Header>
        <Accordion.Body>
          {this.state.editing ?
            <NewTestForm
              testName={this.props.definedTest.name}
              cancelForm={() => {
                this.setState({
                  addingTestCase: false,
                  editing: false,
                  newTestName: "",
                });
              }}
              addTestCallback={newTest => {
                this.props.editDefinedTest(newTest);
                this.setState({
                  addingTestCase: false,
                  editing: false,
                });
              }}
              exampleSets={this.props.exampleSets}
              selectedExampleSets={this.props.definedTest.exampleSets ?? [this.props.definedTest.exampleSet]}
              selectedTransformationFns={this.props.definedTest.transformationFunctions ?? (this.props.definedTest.transformationFunction ? [this.props.definedTest.transformationFunction] : null)}
              desiredBehavior={this.props.definedTest.desiredBehavior}
              directionality={this.props.definedTest.directionality}
              granularity={this.props.definedTest.granularity}
              testType={this.props.definedTest.type}
            />
            :
            <>
              <ListGroup>{this.testParams()}</ListGroup>
              <TestOutput definedTest={this.props.definedTest} exampleSets={this.props.exampleSets}/>
              <br></br>
              <Button onClick={() => this.props.runSingleTest()} disabled={this.props.definedTest.deactivated}>
                Re-run test
              </Button>
            </>
          }
        </Accordion.Body>
      </Accordion.Item>
    );
  }
}
