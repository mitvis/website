import React, { Component } from 'react';
import SearchExploreSection from './SearchExploreSection.js';
import ExampleSetsList from './ExampleSetsList.js';
import Row from 'react-bootstrap/Row'


export default class ExampleSetsSection extends Component {

	constructor(props) {
		super(props);

		this.state = {
			activeIds: new Set(),
			activeIdsToAdd: new Set(),
		}
	}

	updateActiveIds = (newActiveIds) => {
		this.setState({
			activeIds: newActiveIds
		});
	}

	updateActiveIdsToAdd = (newActiveIds) => {
		this.setState({
			activeIdsToAdd: newActiveIds
		});
	}

	render() {
		return(
		  <>
        <h3>Example Sets</h3>
    		<Row style={{'marginBottom':'10px', 'marginTop':'10px'}}>
          <ExampleSetsList
            exampleSource={this.props.exampleSource}
            updateHoveringIds={this.props.updateHoveringIds}
            updateExpandedExSet={this.props.updateExpandedExSet}
            removeExpandedExSet={this.props.removeExpandedExSet}
            exampleSets={this.props.exampleSets}
            updateExampleSets={this.props.updateExampleSets}
            activeIds={this.state.activeIds}
            updateActiveIds={this.updateActiveIds}
            data={this.props.data}
            addExample={this.props.addExample}
            maxId={this.props.maxId}
          />
        </Row>
        <Row>
          <SearchExploreSection
            updateExampleSource={this.props.updateExampleSource}
            exampleSource={this.props.exampleSource}
            brushedIds={this.props.brushedIds}
            updateBrushedPoints={this.props.updateBrushedPoints}
            updateHoveringIds={this.props.updateHoveringIds}
            exampleSets={this.props.exampleSets}
            updateExampleSets={this.props.updateExampleSets}
            activeIds={this.state.activeIds}
            activeIdsToAdd={this.state.activeIdsToAdd}
            updateActiveIds={this.updateActiveIds}
            updateActiveIdsToAdd={this.updateActiveIdsToAdd}
            updateClusterTopWords={this.props.updateClusterTopWords}
            updateClusterIds={this.props.updateClusterIds}
            data={this.props.data}
            selectedModel={this.props.selectedModel}
          />
        </Row> 
		  </>
		);
	}
}
