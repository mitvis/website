import React, { Component } from 'react';
import ProjectionPlotPlotly from './ProjectionPlotPlotly'
import TopWords from './TopWords'
import Legend from './Legend'
import { isEqual } from 'lodash';


var $;
$ = require('jquery');

export default class VizSection extends Component {
	constructor(props) {
    super(props);

    this.state = {
			idx: 500,
			currentExample: null,
    	};
  	}

  	shouldComponentUpdate(nextProps) {
	    return !isEqual(this.props, nextProps);
  	}


  	render() {
			return(
				<div>
					<div>
						{this.props.data ?
							<>
							<ProjectionPlotPlotly
								exampleSource={this.props.exampleSource}
								updateBrushedPoints={this.props.updateBrushedPoints}
								data_and_bounds={this.props.data} 
								expandedExSet={this.props.expandedExSet}
								expandedTest={this.props.expandedTest}
								expandedTestObject={this.props.expandedTestObject}
								exampleSets={this.props.exampleSets}
								clusterIds={this.props.clusterIds}
							/>
							<Legend 
								expandedTest={this.props.expandedTest}
								expandedTestObject={this.props.expandedTestObject}
							/>
							<TopWords 
								clusterTopWords={this.props.clusterTopWords}
								expandedExamples={this.props.expandedExSet ? this.props.exampleSets[this.props.expandedExSet].sentences : null}
								expandedLabel={this.props.expandedExSet ? this.props.exampleSets[this.props.expandedExSet].name : null}/>
							</>
							: <p>Loading ...</p>
						}

					</div>
				</div>
			);
  	}



	getExample(idx) {
		let example;
		$.getJSON('/api/getExample', {idx: JSON.stringify(idx)}, function(result) {
			example = result.example;
			this.setState({
				currentExample: example,
				idx: idx
      });
		}.bind(this));
	}
}
