import React, { PureComponent } from 'react';
import * as d3 from 'd3';
import {
  colors,
  relativeSimilarity,
  paired,
  sequentialColorScale,
  divergingColorScale,
  output, 
  distributional
} from '../constants.js';

export default class ProbHistogram extends PureComponent {
	constructor(props) {
    super(props);

    this.state = {
      x: null,
      y: null,
      data: null,
      brushedIds: new Set(),
      brushObject: null,
      margin: {top: 10, right: 170, bottom: 40, left: 35}
    }
  }

  componentDidMount() {
    let data = this.props.data;    
    this.setState({data: data}, this.plotData);

    // this.createAxes();
    // this.updatePoints();
  }

  componentDidUpdate(nextProps, nextState) {
    if (nextProps.data !== this.props.data) {
      d3.select(this.svg).selectAll('rect').remove()
      d3.select(this.svg).selectAll('.legend').remove()
      this.setState({
        data: this.props.data
      }, this.plotData);
    }
  }

  predToColor(prob) {
    let percent = prob*100;
    let colorQuantile = Math.floor(percent/20)*20/10;
    let colorIdx = 4 - Math.min(colorQuantile/2, 4);
    let color = divergingColorScale[colorIdx];
    return color;
  }

  predDiffToColor(predDiff) {
    let diffQuantile = Math.floor(Math.abs(predDiff) * 10) / 10;
    let diffIndex = diffQuantile*10;
    let color = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4];
    return color;
  }

  getBinColor(binMean, exSetIdx=0) {
    if (this.props.definedTest.granularity == paired) {
      return this.predDiffToColor(binMean)
    } else if (this.props.definedTest.type == output) {
      return this.predToColor(binMean)
    } else if (this.props.definedTest.granularity == distributional) {
      return colors[exSetIdx]
    }
  }


  plotData() {
    var xAxisLowerBound, xAxisUpperBound, xAxisLabelString, numExSets, exSetNames, thresholds;

    if (this.props.definedTest.granularity != paired) {
      xAxisLowerBound = 0;
      xAxisUpperBound = 1; 
      xAxisLabelString = "P(moderated)";
      numExSets = this.props.definedTest.exampleSets.length;
      exSetNames = this.props.definedTest.exampleSets;
      thresholds = 10
    } else {
      xAxisLowerBound = -1*this.props.xAxisBound
      xAxisUpperBound = this.props.xAxisBound
      xAxisLabelString = "Change in P(mod) post-transform"
      numExSets = 1
      exSetNames = [this.props.definedTest.exampleSet];
      thresholds = xAxisUpperBound*10*2
      let newMargin = this.state.margin
      newMargin.right = 60
      this.setState({ margin: newMargin })
    }

    let width = 400 - this.state.margin.left - this.state.margin.right;
    let height = 150 - this.state.margin.top - this.state.margin.bottom;
    
       
    var x = d3.scaleLinear()
      .domain([xAxisLowerBound, xAxisUpperBound]) 
      .range([this.state.margin.left, width + this.state.margin.left]);

    const xAxis = (g) => 
        g.attr("transform", "translate(0," + (height + this.state.margin.top) + ")")
        .call(d3.axisBottom(x).tickValues([xAxisLowerBound, (xAxisLowerBound+xAxisUpperBound)/2, xAxisUpperBound]).tickSizeOuter(0));

    d3.select(this.xAxis).call(xAxis);

    // set the parameters for the histogram
    var histogram = d3.histogram()
        .value(function(d) { return d.pred; })   // I need to give the vector of value
        .domain(x.domain())  // then the domain of the graphic
        .thresholds(thresholds); // then the numbers of bins

    // And apply this function to data to get the bins
    let bins = [];
    let binColors = []; 

    for (let i = 0; i < numExSets; i++) {
      bins.push(histogram(this.state.data.filter(d => d.exSet === exSetNames[i])));
    }

    // Y axis: scale and draw:
    var y = d3.scaleLinear()
              .range([height + this.state.margin.top, this.state.margin.top])
              .domain([0, d3.max(bins.flat(), function(d) { return d.length; })]);   // d3.hist has to be called before the Y axis obviously
        
    const yAxis = (g) => 
        g.attr("transform", "translate(" + this.state.margin.left + ",0)")
          .call(d3.axisLeft(y).tickValues([0, y.domain()[1]]).tickSizeOuter(0));
        
    d3.select(this.yAxis).call(yAxis);

    this.setState({
        x: x,
        y: y
    });

    d3.select(this.xAxisLabel) 
        .attr("class", "x label")
        .attr("text-anchor", "middle")
        .attr("x", this.state.margin.left + width/2 )
        .attr("y", height + this.state.margin.top + this.state.margin.bottom - 5)
        .style("font-size", "10pt")
        .text(xAxisLabelString);

    d3.select(this.yAxisLabel)
      .attr("transform", "rotate(-90)")
      .attr("y", 0)
      .attr("x",0 - (height / 2 + this.state.margin.top))
      .style("font-size", "10pt")
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .text("# examples"); 

    let binHeight = height + this.state.margin.top;

    for (let i = 0; i < numExSets; i++) {
      d3.select(this.chartArea)
        .selectAll('rect' + i.toString())
        .data(bins[i])
        .enter()
        .append("rect")
        .attr("x", 1)
        .attr("transform", function(d) { return "translate(" + x(d.x0) + "," + y(d.length) + ")"; })
        .attr("width", function(d) { return x(d.x1) - x(d.x0) - 1 ; })
        .attr("height", function(d) { return binHeight - y(d.length); })
        .style("fill", function(d) {return this.getBinColor((d.x1 + d.x0)/2.0, i)}.bind(this))
        .style("opacity", this.props.definedTest.granularity == distributional ? 0.6 : 0.9);
            
      if (this.props.showLegend) {
        d3.select(this.svg).append("circle").attr("cx", width + this.state.margin.left + 20).attr("cy",30 + 20*i).attr("r", 5).style("fill", colors[i]).style("opacity", .6).attr("class", "legend")
        d3.select(this.svg).append("text").attr("x", width + this.state.margin.left + 30).attr("y", 30 + 20*i).text(exSetNames[i]).style("font-size", "10pt").attr("alignment-baseline","middle").attr("class", "legend")
      }
    }

    // create the d3-brush generator
    const brush = d3.brushX()
          .extent([[this.state.margin.left, this.state.margin.top],[width + this.state.margin.left, height + this.state.margin.top]])
          .on('end', this.brushed.bind(this))

    this.setState({
      brushObject: brush
    });

    // attach the brush to the chart
    const gBrush = d3.select(this.brush)
      .attr('class', 'brush')
      .call(brush);
  }

  brushed(event) {
    const { selection } = event;
    let probBounds = [-1,1];
    if (selection) {
      probBounds = [this.state.x.invert(selection[0]), this.state.x.invert(selection[1])];
    }
    this.props.updateProbBounds(probBounds);
  }

  render() {
    return (
      <>
        <svg ref={(node) => {this.svg = node; }}
          className="histogram" 
          width={400} 
          height={150}
          style={{'marginBottom': '10px'}}>

          {/* Axes */}
          <g ref={(node) => {this.brush = node; }} />
          <g ref={(node) => { this.xAxis = node; }} />
          <g ref={(node) => { this.yAxis = node; }} />
          <text ref={(node) => { this.xAxisLabel = node;}} />
          <text ref={(node) => { this.yAxisLabel = node;}} />
          <g ref={(node) => { this.chartArea = node; }} />
        </svg>

        <div ref={(node) => { this.tooltip = node; }} />
      </>
    );
  }
}
