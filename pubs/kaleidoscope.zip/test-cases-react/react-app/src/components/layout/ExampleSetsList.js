import React, { Component } from 'react';
import ExampleSet from './ExampleSet';
import Accordion from 'react-bootstrap/Accordion';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

// var $;
// $ = require('jquery');

export default class ExampleSetsList extends Component {
  constructor(props) {
		super(props);

    this.state = {
      newExampleSetName: "",
      expandedExSet: null
		};
	}

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.exampleSource !== this.props.exampleSource) {
      if (this.props.exampleSource === "brushedIds") {
        this.updateActiveIds(new Set());
      }
    }
  }

  updateExampleSets(newExampleSets){
    this.props.updateExampleSets(newExampleSets);
  }

  addSentence(i, e) {
    e.preventDefault();
    let example = e.target[0].value;
    let exampleId = this.props.maxId + 1;

    this.props.exampleSets[i].sentences.push(example);
    this.props.exampleSets[i].exampleIds.push(exampleId);
    this.props.addExample(example, exampleId);
    e.target[0].value = "";

    this.updateExampleSets(this.props.exampleSets);
    // $.post('/api/addExample', {exampleString: JSON.stringify(example), exampleId: JSON.stringify(exampleId)}, function(result) {
    //     console.log("post complete", result)
    // })
  }

  editSentence(i0, i1, newSentence) {
    this.props.exampleSets[i0].sentences[i1] = newSentence;
    this.updateExampleSets(this.props.exampleSets);
  }

  changeActive(exampleId) {
    let newActiveIds = new Set(this.props.activeIds);
    if (newActiveIds.has(exampleId)) {
      newActiveIds.delete(exampleId);
    } else {
      newActiveIds.add(exampleId);
    }

    this.updateActiveIds(newActiveIds);
  }

  updateActiveIds = (newActiveIds) => {
    this.props.updateActiveIds(newActiveIds);
  }

  removeSentence(i0, e, i1) {
    e.preventDefault();
    let exampleId = this.props.exampleSets[i0].exampleIds[i1];
    this.props.exampleSets[i0].sentences.splice(i1, 1);
    this.props.exampleSets[i0].exampleIds.splice(i1, 1);
    this.updateExampleSets(this.props.exampleSets);
    let newActiveIds = new Set(this.props.activeIds);
    if (newActiveIds.has(exampleId)) {
      newActiveIds.delete(exampleId);
      this.updateActiveIds(newActiveIds);
    }
  }

  editExampleSet(i, newName) {
    if (!this.props.exampleSets.map((exampleSet) => exampleSet.name).includes(newName)) this.props.exampleSets[i].name = newName;
    this.updateExampleSets(this.props.exampleSets);
  }

  removeExampleSet(i, e) {
    e.stopPropagation();
    let newActiveIds = new Set(this.props.activeIds);
    for (let s = 0; s < this.props.exampleSets[i].exampleIds.length; s++) {
      if (newActiveIds.has(this.props.exampleSets[i].exampleIds[s])) {
        newActiveIds.delete(this.props.exampleSets[i].exampleIds[s]);
      }
    }
    // this.props.updateHoveringIds(this.props.exampleSets[i].exampleIds, this.props.exampleSets[i].sentences, "delete");
    this.updateActiveIds(newActiveIds);
    this.props.exampleSets.splice(i, 1);
    this.props.removeExpandedExSet(i, 'exSet')
    this.updateExampleSets(this.props.exampleSets);
  }

  addExampleSet(e) {
    e.preventDefault();
    if (this.state.newExampleSetName && !this.props.exampleSets.map((exampleSet) => exampleSet.name).includes(this.state.newExampleSetName)) {
      this.props.exampleSets.push({name: this.state.newExampleSetName, sentences: [], exampleIds: []});
      this.setState({
        newExampleSetName: ""
      });
      this.updateExampleSets(this.props.exampleSets);
    }
    e.target[0].value = "";
  }

  editAddExampleSet(e) {
    this.setState({
      newExampleSetName: e.target.value
    });
  }

  clearAllSelected = () => {
    this.updateActiveIds(new Set());
  }

  toggleSelected = (index) => {
    if (this.state.expandedExSet === index) {
      this.setState({
        expandedExSet: null
      });
    } else {
      this.setState({
        expandedExSet: index
      });
    }
  }

	render() {
    let exSetLength = this.props.exampleSets.length;

	  return (
      <>
        <Button className='selectButtonExSet clearAllSelected' variant="light" onClick={this.clearAllSelected}>
          <i>clear all selected</i>
        </Button>
        <Accordion defaultActiveKey={['0']} alwaysOpen>
          <Accordion.Item eventKey="0">
            <Accordion.Body>
              <Form onSubmit={(e) => this.addExampleSet(e)}>
                <Form.Control placeholder="Enter new example set..." type="text" onChange={(e) => this.editAddExampleSet(e)} />
              </Form>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <Accordion alwaysOpen={false}>
          {this.props.exampleSets.slice(0).reverse().map((exampleSet, i) => 
            <ExampleSet
              index={exSetLength - i - 1} 
              key={exampleSet.name} 
              name={exampleSet.name}
              exampleSet={exampleSet}
              activeIds={this.props.activeIds} 
              updateActiveIds={this.updateActiveIds}
              addSentence={e => this.addSentence(exSetLength - i - 1, e)} 
              removeSentence={(e, i1) => this.removeSentence(exSetLength - i - 1, e, i1)} 
              editSentence={(i1, newSentence) => this.editSentence(exSetLength - i - 1, i1, newSentence)}
              editExampleSet={newName => this.editExampleSet(exSetLength - i - 1, newName)}
              removeExampleSet={e => this.removeExampleSet(exSetLength - i - 1, e)}
              changeActive={exampleId => this.changeActive(exampleId)}
              // updateHoveringIds={(exampleIds, examples, mouseAction) => this.props.updateHoveringIds(exampleIds, examples, exampleSet.name, mouseAction)}
              toggleSelected={(index) => this.props.updateExpandedExSet(index, 'exSet')}
            />
          )}
        </Accordion>
      </>
	  );
	}
}
