import { useD3 } from '../hooks/useD3';
import React from 'react';
import * as d3 from 'd3';
import {
    colors,
    divergingColorScale,
    sequentialColorScale,
    output, 
    invariance,
    directionality,
    distributional,
    paired
} from '../constants.js';


export default class Legend extends React.PureComponent {
	constructor(props) {
        super(props);
        this.margin = {top: '10%', right: '10%', bottom: '10%', left: '10%'};
        this.width = 400 - this.margin.left - this.margin.right;
    	this.height = 40 - this.margin.top - this.margin.bottom;
    }


    componentDidUpdate(prevProps) {
    	d3.select(this.svg).selectAll('*').remove()
    	if (this.props.expandedTest) {
    		this.drawLegend()
    	} 
    }

    drawLegend() {
    	if (this.props.expandedTestObject.type == output || this.props.expandedTestObject.granularity == distributional) {
    		d3.select(this.svg)
			  .append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",'10px')
		    	  .attr("y","1em")
		    	  .style("font-size", "10pt")
		    	  .attr('transform', 'translate(15,0)')
		    	  .text("least")

		    d3.select(this.svg).append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",'10px')
		    	  .attr("y","2em")
		    	  .style("font-size", "10pt")
		    	  .text("moderated")

    		for (let i = 0; i < divergingColorScale.length; i++) {
    			d3.select(this.svg)
		    	  .append("circle")
		    	  .attr("cx", (32 + 10*i).toString() + '%')
		    	  .attr("cy",12).attr("r", "3%")
		    	  .style("fill", divergingColorScale[divergingColorScale.length - i - 1])
		    	  .style("opacity", 1)
    		}

    		d3.select(this.svg)
			  .append("text")
		    	  .attr("text-anchor", "end")
		    	  .attr("x", '100%')
		    	  .attr("y","1em")
		    	  .style("font-size", "10pt")
		    	  .attr('transform', 'translate(-15,0)')
		    	  .text("most")
		    d3.select(this.svg).append("text")
		    	  .attr("text-anchor", "end")
		    	  .attr("x", '100%')
		    	  .attr("y","2em")
		    	  .style("font-size", "10pt")
		    	  .text("moderated")

    	} 

    	if (this.props.expandedTestObject.granularity == distributional) {
    		var star = d3.symbol().type(d3.symbolStar).size(100);
    		var square = d3.symbol().type(d3.symbolSquare).size(100);
    		d3.select(this.secondSvg)
	    	  .append("path")
	    	  .attr("d", square)
	    	  .attr("transform", "translate(15, 10)")
	    	  .style("fill", 'steelblue')
	    	  .style("opacity", 1)
	    	d3.select(this.secondSvg)
	    	  .append("path")
	    	  .attr("d", star)
	    	  .attr("transform", "translate(15, 35)")
	    	  .style("fill", 'steelblue')
	    	  .style("opacity", 1)
	    	d3.select(this.secondSvg)
			  .append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",30)
		    	  .attr("y",15)
		    	  .style("font-size", "10pt")
		    	  .text(this.props.expandedTestObject.exampleSets[0])
		    d3.select(this.secondSvg).append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",30)
		    	  .attr("y",40)
		    	  .style("font-size", "10pt")
		    	  .text(this.props.expandedTestObject.exampleSets[1])
    	}

    	if (this.props.expandedTestObject.granularity == paired) {
    		d3.select(this.svg)
			  .append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",'10px')
		    	  .attr("y","1em")
		    	  .style("font-size", "10pt")
		    	  .text("smallest")
		    d3.select(this.svg).append("text")
		    	  .attr("text-anchor", "start")
		    	  .attr("x",'10px')
		    	  .attr("y","2em")
		    	  
		    	  .style("font-size", "10pt")
		    	  .text("change")

    		for (let i = 0; i < sequentialColorScale.length; i++) {
    			d3.select(this.svg)
		    	  .append("circle")
		    	  .attr("cx", (32 + 10*i).toString() + '%')
		    	  .attr("cy",12).attr("r", "3%")
		    	  .style("fill", sequentialColorScale[i])
		    	  .style("opacity", 1)
    		}

    		d3.select(this.svg)
			  .append("text")
		    	  .attr("text-anchor", "end")
		    	  .attr("x","100%")
		    	  .attr("y","1em")
		    	  .style("font-size", "10pt")
		    	  .attr('transform', 'translate(-1,0)')
		    	  .text("largest")
		    d3.select(this.svg).append("text")
		    	  .attr("text-anchor", "end")
		    	  .attr("x","100%")
		    	  .attr("y","2em")
		    	  .style("font-size", "10pt")
		    	  .text("change")
    	}


    }

    legendTitle() {
    	if (this.props.expandedTestObject.type == output || this.props.expandedTestObject.granularity == distributional) {
    		return "Probability of moderation"
    	} else {
    		return "Change in prob. of moderation after transformation"
    	}
    }

    secondLegendTitle() {
    	return "Example set"
    }

    render() {
    	return(
	    	this.props.expandedTest &&
	    		<>
	    		<span style={{'fontSize':'11pt', 'fontWeight': 'bold'}}>{this.legendTitle()}</span>
	    		<svg ref={(node) => {this.svg = node; }}
	                 width={'100%'} 
	                 height={40}
	                 style={{'marginBottom': '10px', 'marginTop': '10px'}}>
	            </svg>
	            {this.props.expandedTestObject.granularity == distributional &&
	            <>
	            <span style={{'fontSize':'11pt', 'fontWeight': 'bold'}}>{this.secondLegendTitle()}</span>
	            <svg ref={(node) => {this.secondSvg = node; }}
	                 width={'100%'} 
	                 height={50}
	                 style={{'marginBottom': '10px', 'marginTop': '10px'}}>
	            </svg>
	            </>
	        	}
	            </>
        )

    }

}
