import React, { Component } from 'react';
import SearchExploreSentence from './SearchExploreSentence.js';
import ListGroup from 'react-bootstrap/ListGroup';
import Button from 'react-bootstrap/Button';
import ButtonGroup from 'react-bootstrap/ButtonGroup';

export default class SearchExploreCluster extends Component {

	changeActive(exampleId) {
    let newActiveIdsToAdd = new Set(this.props.activeIdsToAdd);
    if (newActiveIdsToAdd.has(exampleId)) {
      newActiveIdsToAdd.delete(exampleId);
    } else {
      newActiveIdsToAdd.add(exampleId);
    }
    this.updateActiveIdsToAdd(newActiveIdsToAdd);
  }

  updateActiveIdsToAdd(newActiveIdsToAdd) {
    this.props.updateActiveIdsToAdd(newActiveIdsToAdd);
  }

  selectAllInCluster = () => {
    let newActiveIdsToAdd = new Set(this.props.activeIdsToAdd);
    for (let i = 0; i < this.props.exampleIds.length; i++) {
      if (!newActiveIdsToAdd.has(this.props.exampleIds[i]) && this.props.showExamples[i]) {
        newActiveIdsToAdd.add(this.props.exampleIds[i]);
      }
    }
    this.updateActiveIdsToAdd(newActiveIdsToAdd);
  }

  deselectAllInCluster = () => {
    let newActiveIdsToAdd = new Set(this.props.activeIdsToAdd)
    for (let i = 0; i < this.props.exampleIds.length; i++) {
      if (newActiveIdsToAdd.has(this.props.exampleIds[i])) {
        newActiveIdsToAdd.delete(this.props.exampleIds[i]);
      }
    }
    this.updateActiveIdsToAdd(newActiveIdsToAdd);
  }

	render() { 
		let sentencesAndIds = this.props.examples.map((x, i) => [x, this.props.exampleIds[i], this.props.showExamples[i]]);
    let showExampleNum = this.props.showExamples.filter(s => s === true).length;

    const exampleText = <>{this.props.exampleIds.length} examples</>;
    const showExampleNumText = <>{showExampleNum}/{this.props.exampleIds.length} examples</>;

		return (
			<>
				<div class="Aligner">
          <span class="Aligner-item" style={{'font-size': '10pt'}}><b style={{'color': this.props.clusterColor}}>Cluster {this.props.clusterId + 1} </b>
            ({showExampleNum === this.props.exampleIds.length ? exampleText : showExampleNumText})
          </span>
          <ButtonGroup class="Aligner-item" style={{'float': 'right', 'margin': '5px'}}>
            <Button onClick={this.selectAllInCluster} className='selectButton' variant="light">Select all</Button>
            <Button onClick={this.deselectAllInCluster} className='selectButton' variant="light">De-select all</Button>
          </ButtonGroup>
				</div>
				<ListGroup style={{'margin-bottom': '10px', 'padding-left': '10px', 'max-height': '20vh', 'overflow-y': 'scroll'}} >
          {sentencesAndIds.map(([sentence, exampleId, showExample], i) => 
            <SearchExploreSentence 
              sentence={sentence}
              exampleId={exampleId}
              showExample={showExample}
              changeActive={() => this.changeActive(exampleId)} 
              active={this.props.activeIdsToAdd.has(exampleId)}
              updateHoveringIds={(mouseAction) => this.props.updateHoveringIds(new Array([exampleId]), new Array([sentence]), "cluster", mouseAction)}
            />
          )}
        </ListGroup>
      </>
		);
	}
}
