import React, { Component } from 'react';
import Button from 'react-bootstrap/Button';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ListGroup from 'react-bootstrap/ListGroup';
import { Pencil, Trash, Check } from 'react-bootstrap-icons';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';

export default class ExampleSetSentence extends Component {
  constructor(props) {
    super(props);

    this.state = {
      active: false,
      editing: false,
      exampleId: null,
      newSentence: ""
    };
	}

  editSentence(e) {
    this.setState({
      newSentence: e.target.value
    });
  }

  startEditSentence(e) {
    e.stopPropagation();
    e.preventDefault();
    this.setState({
      editing: !this.state.editing
    });
  }

  endEditSentence() {
    this.props.editSentence(this.state.newSentence ? this.state.newSentence : this.props.sentence);
    this.setState({
      editing: !this.state.editing,
      newSentence: ""
    });
  }

	render() {
    const checkButton = (
      <Button className="iconButton" variant="light" onClick={() => this.endEditSentence()}>
        <Check />
      </Button>
    );

    const editButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.startEditSentence(e)}>
        <Pencil />
      </Button>
    );

    const trashButton = (
      <Button variant="light" className="iconButton" onClick={(e) => this.props.removeSentence(e)} >
        <Trash />
      </Button>
    );

		return (
      <ListGroup.Item style={{'wordBreak': 'break-word'}} active={this.props.active}>
        <Row>
          <Col sm={10} style={{display: 'flex', alignItems: 'center'}} onClick={() => this.props.changeActive()}>
            {this.state.editing ? (
              <ListGroup.Item>
                <Form onSubmit={() => this.endEditSentence()}>
                  <Form.Control type="text" defaultValue={this.props.sentence} onChange={(e) => this.editSentence(e)}/>
                </Form>
              </ListGroup.Item>
            ) : this.props.sentence}
          </Col>
          <Col sm={2}>
            <ButtonGroup>
              {this.state.editing ? checkButton : editButton}
              {trashButton}
            </ButtonGroup>
          </Col>
        </Row>
      </ListGroup.Item>
		);
	}
}
