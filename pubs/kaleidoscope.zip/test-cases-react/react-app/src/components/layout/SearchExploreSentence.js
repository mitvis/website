import React, { Component } from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';

export default class SearchExploreSentence extends Component {
    constructor(props) {
		super(props);

    this.state = {
      active: false,
    };
	}

  changeActive() {
    this.setState({active: !this.state.active});
  }

	render() {
    if (this.props.showExample) {
      return (
        <ListGroup.Item
          style={{'word-break': 'break-word'}}
          key={this.props.exampleId} 
          active={this.props.active} 
          onClick={() => this.props.changeActive()}>

          <Container>
            <Row style={{'font-size': '10pt'}}>
              {this.props.sentence}
            </Row>
          </Container>
        </ListGroup.Item>
      );
    } else {
      return null;
    }
	}
}
