import React, { Component } from 'react';
var $;
$ = require('jquery');

export default class TopWords extends Component {
	constructor(props) {
    super(props);

    this.state = {
      clusterTopWords: null,
      selectedTopWords: null
    }
    this.clusterColors = ["#f28e2b", "#e15759", "#76b7b2"];
  }

  // Whenever the component updates, select the <g> from the DOM, and use D3 to manipulte circles
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.expandedExamples !== this.props.expandedExamples) {
      if ((!this.props.expandedExamples) || (this.props.expandedExamples.size <= 1)) {
        this.setState({
          selectedTopWords: null
        });
      } else if (this.props.expandedLabel !== "cluster") {
        this.updateTopWords(this.props.expandedExamples);
      }
    }
  }

  updateTopWords(allExamples) {
    $.post('/api/getTopWords', {allExamples: JSON.stringify(Array.from(allExamples))}, function(result) {
      console.log(result)
      this.setState({
        selectedTopWords: result['topWords']
      })
    }.bind(this));
  }

  getTopWordsString(topWordsDict) {
    let filteredWords = topWordsDict.filter((w) => w.count > 1);
    let formattedTopWords = filteredWords.map((w) => (<>{w.word}  <span style={{'color': 'rgb(200,200,200)'}}>({w.count.toString()})</span></>));
                                         
    if (formattedTopWords.length > 0) {
      formattedTopWords = formattedTopWords.reduce((prev, curr) => [prev, ', ', curr]);
    } else {
      formattedTopWords = (<span style={{'color': 'grey'}}><i>too few examples to calculate top words</i></span>);
    }
                                         
    return formattedTopWords;
  }

  selectedTopWordsSection() {
    return (
      <div className="topWords">
        <b><i style={{'color':'#4e79a7'}}>{this.props.expandedLabel}:</i></b> {this.getTopWordsString(this.state.selectedTopWords)}
        <br></br>
      </div>
    );
  }

  clusterTopWordsSection() {
    return (
      <>
        {[0,1,2].map(i => 
          <div className="topWords">
            <b><i style={{"color": this.clusterColors[i]}}>cluster {i + 1}:</i></b> {this.getTopWordsString(this.props.clusterTopWords[i])}
            <br></br>
          </div>
        )}
      </>
    );
  }

	render() {
    return (
      <div style={{ "marginTop": "10px", "fontSize": "12pt" }}>
        {(this.state.selectedTopWords || this.props.clusterTopWords) ? <div><b>Top words</b></div> : <></> }
        {this.state.selectedTopWords ? this.selectedTopWordsSection() : <></>}
        {this.props.clusterTopWords ? this.clusterTopWordsSection() : <></>}
      </div>
    );
  }
 
}

