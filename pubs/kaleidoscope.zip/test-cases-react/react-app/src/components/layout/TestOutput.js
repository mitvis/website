import React, { PureComponent, Component } from 'react';
import ProbHistogram from './ProbHistogram';
import ConfusionMatrix from './ConfusionMatrix';
import Accordion from 'react-bootstrap/Accordion';
import ListGroup from 'react-bootstrap/ListGroup';
import Badge from 'react-bootstrap/Badge';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { ArrowDown } from 'react-bootstrap-icons';


import {
  epsilon,
  pcutoff,
  output,
  invariance,
  directionality,
  relativeSimilarity,
  distributional,
  paired,
  colors,
  colorsRGB,
  sequentialColorScale,
  divergingColorScale
} from '../constants.js';


export default class TestOutput extends Component {
  
  constructor(props) {
    super(props);

    this.state = {
      colors: colorsRGB, 
      probBounds: [-1,1],
      selectedConfusionMatrixTypes: new Set()
    };

  }

  updateProbBounds = (newBounds) => {
    this.setState({
      probBounds: newBounds
    });
  }

  updateSelectedCmTypes = (newTypes) => {
    this.setState({
      selectedConfusionMatrixTypes: newTypes
    });
  }

  sortPairedData() {
    let exSetJSON = [];
    let confusionMatrixTypeArr = this.computeConfusionMatrix();

    for (let i = 0; i < this.props.definedTest.transformedExamples[0].length; i++) {
      let newItem = {
        'example': this.props.definedTest.transformedExamples[0][i],
        'pred': this.props.definedTest.preds[0][i],
        'transformedExample': this.props.definedTest.transformedExamples[1][i],
        'transformedExamplePred': this.props.definedTest.preds[1][i],
        'confusionMatrixType': confusionMatrixTypeArr[i]
      }
      exSetJSON.push(newItem);
    }
    return this.sortHelper(exSetJSON);
  }

  sortHelper(predsObj) {
    predsObj.sort(function(a, b) {
      return ((a.pred < b.pred) ? -1 : ((a.pred === b.pred) ? 0 : 1));
    });
    return predsObj;
  }

  sortHelperPaired(predsObj) {
    predsObj.sort(function(a, b) {
      return ((Math.abs(a.pred) < Math.abs(b.pred)) ? -1 : ((Math.abs(a.pred) === Math.abs(b.pred)) ? 0 : 1));
    });
    return predsObj;
  }

  sortSentencesByPreds(sentences, preds) {
    let predsObj = [];
    
    for (let i = 0; i < preds.length; i++) {
      predsObj.push({
        'example': sentences[i],
        'pred': preds[i]
      });
    }
    return this.sortHelper(predsObj);
  }

  filterSentencesByPreds(sentences, preds, passed) {
    if (passed) {
      return this.sortSentencesByPreds(sentences, preds).filter((predsObj) => predsObj.pred > 0.5).reverse();
    } else {
      return this.sortSentencesByPreds(sentences, preds).filter((predsObj) => predsObj.pred <= 0.5);
    }
  }

  getPassedExamplesAndPreds() {
    if (this.props.definedTest.type === output) {
      let allExampleSets = JSON.parse(localStorage.getItem('exampleSets'));
      let testExampleSetSentences = allExampleSets.filter(exSet => exSet['name'] === this.props.definedTest.exampleSets[0])[0].sentences;
      let testExampleSetPreds = this.props.definedTest.preds;
      return this.filterSentencesByPreds(testExampleSetSentences, testExampleSetPreds, true);
    }
  }

  getFailedExamplesAndPreds() {
    if (this.props.definedTest.type === output) {
      let allExampleSets = JSON.parse(localStorage.getItem('exampleSets'));
      let testExampleSetSentences = allExampleSets.filter(exSet => exSet['name'] === this.props.definedTest.exampleSets[0])[0].sentences;
      let testExampleSetPreds = this.props.definedTest.preds;
      return this.filterSentencesByPreds(testExampleSetSentences, testExampleSetPreds, false);
    }
  }

  getAllExamplesAndPreds() {
    let allExampleSets = JSON.parse(localStorage.getItem('exampleSets'));
    let testExampleSetSentences = allExampleSets.filter(exSet => exSet['name'] === this.props.definedTest.exampleSets[0])[0].sentences;
    let testExampleSetPreds = this.props.definedTest.preds;
    return this.sortSentencesByPreds(testExampleSetSentences, testExampleSetPreds);
  }

  testsOutput(tests, msg, i) {
    return (
      <Accordion>
        <Accordion.Item eventKey={i}>
          <Accordion.Header>
            <Container>
              <Row>{tests.length} {msg}</Row>
            </Container>
          </Accordion.Header>
          <Accordion.Body>
            <ListGroup style={{'maxHeight': '30vh', 'overflowY': 'scroll', 'overflowX': 'hidden'}}>
              {this.headerRow()}
              {tests.map((example, i) =>
                <OutputSentence
                  idx={i}
                  example={example}
                  color={example.pred < 0.5 ? "danger" : "success"}
                  testType={this.props.definedTest.type}
                />
              )}
            </ListGroup>
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>
    );
  }

  probToColor(prob) {
    let percent = prob*100;
    let colorQuantile = Math.floor(percent/20)*20/10;
    let colorIdx = 4 - Math.min(colorQuantile/2, 4);
    let color = divergingColorScale[colorIdx];
    return color;
  }

  predDiffToColor(predDiff) {
    let diffQuantile = Math.round(Math.abs(predDiff) * 10) / 10 
    let diffIndex = diffQuantile*10
    let color = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4]
    return color;
  }

  testsOutputPaired(tests) {

    return (
      <>
      {this.headerRow()}
      <ListGroup style={{'maxHeight': '30vh', 'overflowY': 'scroll', 'overflowX': 'hidden'}}>
        {tests.map((example) =>
          ((example.pred >= this.state.probBounds[0]) & (example.pred <= this.state.probBounds[1])) ?
          <PairedOutputSentences
              backgroundColor={this.state.colors[0]}
              example={{'example': example.examples, 'predDiff': example.pred, 'preds': example.individualPreds}}
              predDiffBadgeColor={this.predDiffToColor(example.pred)}
              predBadgeColors={[this.probToColor(example.individualPreds[0]), this.probToColor(example.individualPreds[1])]}
              testType={this.props.definedTest.type}
            />  : <></>
        )}
      </ListGroup>
      </>
    );
  }

  testsOutputAll(tests) {
    let exSetNames = [];

    if (this.props.definedTest.granularity === paired) {
      exSetNames = [this.props.definedTest.exampleSet, this.props.definedTest.exampleSet + " + 1st TF", this.props.definedTest.exampleSet + " + 2nd TF"];
    } else {
      exSetNames = this.props.definedTest.exampleSets;
    }

    return (
      <>
        {this.headerRow()}
        <ListGroup style={{'maxHeight': '30vh', 'overflowY': 'scroll', 'overflowX': 'hidden'}}>
          {tests.map((example) =>
            ((example.pred >= this.state.probBounds[0]) & (example.pred <= this.state.probBounds[1])) ?
            <OutputSentence
              backgroundColor={this.state.colors[exSetNames.indexOf(example.exSet)]}
              example={example}
              badgeColor={this.probToColor(example.pred)}
              testType={this.props.definedTest.type}
            /> : <></>
          )}
        </ListGroup>
      </>
    );
  }

  headerRow() {
    console.log("header row", this.props.definedTest.type, this.props.definedTest.type == paired)
    return (
      <Row style={{'fontSize': '10pt'}}>
        <Col sm={4} style={{display: 'flex', alignItems: 'center'}}>
          <Badge bg="secondary">{this.props.definedTest.granularity == paired ? 
                                  "change in p(mod)"
                                 : "p(moderated)"}
          </Badge>
        </Col>
        <Col sm={8}>
          <i>Example</i>
        </Col>
      </Row>
    );
  }

  passedTestsOutput() {
    const passedTests = this.getPassedExamplesAndPreds();
    return this.testsOutput(passedTests, "Passed (p > 0.5)", "1");
  }

  failedTestsOutput() {
    const failedTests = this.getFailedExamplesAndPreds();
    return this.testsOutput(failedTests, "Failed (p < 0.5)", "2");
  }

  transformedExamplesOutput() {
    let exSetName = this.props.definedTest.exampleSet;
    let exSetLength = this.props.exampleSets.filter(exampleSet => exampleSet.name === exSetName)[0].sentences.length;
    let transformedExamplesLength = this.props.definedTest.transformedExamples[0].length;
    return (
      <>
      The transformation {this.props.definedTest.type === relativeSimilarity ? "s " : <></>} 
      applied to <b>{transformedExamplesLength.toString()}</b> out of <b>{exSetLength.toString()}</b> examples.
      </>
    );
  }

  getDataForHistogramPaired() {
    let exampleSetNames = [this.props.definedTest.exampleSet]
    let exampleSetSentences = [this.props.definedTest.transformedExamples[0], this.props.definedTest.transformedExamples[1]]
    let preds = [this.props.definedTest.preds[0], this.props.definedTest.preds[1]]
    let predDiffs = this.props.definedTest.preds[0].map((p, i) => this.props.definedTest.preds[1][i] - p)
    let xAxisBound = Math.ceil(Math.max(...predDiffs.map((p) => Math.abs(p))) * 10)/10

    let exampleJSON = []
    for (let i = 0; i < predDiffs.length; i++) {
        let newItem = {
          'exSet': exampleSetNames[0],
          'examples': [exampleSetSentences[0][i], exampleSetSentences[1][i]],
          'pred': predDiffs[i],
          'individualPreds': [preds[0][i], preds[1][i]]
        }
        exampleJSON.push(newItem);
    }
    console.log(exampleJSON, xAxisBound)
    return [exampleJSON, xAxisBound];
 
  }

  computeConfusionMatrix() {
    let preTransformProbs = this.props.definedTest.preds[0];
    let postTransformProbs = this.props.definedTest.preds[1];
    let confusionMatrixTypeArr = new Array(preTransformProbs.length);

    for (let i = 0; i < preTransformProbs.length; i++) {
      if (preTransformProbs[i] >= 0.5) {
        if (postTransformProbs[i] >= 0.5) {
          confusionMatrixTypeArr[i] = 1;
        } else {
          confusionMatrixTypeArr[i] = 2;
        }
      } else {
        if (postTransformProbs[i] >= 0.5) {
          confusionMatrixTypeArr[i] = 3;
        } else {
          confusionMatrixTypeArr[i] = 4;
        }
      }
    }
    return confusionMatrixTypeArr;
  }

  getOccurences(arr) {
    const occurrences = arr.reduce(function (acc, curr) {
      acc[curr] ? ++acc[curr] : acc[curr] = 1
      return acc;
    }, {});

    for (let i = 1; i <= 4; i++) {
      if (!occurrences[i]) {
        occurrences[i] = 0;
      }
    }
    return occurrences;
  }

  getDataForHistogram() {
    let exampleSetNames = this.props.definedTest.exampleSets;
    let allExampleSets = this.props.exampleSets;
    let exampleSetSentences = exampleSetNames.map(exSetName => allExampleSets.filter(exampleSet => exampleSet.name === exSetName)[0].sentences);

    let exampleJSON = [];
    for (let i = 0; i < exampleSetNames.length; i++) {
      for (let j = 0; j < exampleSetSentences[i].length; j++) {
        let newItem = {
          'exSet': exampleSetNames[i],
          'example': exampleSetSentences[i][j],
          'pred': this.props.definedTest.type === output ? this.props.definedTest.preds[j] : this.props.definedTest.preds[i][j]
        }
        exampleJSON.push(newItem);
      }
    }
    return exampleJSON;
  }

  getResultString() {
    if (this.props.definedTest.type === directionality) {
      return this.getDirectionalityResultString()
    } else if  (this.props.definedTest.type === invariance) {
      return this.getInvarianceResultString()
    } else {
      this.getOutputResultString()
    }
  }

  getOutputResultString() {
    return this.props.definedTest.result
  }

  getInvarianceResultString() {
    let res_string = ""
    let diffQuantile = Math.round(Math.abs(this.props.definedTest.meanDiff) * 10) / 10 
    let diffIndex = diffQuantile*10
    let textColor = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4]

   
    if (this.props.definedTest.granularity === distributional) {
      let beginning = (<>You specified that the predicted probability of moderation should be the same between examples in <span className="resultExSetText" style={{'color': colors[0]}}>{this.props.definedTest.exampleSets[0]}</span> and <span className="resultExSetText" style={{'color': colors[1]}}>{this.props.definedTest.exampleSets[1]}</span></>)
      if ((this.props.definedTest.pval >= pcutoff) || (Math.abs(this.props.definedTest.meanDiff) <= epsilon)) {
        res_string = (<span>{beginning}, and <b><span style={{'color':textColor}}>it is the same on average</span></b>.</span>)
      } else {
        res_string = (<span>{beginning}. However, the probability of moderation for <span className="resultExSetText" style={{'color': colors[1]}}>{this.props.definedTest.exampleSets[1]}</span> is actually <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.meanDiff > 0 ? "higher" : "lower"}</span></b> on average.</span> )
      }
    } else {
      let beginning = (<>You specified that the predicted probability of moderation should be the same after applying the transformation(s) to examples in <span className="resultExSetText" style={{'color': colors[0]}}>{this.props.definedTest.exampleSet}</span></>)
      if ((this.props.definedTest.pval >= pcutoff) || (Math.abs(this.props.definedTest.meanDiff) <= epsilon)) {
        res_string = (<span>{beginning}, and <b><span style={{'color':textColor}}>it is the same on average</span></b>.</span>)
      } else {
        res_string = (<span>{beginning}. However, post-transformation, the probability of moderation is actually <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.meanDiff > 0 ? "higher" : "lower"}</span></b> on average.</span> )
      }
    }
    return res_string
  }

  getDirectionalityResultString() {
    let res_string = ""
    let diffQuantile = Math.round(Math.abs(this.props.definedTest.meanDiff) * 10) / 10 
    let diffIndex = diffQuantile*10
    let textColor = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4]


    if (this.props.definedTest.granularity === distributional) {
      let beginning = (<>You specified that the examples in <span className="resultExSetText" style={{'color': colors[1]}}>{this.props.definedTest.exampleSets[1]}</span> should be {this.props.definedTest.directionality === 'Higher' ? 'more' : 'less'} likely to be moderated than <span className="resultExSetText" style={{'color': colors[0]}}>{this.props.definedTest.exampleSets[0]}</span></>)

      if ((this.props.definedTest.pval >= pcutoff) || (Math.abs(this.props.definedTest.meanDiff) <= epsilon)) {
        res_string = (<span>{beginning}, but there’s actually <span style={{'color':textColor, 'fontWeight':'bold'}}>no significant difference in moderation</span> between the two.</span>)
      } else {
        let meanDiffDirection = this.props.definedTest.meanDiff > 0 ? "Higher" : "Lower"
        if (meanDiffDirection === this.props.definedTest.directionality) {
          res_string = (<span>{beginning}, and the probability of moderation is indeed <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.directionality === 'Higher' ? 'higher' : 'lower'}</span></b>  on average.</span>)
        } else {
          res_string = (<span>{beginning}. However, the probability of moderation for <span className="resultExSetText" style={{'color': colors[1]}}>{this.props.definedTest.exampleSets[1]}</span> is actually <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.directionality === 'Higher' ? 'higher' : 'lower'}</span></b> on average.</span>)
        }
      }
    } else if (this.props.definedTest.granularity === paired) {
      let beginning = (<>You specified that after applying the transformation(s), examples in <span className="resultExSetText">{this.props.definedTest.exampleSet}</span> should be {this.props.definedTest.directionality === 'Higher' ? 'more' : 'less'} likely to be moderated.</>)

      if ((this.props.definedTest.pval >= pcutoff) || (Math.abs(this.props.definedTest.meanDiff) <= epsilon)) {
        res_string = (<span>{beginning}. However, post-transformation, there’s actually <span style={{'color':textColor, 'textStyle':'bold'}}>no significant difference in moderation</span>.</span>)
      } else {
        let meanDiffDirection = this.props.definedTest.meanDiff > 0 ? "Higher" : "Lower"
        if (meanDiffDirection === this.props.definedTest.directionality) {
          res_string = (<span>{beginning}. Post-transformation, the probability of moderation is indeed <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.directionality === 'Higher' ? 'higher' : 'lower'}</span></b> on average.</span>)
        } else {
          res_string = (<span>{beginning}. However, post-transformation, the probability of moderation is actually <b><span style={{'color':textColor}}>{(Math.abs(this.props.definedTest.meanDiff*100)).toFixed(1)}% {this.props.definedTest.directionality === 'Higher' ? 'higher' : 'lower'}</span></b> on average.</span>)
        }
      }
    }

    return res_string;
  }
  
  render() {
    if (!this.props.definedTest.result) {
      return <></>;
    } else if (this.props.definedTest.deactivated) {
      if ((this.props.definedTest.deactivationSource === "noTransformation")) {
        return (
          <span style={{'fontStyle': 'italic'}} className="resultTextSpan">
            The transformation did not apply to any of the examples. Try changing the transformation function.
          </span>
        );
      } else if (this.props.definedTest.deactivationSource === "exSetMissing") {
        return (
          <span style={{'fontStyle': 'italic'}} className="resultTextSpan">
            This test relies on example sets that no longer exist.
          </span>
        );
      } else {
        return <></>;
      }
    } else {
      if (this.props.definedTest.type === output | this.props.definedTest.granularity === distributional) {
        let histData = this.getDataForHistogram();
        const showLegend = this.props.definedTest.granularity === distributional;

        return(
          <>
            <span className="resultTextSpan">
              {this.getResultString()}
            </span>
            <ProbHistogram 
              data={histData}
              definedTest={this.props.definedTest}
              showLegend={showLegend}
              updateProbBounds={this.updateProbBounds}
            />
            {this.testsOutputAll(this.sortHelper(histData))}
          </>
        );
      } else {
        let pairedData = this.sortPairedData();
        let [histData, xAxisBound] = this.getDataForHistogramPaired();
        console.log(histData, xAxisBound) 
        return (
          <>
            <span className="resultTextSpan">
              {this.transformedExamplesOutput()}
            </span>

            <span className="resultTextSpan">
              {this.getResultString()}
            </span>

            <ProbHistogram 
              data={histData}
              xAxisBound={xAxisBound}
              definedTest={this.props.definedTest}
              showLegend={false}
              updateProbBounds={this.updateProbBounds}
            />
          
           {/*
            <ConfusionMatrix 
              colors={this.state.colors}
              cmOccurences={this.getOccurences(this.computeConfusionMatrix())}
              updateSelectedCmTypes={this.updateSelectedCmTypes}
              selectedConfusionMatrixTypes={this.state.selectedConfusionMatrixTypes}
            />
           */}
            {this.testsOutputPaired(this.sortHelper(histData))}
          </>
        );
      }
    }
  }
}

class OutputSentence extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  getBackgroundColor() {
    if (this.props.testType === output) {
      return "";
    } else {
      return this.colorToRGBA();
    }
  }

  colorToRGBA() {
    let rgb = this.props.backgroundColor;
    let opacity = 0.4;
    return `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${opacity})`;
  }

  render() {
    return (
      <ListGroup.Item key={this.props.idx} style={{'wordBreak': 'break-word', 'backgroundColor': this.getBackgroundColor()}}>
        <Row style={{'fontSize': '10pt'}}>
          <Col sm={3} style={{display: 'flex', alignItems: 'center', 'justifyContent': 'center'}}>
            <Badge bg="custom-button" style={{backgroundColor: this.props.badgeColor}}>{this.props.example.pred.toFixed(2)}</Badge>
          </Col>
          <Col sm={9}>
            {this.props.example.example}
          </Col>
        </Row>
      </ListGroup.Item>
    );
  }
}

class PairedOutputSentences extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }

  getBackgroundColor() {
    return this.colorToRGBA();
  }

  colorToRGBA() {
    let rgb = this.props.backgroundColor;
    let opacity = 0.4;
    return `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${opacity})`;
  }

  render() {
    return (
      <ListGroup.Item key={this.props.idx} style={{'wordBreak': 'break-word'}}>
        <Row style={{'fontSize': '10pt'}}>
          <Col sm={2} style={{display: 'flex', alignItems: 'center', 'justifyContent': 'center'}}>
            <Badge bg="custom-button" style={{backgroundColor: this.props.predDiffBadgeColor}}>{this.props.example.predDiff.toFixed(2)}</Badge>
          </Col>
          <Col sm={10}>
            <Row>
              <Col sm={2} className='align-self-center' style={{'paddingLeft': '0'}}><Badge bg="custom-button" style={{backgroundColor: this.props.predBadgeColors[0]}}>{this.props.example.preds[0].toFixed(2)}</Badge></Col>
              <Col sm={10}>{this.props.example.example[0]}</Col>
            </Row>
            <Row><Col sm={3}><ArrowDown /></Col></Row>
            <Row>
              <Col sm={2} className='align-self-center' style={{'paddingLeft': '0'}}><Badge bg="custom-button" style={{backgroundColor: this.props.predBadgeColors[1]}}>{this.props.example.preds[1].toFixed(2)}</Badge></Col>
              <Col sm={10}>{this.props.example.example[1]}</Col>
             </Row>
          </Col>
        </Row>
      </ListGroup.Item>
    );
  }
}

