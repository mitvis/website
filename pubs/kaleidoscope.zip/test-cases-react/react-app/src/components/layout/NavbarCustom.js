import React, { Component } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';

export default class NavbarCustom extends Component {
	render() {
		return (
			<Navbar bg="light">
        <Container className="container-left-margin">
          <Navbar.Brand href="#home">Testing ML Models</Navbar.Brand>
        </Container>
      </Navbar>
    );
	}
}
