import React, { Component } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import Button from 'react-bootstrap/Button';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import ListGroup from 'react-bootstrap/ListGroup';
import ExampleSetSentence from './ExampleSetSentence';
import { Pencil, Trash, Check } from 'react-bootstrap-icons';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';


export default class ExampleSet extends Component {
  constructor(props) {
  super(props);
    this.state = {
      editing: false,
      newName: "",
    };
	}

  editExampleSet(e) {
    e.stopPropagation();
    this.setState({newName: e.target.value});
  }

  startEditExampleSet(e) {
    e.stopPropagation();
    e.preventDefault();
    this.setState({editing: true});
  }

  endEditExampleSet(e) {
    e.stopPropagation();
    this.props.editExampleSet(this.state.newName ? this.state.newName : this.props.exampleSet.name);
    this.setState({editing: false, newName: ""});
  }

  deselectAllInExSet = () => { 
    let newActiveIds = new Set(this.props.activeIds);
    [...this.props.exampleSet.exampleIds].forEach(function(v) {
      newActiveIds.delete(v); 
    });
    this.props.updateActiveIds(newActiveIds);
  }

  selectAllInExSet = () => { 
    let newActiveIds = new Set(this.props.activeIds);
    [...this.props.exampleSet.exampleIds].forEach(function(v) {
      newActiveIds.add(v); 
    });
    this.props.updateActiveIds(newActiveIds);
  }

	render() {
    let sentencesAndIds = this.props.exampleSet.sentences.map((x, i) => [x, this.props.exampleSet.exampleIds[i]]);
    let numExamples = this.props.exampleSet.sentences.length;
    let hasActiveExamples = false;
    let numActiveExamples = 0;

    for (let i = 0; i < this.props.exampleSet.exampleIds.length; i++) {
      if (this.props.activeIds.has(this.props.exampleSet.exampleIds[i])) {
        hasActiveExamples = true;
        numActiveExamples += 1;
      }
    }

    const checkButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.endEditExampleSet(e)}>
        <Check />
      </Button>
    );

    const editButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.startEditExampleSet(e)}>
        <Pencil />
      </Button>
    );

    const trashButton = (
      <Button className="iconButton" variant="light" onClick={(e) => this.props.removeExampleSet(e)}>
        <Trash />
      </Button>
    );

    const selectedText = this.props.exampleSet.name + " (" + numActiveExamples + "/" + this.props.exampleSet.exampleIds.length + " selected)";
    const defaultText = this.props.exampleSet.name + " (" + this.props.exampleSet.exampleIds.length + " examples)";

		return (
      <Accordion.Item eventKey={this.props.index} style={{'fontSize': '10pt'}}>
        <Accordion.Header onClick={() => this.props.toggleSelected(this.props.index)}>
            <Container>
              <Row>
                <Col sm={9} style={{display: 'flex', alignItems: 'center'}}>
                  {this.state.editing ? 
                    <ListGroup.Item>
                      <Form onSubmit={(e) => this.endEditExampleSet(e)}>
                        <Form.Control
                          type="text"
                          defaultValue={this.props.exampleSet.name}
                          onChange={(e) => this.editExampleSet(e)}/>
                      </Form>
                    </ListGroup.Item> :
                    hasActiveExamples ? selectedText : defaultText
                  }
                </Col>
                <Col sm={3}>
                  <ButtonGroup>
                    {this.state.editing ? checkButton : editButton}
                    {trashButton}
                  </ButtonGroup>
                </Col>
              </Row>
            </Container>
          </Accordion.Header>
          <Accordion.Body>
            <ButtonGroup className="Aligner-item" style={{'marginBottom': '5px'}}>
              <Button onClick={this.selectAllInExSet} className='selectButtonExSet' variant="light">
                  Select all
              </Button>
              
              <Button onClick={this.deselectAllInExSet} className='selectButtonExSet' variant="light">
                  De-select all
              </Button>
            </ButtonGroup>

            <ListGroup style={{'maxHeight': '30vh', 'overflowY': 'scroll', 'overflowX': 'hidden'}}>
              <ListGroup.Item>
                <Form onSubmit={(e) => this.props.addSentence(e)}>
                  <Form.Control type="text" placeholder="Enter new sentence" />
                </Form>
              </ListGroup.Item>
              {sentencesAndIds.slice(0).reverse().map(([sentence, exampleId], i) =>
                <ExampleSetSentence
                  key={sentence}
                  sentence={sentence}
                  exampleId={exampleId}
                  active={this.props.activeIds.has(exampleId)}
                  editSentence={(newSentence) => this.props.editSentence(numExamples - i - 1, newSentence)}
                  removeSentence={(e) => this.props.removeSentence(e, numExamples - i - 1)}
                  changeActive={() => this.props.changeActive(exampleId)}
                />
              )}
            </ListGroup>
          </Accordion.Body>
      </Accordion.Item>
		);
	}
}
