import React, { Component } from 'react';
import Form from 'react-bootstrap/Form';

export default class SearchExploreForm extends Component {

	render() {
    let placeholderString = this.props.function === "searchAll" ? "Search all examples..." : "Filter examples...";
		return (
      <Form style={{'marginTop': '10px'}} onSubmit={(e) => this.props.search(e)}>
        <Form.Control placeholder={placeholderString} />
      </Form>
    );
	}
}
