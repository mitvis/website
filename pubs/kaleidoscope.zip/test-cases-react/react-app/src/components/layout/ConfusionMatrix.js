import React, { PureComponent } from 'react';

export default class ConfusionMatrix extends PureComponent {

  colorToRGBA(rgb, opacity) {
    return "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + opacity + ")";
  }

  setSelected(event) {
    event.target.classList.toggle("selected");
    let newTypes = this.props.selectedConfusionMatrixTypes;
    let selectedType = parseInt(event.target.getAttribute("cmType"));

    if (newTypes.has(selectedType)) {
      newTypes.delete(selectedType);
    } else {
      newTypes.add(selectedType);
    }

    this.props.updateSelectedCmTypes(newTypes);
  }


  render() {
    return (
			<table style={{'marginBottom': '20px'}}>
			  <tr>
			    <td colspan="2" rowspan="2"><i>model classifications <br></br> (cutoff = 0.5)</i></td>
          <td style={{'background':this.colorToRGBA(this.props.colors[1],0.4)}} colspan="2">Post-transform</td>
			  </tr>
			  <tr>
			    <td style={{'background':this.colorToRGBA(this.props.colors[1],0.3)}}> mod </td>
			    <td style={{'background':this.colorToRGBA(this.props.colors[1],0.2)}}>unmod</td>
			  </tr>
			  <tr>
			  	<td rowspan="2" style={{'background':this.colorToRGBA(this.props.colors[0],0.4)}}>Pre-transform</td>
			    <td style={{'background':this.colorToRGBA(this.props.colors[0],0.3)}}> mod </td>
			    <td cmType="1" className="cell" onClick={this.setSelected.bind(this)} style={{'borderRight': '1px solid grey', 'borderBottom': '1px solid grey'}}>{this.props.cmOccurences[1]}</td>
			    <td cmType="2" className="cell" onClick={this.setSelected.bind(this)}>{this.props.cmOccurences[2]}</td>
			  </tr>
			  <tr>
			  	<td style={{'background':this.colorToRGBA(this.props.colors[0],0.2)}}>unmod</td>
			    <td cmType="3" className="cell" onClick={this.setSelected.bind(this)}>{this.props.cmOccurences[3]}</td>
			    <td cmType="4" className="cell" onClick={this.setSelected.bind(this)} style={{'borderLeft': '1px solid grey', 'borderTop': '1px solid grey'}}>{this.props.cmOccurences[4]}</td>
			  </tr>
			</table>
    );
  }
}
