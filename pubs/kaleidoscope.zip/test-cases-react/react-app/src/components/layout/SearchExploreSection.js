import React, { Component } from 'react';
import SearchExploreCluster from './SearchExploreCluster.js';
import Dropdown from 'react-bootstrap/Dropdown';
import SearchExploreForm from './SearchExploreForm.js';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

var $;
$ = require('jquery');

export default class SearchExploreSection extends Component {
	constructor(props) {
		super(props);
		this.state = {
			clusterSentences: {
        0: {'sentences': [], 'exampleIds': [], 'showExample': []}, 
        1: {'sentences': [], 'exampleIds': [], 'showExample': []},  
        2: {'sentences': [], 'exampleIds': [], 'showExample': []}
			},
			searchQuery: "",
			checked: [1, 1],
			range: [0, 1],
			exampleSource: null,
			newExampleSetName: "",
		}
		this.clusterColors = ["#f28e2b", "#e15759", "#76b7b2"];
	}

	componentDidUpdate(prevProps, prevState) {
		const areSetsEqual = (a, b) => a.size === b.size && [...a].every(value => b.has(value));

		if (!areSetsEqual(prevProps.activeIds, this.props.activeIds)) { // if selected example set sentences change
			if (this.props.activeIds.size > 0) {
				this.populateWithActiveIds();
				this.props.updateExampleSource("activeIds");
				this.props.updateActiveIdsToAdd(new Set());
			} else if (this.props.brushedIds.size === 0) {
        		this.clearAllExamples();
			}
		} else if ((prevState.searchQuery !== this.state.searchQuery) && (this.props.activeIds.size > 0)) {
			this.filterExistingExamples();
			this.props.updateExampleSource("activeIds");
		} else if ((prevState.searchQuery !== this.state.searchQuery) && (this.props.brushedIds.size > 0)) {
			this.filterExistingExamples();
			this.props.updateExampleSource("brushedIds");
		} else if ((prevState.searchQuery !== this.state.searchQuery)) {
			if (this.state.searchQuery !== "") {
				this.populateWithQuery();
				this.props.updateExampleSource("query");
				this.props.updateActiveIdsToAdd(new Set());
			} else {
				this.clearAllExamples();
			}
		} else if (!areSetsEqual(prevProps.brushedIds, this.props.brushedIds)) {
			if (this.props.brushedIds.size > 0) {
				this.populateWithBrushedIds();
				this.props.updateExampleSource("brushedIds");
				this.props.updateActiveIdsToAdd(new Set());
			} else if (this.props.activeIds.size === 0) {
        this.clearAllExamples();
			}
		}
  }

  filterExistingExamples() {
    let newClusterSentences = this.state.clusterSentences
    let keys = Object.keys(newClusterSentences)
    let newActiveIdsToAdd = this.props.activeIdsToAdd
    let newClusterIds = [
      new Set(),
      new Set(),
      new Set()
    ];

    for (let clusterIdx = 0; clusterIdx < keys.length; clusterIdx++) {
      newClusterSentences[clusterIdx].sentences.forEach((s, i) => {
        var re = new RegExp(this.state.searchQuery, "i");
        var position = s.search(re);
        if (position === -1) {
          newClusterSentences[clusterIdx].showExample[i] = false
          if (newActiveIdsToAdd.has(newClusterSentences[clusterIdx].exampleIds[i])) {
            newActiveIdsToAdd.delete(newClusterSentences[clusterIdx].exampleIds[i]);
          }
        } else {
          newClusterSentences[clusterIdx].showExample[i] = true;
          newClusterIds[clusterIdx].add(newClusterSentences[clusterIdx]['exampleIds'][i]);
        }
      });
    }

    this.setState({
      clusterSentences: newClusterSentences
    });

    this.props.updateClusterIds(newClusterIds);
  }

  populateWithActiveIds() {
    this.props.updateActiveIdsToAdd(new Set());
		let exampleStrings = Array.from(this.props.activeIds).map((i) => this.props.data[i]);
		let exampleIds = Array.from(this.props.activeIds);

		// let filters = {'queryString': JSON.stringify(this.state.searchQuery), 'labelFilter': JSON.stringify(this.state.checked), 'probRange': JSON.stringify(this.state.range)};
		$.post('/api/getSimilarExamples', {allExampleIds: JSON.stringify(exampleIds), allExampleStrings: JSON.stringify(exampleStrings), model: this.props.selectedModel}, function(result) {
			this.props.updateClusterTopWords(result.clusterTopWords)
			let newClusterSentences = {
				0: {'sentences': [], 'exampleIds': [], 'showExample': []}, 
				1: {'sentences': [], 'exampleIds': [], 'showExample': []},  
				2: {'sentences': [], 'exampleIds': [], 'showExample': []}
			};

			result.clusters.forEach((c, i) => {
				newClusterSentences[c].sentences.push(this.props.data[result.similarExampleIds[i]]);
				newClusterSentences[c].exampleIds.push(result.similarExampleIds[i]);
				newClusterSentences[c].showExample.push(true);
			});

			this.setState({
				clusterSentences: newClusterSentences,
			});

			this.props.updateClusterIds([
				new Set(newClusterSentences[0]['exampleIds']),
				new Set(newClusterSentences[1]['exampleIds']),
				new Set(newClusterSentences[2]['exampleIds'])
			]);
		}.bind(this));
  }

  populateWithQuery() {
    let query = this.state.searchQuery;
    let filters = {'queryString': JSON.stringify(query), 'labelFilter': JSON.stringify(this.state.checked), 'probRange': JSON.stringify(this.state.range)};

    $.post('/api/getAllExamples', {filters: JSON.stringify(filters), model: this.props.selectedModel}, function(result) {
      this.props.updateClusterTopWords(result.clusterTopWords)
      let newClusterSentences = {
        0: {'sentences': [], 'exampleIds': [], 'showExample': []}, 
        1: {'sentences': [], 'exampleIds': [], 'showExample': []},  
        2: {'sentences': [], 'exampleIds': [], 'showExample': []}
      };

      result.clusters.forEach((c, i) => {
        newClusterSentences[c].sentences.push(result.matchedExamples[i]);
        newClusterSentences[c].exampleIds.push(result.matchedIds[i]);
        newClusterSentences[c].showExample.push(true);
      });

      this.setState({
        clusterSentences: newClusterSentences,
        searchQuery: query
      });

      this.props.updateClusterIds([
        new Set(newClusterSentences[0]['exampleIds']),
        new Set(newClusterSentences[1]['exampleIds']),
        new Set(newClusterSentences[2]['exampleIds'])
      ])
    }.bind(this));
  }

  populateWithBrushedIds() {
    let newClusterSentences = {
      0: {'sentences': [], 'exampleIds': [], 'showExample': []}, 
      1: {'sentences': [], 'exampleIds': [], 'showExample': []},  
      2: {'sentences': [], 'exampleIds': [], 'showExample': []}
    };

    let brushedIdsArray = Array.from(this.props.brushedIds)
    let brushedStrings = Array.from(brushedIdsArray).map((i) => this.props.data[i]);

    $.post('/api/clusterExamples', {'allExampleIds': JSON.stringify(brushedIdsArray), 'allExampleStrings': JSON.stringify(brushedStrings), 'model': this.props.selectedModel}, function(result) {
      this.props.updateClusterTopWords(result.clusterTopWords)
      result.clusters.forEach((c, i) => {
        newClusterSentences[c].sentences.push(this.props.data[result.matchedIds[i]]);
        newClusterSentences[c].exampleIds.push(result.matchedIds[i]);
        newClusterSentences[c].showExample.push(true);
      });

      this.setState({
        clusterSentences: newClusterSentences,
      });

      this.props.updateClusterIds([
        new Set(newClusterSentences[0]['exampleIds']),
        new Set(newClusterSentences[1]['exampleIds']),
        new Set(newClusterSentences[2]['exampleIds'])
      ])

    }.bind(this));
  }

  addExamplesToSet(exampleSetIdx, exampleIdsToAdd) {
    let newActiveIds = new Set([...this.props.activeIds, ...this.props.activeIdsToAdd]); 
    let newActiveIdsToAdd = new Set(this.props.activeIdsToAdd);
    let exampleSetToEdit = this.props.exampleSets[exampleSetIdx];

    for (let i = 0; i < exampleIdsToAdd.length; i++) {
      if (exampleSetToEdit.sentences.indexOf(this.props.data[exampleIdsToAdd[i]]) === -1) {
        this.props.exampleSets[exampleSetIdx].exampleIds.push(exampleIdsToAdd[i]);
        this.props.exampleSets[exampleSetIdx].sentences.push(this.props.data[exampleIdsToAdd[i]]);
      }    		
      newActiveIdsToAdd.delete(exampleIdsToAdd[i]);
    } 

    this.props.updateActiveIds(newActiveIds);
    this.props.updateExampleSets(this.props.exampleSets);
    this.props.updateActiveIdsToAdd(newActiveIdsToAdd);
  }

	search(e) {
		e.preventDefault();
		this.setState({
			searchQuery: e.target[0].value,
		});
	}

	clearAllExamples = () => {
		this.props.updateActiveIds(new Set());
		this.props.updateActiveIdsToAdd(new Set());

		let newClusterSentences = {
			0: {'sentences': [], 'exampleIds': [], 'showExample': []}, 
			1: {'sentences': [], 'exampleIds': [], 'showExample': []},  
			2: {'sentences': [], 'exampleIds': [], 'showExample': []}
		};

		this.setState({
			clusterSentences: newClusterSentences,
			searchQuery: "",
			exampleSource: null
		});

		this.props.updateExampleSource(null);
		this.props.updateClusterTopWords(null);
		this.props.updateClusterIds(null);
		this.props.updateBrushedPoints(new Set());
	}

	editAddExampleSet(e) {
		e.stopPropagation();
		this.setState({newExampleSetName: e.target.value});
	}

	addExampleSet(e) {
		e.preventDefault();
		if (this.state.newExampleSetName && !this.props.exampleSets.map((exampleSet) => exampleSet.name).includes(this.state.newExampleSetName)) {
		  let newActiveIdsToAdd = Array.from(this.props.activeIdsToAdd);
		  let newSentencesToAdd = [];
	
		  for (let i = 0; i < newActiveIdsToAdd.length; i++) {
			  newSentencesToAdd.push(this.props.data[newActiveIdsToAdd[i]]);
		  }
			
		  this.props.exampleSets.push({
        name: this.state.newExampleSetName,
        sentences: newSentencesToAdd,
        exampleIds: newActiveIdsToAdd
      });
		  this.setState({newExampleSetName: ""});
		  this.props.updateExampleSets(this.props.exampleSets);
		}
		e.target[0].value = "";
	}

	exampleSourceString() {
		console.log("here", this.props.exampleSource)
		let filteredByString = ' filtered by "' + this.state.searchQuery + '".'
		if (this.props.exampleSource == 'activeIds') {
			return <span className="now-displaying-string"><b>Now displaying:</b> examples similar to those selected above{this.state.searchQuery ? filteredByString : '.'}</span>
		} else if (this.props.exampleSource == 'brushedIds') {
			return <span className="now-displaying-string"><b>Now displaying:</b> examples selected in plot{this.state.searchQuery ? filteredByString : '.'}</span>
		} else if (this.props.exampleSource == 'query') {
			return <span className="now-displaying-string"><b>Now displaying:</b> all examples containing search query "{this.state.searchQuery}".</span>
		} 
	}

	render() {
		let functionString = (this.props.activeIds.size === 0 && this.props.brushedIds.size === 0) ? "searchAll" : "filter";


		if (this.props.activeIds.size === 0 && this.state.searchQuery === "" && this.props.brushedIds.size === 0) {
      return (
        <>
          <h5>Search and Explore Examples</h5>
				  <SearchExploreForm search={(e) => this.search(e)} function={functionString} />
			  </>
      );
		} else {
			let clusters = [];
			for (let i = 0; i < 3; i++) {
        if (this.state.clusterSentences[i].sentences.length !== 0) {
          clusters.push(
            <SearchExploreCluster 
              clusterId={i} 
              activeIdsToAdd={this.props.activeIdsToAdd}
              exampleIds={this.state.clusterSentences[i].exampleIds} 
              examples={this.state.clusterSentences[i].sentences}
              showExamples={this.state.clusterSentences[i].showExample}
              updateActiveIdsToAdd={this.props.updateActiveIdsToAdd}
              updateHoveringIds={(exampleIds, examples, label, mouseAction) => this.props.updateHoveringIds(exampleIds, examples, label, mouseAction)}
              clusterColor={this.clusterColors[i]}
            />
          );
        }
			}

			let dropdownOptions = [];
			for (let j = 0; j < this.props.exampleSets.length; j++) {
				dropdownOptions.push(
					<Dropdown.Item 
						onClick={() => this.addExamplesToSet(j, Array.from(this.props.activeIdsToAdd))}>
						{this.props.exampleSets[j].name}
					</Dropdown.Item>
				)
			}
			dropdownOptions.push(
				<Dropdown.Item onClick={(e) => {e.stopPropagation()}}>
					<Form onSubmit={(e) => {this.addExampleSet(e);}}>
            <Form.Control
              type="text"
              placeholder="Add new example set..."
              onChange={(e) => this.editAddExampleSet(e)}
            />
          </Form>
				</Dropdown.Item>
			);

			return (
				<>
					<h5>Search and Explore Examples</h5>
					
					<Dropdown>
					  <Dropdown.Toggle className="button-color" variant="primary" id="dropdown-basic">
					    Add {this.props.activeIdsToAdd.size} examples to example set
					  </Dropdown.Toggle>

					  {clusters.length > 0 ?
					  	<Button className='selectButtonExSet clearAllSelected' variant="light" onClick={this.clearAllExamples}><i>clear all examples</i></Button>
					  	: <></>
					  }
					  
					  <SearchExploreForm search={(e) => this.search(e)} function={functionString}/>

					  <Dropdown.Menu>
					    {dropdownOptions}
					  </Dropdown.Menu>

					</Dropdown>

					{this.props.exampleSource && this.exampleSourceString()}

					<br></br>

					{clusters.length > 0 ? clusters : <p style={{'marginTop': '10px', 'fontStyle': 'italic'}}>No query matches</p>}
				</>
			)
		}
	}
}
