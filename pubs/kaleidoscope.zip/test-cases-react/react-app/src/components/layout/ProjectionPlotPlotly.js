import React, { Component } from 'react';
import Plot from 'react-plotly.js';
import Dropdown from 'react-bootstrap/Dropdown';
import {
  divergingColorScale,
  sequentialColorScale,
  distributional,
  paired,
  output
} from '../constants.js'

export default class ProjectionPlotPlotly extends Component {
  constructor(props) {
    super(props);

    this.state = {
      x: null,
      y: null,
      data: null,
      quadtree: null,
      brushObject: null,
      projectionType: "umap",
      x_coords: null, 
      y_coords: null, 
      colorArr: null,
      opacityArr: null, 
      sizeArr: null,
      symbolArr: null,
      layout: {autosize: true, margin: {b: 0, l: 0, t: 0, r: 0}, dragmode: 'select', uirevision:true, xaxis: {zeroline: false}, yaxis: {zeroline: false}},
      expandedIds: new Set()
    }

    this.margin = {top: 0, right: 0, bottom: 0, left: 0};
    this.transform = null;
    this.projectionTypes = ["tsne", 'pca', "umap"];
    this.clusterColors = ["#f28e2b", "#e15759", "#76b7b2"];
    this.baseOpacity = 0.1;
    this.baseSize = 5;
    this.baseSymbol = 'circle';
  }

  componentDidMount() {
    this.loadData()
  }

  loadData() {
    let data = JSON.parse(this.props.data_and_bounds.data_json);  
    let x_coord_name = this.state.projectionType + "_x";
    let y_coord_name = this.state.projectionType + "_y";
    console.log('in viz section', data)

    this.setState({
      data: data,
      x_coords: data.map(item => item[x_coord_name]),
      y_coords: data.map(item => item[y_coord_name]),
      colorArr: new Array(data.length).fill("#89909F"),
      opacityArr: new Array(data.length).fill(this.baseOpacity),
      sizeArr: new Array(data.length).fill(this.baseSize),
      symbolArr: new Array(data.length).fill(this.baseSymbol)
    });
  }

      // Whenever the component updates, select the <g> from the DOM, and use D3 to manipulte circles
  componentDidUpdate(prevProps, prevState) {
    if (prevProps.clusterIds !== this.props.clusterIds) { // if clusters have changed
      if (!this.props.clusterIds) {
        if (prevProps.clusterIds) { // if there are no longer visible clusters, unhighlight all previous cluster points
          for (let i = 0; i < prevProps.clusterIds.length; i++) { 
            this.highlightPoints(Array.from(prevProps.clusterIds[i]), new Set());
          }
        }
      } else {
        if (!prevProps.clusterIds) { // if there are visible clusters (but there weren't any before), highlight all new points
          for (let i = 0; i < this.props.clusterIds.length; i++) {
            this.highlightPoints(new Set(), Array.from(this.props.clusterIds[i]), [this.clusterColors[i]]);
          }
        } else {
          for (let i = 0; i < prevProps.clusterIds.length; i++) { // if there were clusters before, unhighlight those points and highlight the new ones
            this.highlightPoints(Array.from(prevProps.clusterIds[i]), Array.from(this.props.clusterIds[i]), [this.clusterColors[i]]);
          }
        }
      }
    }

    if (this.props.expandedExSet && (prevProps.expandedExSet !== this.props.expandedExSet)) {
      let newExpandedIds = new Set(this.props.exampleSets[this.props.expandedExSet].exampleIds);
      let unhighlightIds = this.difference(this.state.expandedIds, newExpandedIds);
      this.highlightPoints(Array.from(unhighlightIds), Array.from(newExpandedIds));
      this.setState({
        expandedIds: newExpandedIds
      });
    } else if (this.props.expandedTest && (prevProps.expandedTest !== this.props.expandedTest)) {
      this.highlightTestPointsInColor(this.props.expandedTestObject);
    } else if (!this.props.expandedExSet && !this.props.expandedTest && (prevProps.expandedTest || prevProps.expandedExSet)) {
      let unhighlightIds = this.state.expandedIds;
      this.highlightPoints(Array.from(unhighlightIds), []);
      this.setState({
        expandedIds: new Set()
      });
    }

    if (this.props.data_and_bounds != prevProps.data_and_bounds) {
      console.log("here updating data", this.props.data_and_bounds)
      this.loadData()
    }
  }

  predToColor(prob) {
    let percent = prob*100;
    let colorQuantile = Math.floor(percent/20)*20/10;
    let colorIdx = 4 - Math.min(colorQuantile/2, 4);
    let color = divergingColorScale[colorIdx];
    return color;
  }

  predDiffToColor(predDiff) {
    let diffQuantile = Math.floor(Math.abs(predDiff) * 10) / 10;
    let diffIndex = diffQuantile*10;
    let color = diffIndex < 4 ? sequentialColorScale[diffIndex] : sequentialColorScale[4];
    return color;
  }

  highlightTestPointsInColor(definedTest) {
    let exampleIds, colors, symbols;
    if (definedTest.deactivated || !definedTest.result) {
      exampleIds = new Set();
      colors = [];
    } else if (definedTest.type === output) {
      exampleIds = this.props.exampleSets.filter((exSet) => exSet.name === definedTest.exampleSets[0])[0].exampleIds;
      colors = definedTest.preds.map((pred) => this.predToColor(pred));
    } else if (definedTest.granularity === distributional) {
      let exampleIds1 = this.props.exampleSets.filter((exSet) => exSet.name === definedTest.exampleSets[0])[0].exampleIds;
      let exampleIds2 = this.props.exampleSets.filter((exSet) => exSet.name === definedTest.exampleSets[1])[0].exampleIds;
      let colors1 = definedTest.preds[0].map((pred) => this.predToColor(pred));
      let colors2 = definedTest.preds[1].map((pred) => this.predToColor(pred));
      let symbols1 = Array(exampleIds1.length).fill('square');
      let symbols2 = Array(exampleIds2.length).fill('star');
      exampleIds = exampleIds1.concat(exampleIds2);
      colors = colors1.concat(colors2);
      symbols = symbols1.concat(symbols2);
    } else if (definedTest.granularity === paired) {
      exampleIds = this.props.exampleSets.filter((exSet) => exSet.name === definedTest.exampleSet)[0].exampleIds;
      exampleIds = exampleIds.filter((exId, i) => new Set(definedTest.transformedIdx).has(i))
      let predDiffs = definedTest.preds[0].map((pred, i) => definedTest.preds[1][i] - pred);
      colors = predDiffs.map((predDiff) => this.predDiffToColor(predDiff));
    }  

    let newExpandedIds = new Set(exampleIds);
    let unhighlightIds = this.difference(this.state.expandedIds, newExpandedIds);
    this.highlightPoints(Array.from(unhighlightIds), exampleIds, colors, symbols ? symbols : ['circle']);
    this.setState({
      expandedIds: newExpandedIds
    });
  }

  difference(setA, setB) {
    let _difference = new Set(setA);
    for (let elem of setB) {
       _difference.delete(elem);
    }
    return _difference;
  }

  highlightPoints(unhighlightIds, expandedIds, colors=["#4e79a7"], symbols=['circle']) {
    let newColorArr = this.state.colorArr;
    let newOpacityArr = this.state.opacityArr;
    let newSizeArr = this.state.sizeArr;
    let newSymbolArr = this.state.symbolArr;

    for (let i = 0; i < unhighlightIds.length; i++) {
      newColorArr[unhighlightIds[i]] = "#89909F";
      newOpacityArr[unhighlightIds[i]] = this.baseOpacity;
      newSizeArr[unhighlightIds[i]] = this.baseSize;
      newSymbolArr[unhighlightIds[i]] = this.baseSymbol;
    }

    for (let j = 0; j < expandedIds.length; j++) {
      newColorArr[expandedIds[j]] = colors.length > 1 ? colors[j] : colors[0];
      newOpacityArr[expandedIds[j]] = 1;
      newSizeArr[expandedIds[j]] = this.baseSize + 1;
      newSymbolArr[expandedIds[j]] = symbols.length > 1 ? symbols[j] : symbols[0];
    }

    this.setState({
      colorArr: newColorArr,
      opacityArr: newOpacityArr,
      sizeArr: newSizeArr,
      symbolArr: newSymbolArr
    });
  }

  changeProjectionType(newProjectionType) {
    let x_coord_name = newProjectionType + "_x";
    let y_coord_name = newProjectionType + "_y";

    this.setState({
      projectionType: newProjectionType,
      x_coords: this.state.data.map(item => item[x_coord_name]),
      y_coords: this.state.data.map(item => item[y_coord_name])
    });
  }

  handleSelection(event) {
    console.log("in handleSelection", event)
    if (event) {
      this.props.updateBrushedPoints(new Set(event.points.map((item) => item.pointIndex)))
    } else {
      this.props.updateBrushedPoints(new Set())
    }
    
  }


  stringDivider(str, width, spaceReplacer) {
    if (str.length>width) {
        var p=width
        for (;p>0 && str[p]!==' ';p--) {
        }
        if (p>0) {
            var left = str.substring(0, p);
            var right = str.substring(p+1);
            return left + spaceReplacer + this.stringDivider(right, width, spaceReplacer);
        }
    }
    return str;
  }

  render() {
    // let x_coord_name = this.state.projectionType + "_x";
    // let y_coord_name = this.state.projectionType + "_y";
    if (this.state.data) {
      return (
        <>
        <div>
          <span style={{'float': 'left', 'margin': '4px'}}>Projection type:</span> 
          <Dropdown>
            <Dropdown.Toggle id="dropdown-basic" style={{'padding': '0.2rem 0.3rem', 'float': 'left'}}>
              {this.state.projectionType}
            </Dropdown.Toggle>

            <Dropdown.Menu>
              {this.projectionTypes.map((projectionType) => 
              <Dropdown.Item active={projectionType === this.state.projectionType} onClick={() => this.changeProjectionType(projectionType)}>
                {projectionType}
              </Dropdown.Item>
              )}
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <div style={{'display': 'inline-block', 'position': 'relative', 'width': '100%'}}>
        <div style={{'marginTop': '100%'}}></div>
        <Plot
          data={[
            {
              x: this.state.x_coords,
              y: this.state.y_coords,
              text: this.state.data.map(item => this.stringDivider(item['comment'], 40, "<br>")), 
              type: 'scatter',
              mode: 'markers',
              hoverinfo: 'text',
              marker: {size: this.state.sizeArr, color: this.state.colorArr, opacity: this.state.opacityArr, line: {width: 0}, symbol: this.state.symbolArr},
              xaxis: {zeroline: false, visible: false},
              yaxis: {zeroline: false, visible: false}
            }]}
          layout={ this.state.layout }
          config={{ modeBarButtonsToRemove: ['toImage', 'autoScale2d'], displaylogo: false }}
          useResizeHandler={true}
          style={{position: 'absolute', top: 0, bottom: 0, left: 0, right: 0}}
          onSelected={(event) => this.handleSelection(event)}
        />
        </div>
        </>
      );
    } else {
      return <></>;
    }
  }
}
