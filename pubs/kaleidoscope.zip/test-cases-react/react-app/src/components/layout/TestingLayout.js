import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Button } from 'semantic-ui-react';
import { Link } from 'react-router-dom';

import ExampleSetsSection from './ExampleSetsSection.js';
import VizSection from './VizSection.js';
import DefinedTestsSection from './DefinedTestsSection.js';
import SettingsTab from './SettingsTab';
import "../../index.css";

import {
	defaultExampleSets,
	defaultTests
} from '../defaultData.js'

var $;
$ = require('jquery');

class TestingLayout extends Component {

	constructor(props) {
		super(props);

		this.state = {
			exampleSets: JSON.parse(localStorage.getItem('exampleSets')) || [],
			tests: JSON.parse(localStorage.getItem('tests')) || [],
			fullData: null,
			examplesAndIds: null,
			maxId: null,
			clusterTopWords: null,
			clusterIds: null,
			brushedIds: new Set(),
			exampleSource: null,
			expandedExSet: null,
			expandedTest: null,
			expandedExSetsAndTests: [],
			selectedModel: this.props.selectedModel,
			selectedTask: this.props.selectedTask,
			selectedData: this.props.selectedData,
			models: ['model1', 'model2']
		};
	}

	updateExampleSource = (newExampleSource) => {
		this.setState({
			exampleSource: newExampleSource
		})
	} 

	updateClusterTopWords = (newClusterTopWords) => {
		this.setState({
			clusterTopWords: newClusterTopWords
		})
	}

	updateClusterIds = (newClusterIds) => {
		this.setState({
			clusterIds: newClusterIds
		})
	}

	updateExampleSets = (newExampleSets) => {
		this.updateTestActivation();

		this.setState({
			exampleSets: newExampleSets,
		});

		localStorage.setItem('exampleSets', JSON.stringify(newExampleSets));
	}

	updateTestActivation = () => {
		let newTests = this.state.tests;
		let exampleSetNames = new Set(this.state.exampleSets.map(exSet => exSet['name']));

		for (let testIdx = 0; testIdx < this.state.tests.length; testIdx++) {
      let test = this.state.tests[testIdx];
      let testExSets = [];
      if ('exampleSets' in test) {
        testExSets = test['exampleSets'];
      } else if ('exampleSet' in test) {
        testExSets = [test['exampleSet']];
      }

			let deactivatedStatus = false;

			for (let exSetIdx = 0; exSetIdx < testExSets.length; exSetIdx++) {
				if (!exampleSetNames.has(testExSets[exSetIdx])) {
					deactivatedStatus = true;
				}
			}

			newTests[testIdx]['deactivated'] = deactivatedStatus;
			newTests[testIdx]['deactivationSource'] = "exSetMissing";
		}

		this.setState({
			tests: newTests,
		});

		localStorage.setItem('tests', JSON.stringify(newTests));
	}


	updateBrushedIds = (exampleIds) => {
		this.setState({
			brushedIds: exampleIds
		});
	}

	updateExpandedExSetsAndTests = (index, type) => {
		let currentlyExpanded = this.state.expandedExSetsAndTests;
		let clickedSetId = type + '_' + index.toString();

		if (!currentlyExpanded.includes(clickedSetId)) { // checking whether array contains the id
	      if (type === 'exSet') {
	        const existingExSetIndex = currentlyExpanded.findIndex(element => element.includes('exSet'));
			existingExSetIndex !== -1 && currentlyExpanded.splice(existingExSetIndex, 1); 
	      }
	      currentlyExpanded.push(clickedSetId); // adding to array because value doesn't exist
		} else {
	      currentlyExpanded.splice(currentlyExpanded.indexOf(clickedSetId), 1); // deleting
		}

		let expandedTest = null;
		let expandedExSet = null;
		if (currentlyExpanded.length > 0) {
			let selectedType = currentlyExpanded[currentlyExpanded.length - 1].split('_')[0];
			let selectedIdx = currentlyExpanded[currentlyExpanded.length - 1].split('_')[1];
			if (selectedType === 'exSet') {
				expandedExSet = selectedIdx;
			} else {
				expandedTest = selectedIdx;
			}
		}
		
		this.setState({
			expandedExSetsAndTests: currentlyExpanded,
			expandedExSet: expandedExSet,
			expandedTest: expandedTest
		});
	}

	removeExpandedExSetOrTest = (index, type) => {
		let clickedSetId = type + '_' + index.toString()
		let currentlyExpanded = this.state.expandedExSetsAndTests
		if (currentlyExpanded.indexOf(clickedSetId) > 0) {
			currentlyExpanded.splice(currentlyExpanded.indexOf(clickedSetId), 1);
		}

		let expandedExSet = type == 'exSet' ? null : this.state.expandedExSet
		let expandedTest = type == 'test' ? null : this.state.expandedTest
		
		this.setState({
			expandedExSetsAndTests: currentlyExpanded,
			expandedExSet: expandedExSet,
			expandedTest: expandedTest
		})
	}

	setTestAsRunning = (testIdx) => {
		let newTests = this.state.tests
		newTests[testIdx]['running'] = true
		this.setState({
			tests: newTests
		});
	}

	updateTestResult = (testName, testResult, testPreds, transformedExamples, transformationApplied, transformedIdx, meanDiff, pval) => {
		let newTests = this.state.tests;

		for (let i = 0; i < newTests.length; i++) {
			if (newTests[i]['name'] === testName) {
				newTests[i]['result'] = testResult;
				newTests[i]['preds'] = testPreds;
				newTests[i]['runTestIdx'] = newTests[i]['runTestIdx'] + 1
				newTests[i]['transformedExamples'] = transformedExamples;
				newTests[i]['transformedIdx'] = transformedIdx; 
				newTests[i]['meanDiff'] = meanDiff;
				newTests[i]['pval'] = pval;
				newTests[i]['running'] = false;
				if ((newTests[i].granularity === "Paired") && (!transformationApplied)) {
					newTests[i]['deactivated'] = true;
					newTests[i]['deactivationSource'] = 'noTransformation';
				}
				break;
			}
		}

		this.setState({
			tests: newTests
		});

		localStorage.setItem('tests', JSON.stringify(newTests));
	}

	addExample = (newExample, newExampleId) => {
		let newExamplesAndIds = this.state.examplesAndIds;
		newExamplesAndIds[newExampleId] = newExample;
		this.setState({
			examplesAndIds: newExamplesAndIds
		});

		let maxId = this.state.maxId + 1;

		let newFullData = this.state.fullData;
		newFullData[newExampleId] = newExample;
		this.setState({
			fullData: newFullData
		});

		this.setState({
			examplesAndIds: this.state.examplesAndIds,
			maxId: maxId,
			fullData: this.state.fullData
		});
	}

	removeDefinedTest = i => {
	let newDefinedTests = [];
	this.state.tests.forEach((t, ix) => {
	  if (ix !== i) {
	    newDefinedTests.push(t);
	  }
	});
	this.setState({
	  tests: newDefinedTests
	});
	localStorage.setItem('tests', JSON.stringify(newDefinedTests));
	}

	editDefinedTest = (i, newTest) => {
	let newDefinedTests = this.state.tests.filter((t, ix) => ix !== i);
	newDefinedTests.push(newTest);

	this.setState({
	  tests: newDefinedTests
	}, () => {
			this.forceUpdate();
		});
	localStorage.setItem('tests', JSON.stringify(newDefinedTests));
	}

	componentDidMount() {
		this.getProjectionDf()
	}

	getProjectionDf() {
		console.log(this.state.selectedTask)
		$.getJSON('/api/getProjectionDf', {'task': this.state.selectedTask, 'data': this.state.selectedData}, function(result) {
			console.log(result)
			let examplesAndIds = {};
			JSON.parse(result.data_json).map((el) => examplesAndIds[el.comment_id] = el.comment)
			let maxId = Math.max(...Object.keys(examplesAndIds).map((k) => parseInt(k)))

			this.setState({
				fullData: result,
				examplesAndIds: examplesAndIds,
				maxId: maxId
			});
		}.bind(this));
	}


  	callback = (newTest) => {
		const newTests = this.state.tests.concat(newTest);
		this.setState({
			tests: this.state.tests.concat(newTest)
		}, () => {
			this.forceUpdate();
		});
		localStorage.setItem('tests', JSON.stringify(newTests));
	};

	addNewTransformation = (transformation) => {
		const newTransformations = this.state.transformationFunctions.concat(transformation);
		this.setState({
			transformationFunctions: newTransformations
		}, () => {
			this.forceUpdate();
		});
		localStorage.setItem('transformationFunctions', JSON.stringify(newTransformations))
	};

	changeModel = (modelName) => {
		this.setState({selectedModel: modelName});
	}

	changeTask = (taskName) => {
		this.setState({fullData: null})
		console.log(taskName)
		this.setState({selectedTask: taskName}, () => {console.log(this.state.selectedTask); this.getProjectionDf()});
	}

	render() {
		if (localStorage.getItem('exampleSets') == null) {
			localStorage.setItem('exampleSets', JSON.stringify(defaultExampleSets))
		} 
		if (localStorage.getItem('tests') === null) {
			localStorage.setItem('tests', JSON.stringify(defaultTests))
		} 

		return (
		<Container className="container-left-margin">
 
        <SettingsTab 
        	selectedModel={this.state.selectedModel}
			selectedTask={this.state.selectedTask}
			selectedData={this.state.selectedData}
			models={this.state.models}
			changeModel={this.changeModel}
        />

          
          <Row>
          <Col sm={4}>
            <ExampleSetsSection
              exampleSource={this.state.exampleSource}
              updateExampleSource={this.updateExampleSource}
              updateExampleSets={this.updateExampleSets}
              updateClusterTopWords={this.updateClusterTopWords}
              updateClusterIds={this.updateClusterIds}
              updateBrushedPoints={this.updateBrushedIds}
              exampleSets={this.state.exampleSets}
              data={this.state.examplesAndIds}
              addExample={this.addExample}
              maxId={this.state.maxId}
              brushedIds={this.state.brushedIds}
              selectedModel={this.state.selectedModel}
              updateExpandedExSet={this.updateExpandedExSetsAndTests}
              removeExpandedExSet={this.removeExpandedExSetOrTest}
            />
          </Col>
          <Col sm={4} className="row-margins sticky-top">
            <VizSection
              exampleSource={this.state.exampleSource}
              exampleSets={this.state.exampleSets}
              expandedExSet={this.state.expandedExSet}
              expandedTest={this.state.expandedTest}
              expandedTestObject={this.state.expandedTest ? this.state.tests[this.state.expandedTest] : null}
              clusterTopWords={this.state.clusterTopWords}
              clusterIds={this.state.clusterIds}
              data={this.state.fullData}
              updateBrushedPoints={this.updateBrushedIds}
            />
			    </Col>
          <Col sm={4}>
          	<DefinedTestsSection
              addTestCallback={newTest => this.callback(newTest)}
              updateTestResult={this.updateTestResult}
              definedTests={this.state.tests}
              removeDefinedTest={i => this.removeDefinedTest(i)}
              editDefinedTest={(i, newTest) => this.editDefinedTest(i, newTest)}
              exampleSets={this.state.exampleSets}
              selectedModel={this.state.selectedModel}
              updateExpandedTest={this.updateExpandedExSetsAndTests}
              removeExpandedTest = {this.removeExpandedExSetOrTest}
              setTestAsRunning = {this.setTestAsRunning}
            />
          </Col>
			  </Row>
			</Container>
		);
	}
}

// class SelectOptions extends Component {
//   render() {
//     return (
//       <>
//         <h1>Select a task:</h1>
//         <Link to="/moderation">
//           <Button>Content moderation</Button>
//         </Link>
//       </>
//     );
//   }
// }

// class SelectModerationModel extends Component {
//   render() {
//     return (
//       <>
//         <h1>Select a model:</h1>
//         <Link to="/moderation/model1">
//           <Button>model1</Button>
//         </Link>
//         <Link to="/moderation/model2">
//           <Button>model2</Button>
//         </Link>
//       </>
//     );
//   }
// }

// class SelectModerationData extends Component {
//   render() {
//  	const buttons = []
//  	const options = ['news',
// 					 'gaming',
// 					 'movies',
// 					 'askreddit',
// 					 'funny',
// 					 'tifu',
// 					 'getmotivated',
// 					 'technology',
// 					 'futurology']

// 	for (let i = 0; i < options.length; i++) {
// 	    buttons.push(
// 	    	<>
// 	    	<Link to="/moderation/{options[i]}">
//           		<Button>{options[i]}</Button>
//         	</Link>
//         	</>
//         );
// 	}

//     return (
//       <>
//         <h1>Select a model:</h1>
//         {buttons}
//       </>
//     );
//   }
// }

// class SelectSentimentModel extends Component {
//   render() {
//     return (
//       <>
//         <h1>Select a model:</h1>
//         <Link to="/sentiment/amazon">
//           <Button>r/amazon</Button>
//         </Link>
//       </>
//     );
//   }
// }

export {TestingLayout};
