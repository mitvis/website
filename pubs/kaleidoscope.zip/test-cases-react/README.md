# test-cases

Before running for the first time: 
1. Download the data and model files (contact hsuresh@mit.edu for the links to these files). Unzip these into a `data` folder and a `models` folder, and add these folders to react-app/api/.
2. Create a python virtual environment to run the Flask backend.\
      E.g., using `mkvirtualenv`:\
      	`> cd test-cases`\
      	`> pip install virtualenvwrapper`\
        `> mkvirtualenv test-cases`\
        `> workon .`\
        `> pip install -r requirements.txt`
        `> deactivate`
3. cd into the `react-app` folder and run `npm install`

To start the app after completing the above steps: 
1. `cd react-app`
2. Activate the virtualenv and run the Flask backend.\ 
  `> cd api`\
  `> workon test-cases`\
  `> flask run`\
  It may take a minute or two for the server to start up. 
3. Start the app. 
  `> npm start`
4. Navigate to `localhost:3000` 
