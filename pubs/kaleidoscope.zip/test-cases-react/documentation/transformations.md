# Transformation Documentation

This file details documentation for transformations applied on the input list.

## replace(input_list: List<String>, words_to_replace: List<String>, words_to_replace_with: List<String>, one_to_one_replace: bool)

This transformation replaces all instances of the words given in `strings_to_replace` in `input_list` with words in `strings_to_replace_with`. The function either chooses the string to replace with randomly or replaces words one-to-one.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model
- `strings_to_replace` (required): list of strings to replace in `input_list`
- `strings_to_replace_with` (required): list of strings to replace with in `input_list`
- `one_to_one_replace` (optional, default is `False`): boolean on whether to replace words via a one-to-one mapping of `words_to_replace` and `words_to_replace_with`. When `one_to_one_replace` is `True`, `strings_to_replace` and `strings_to_replace_with` must be the same length.

Examples:
- `replace(["i don't like your comment", "this is stupid"], ["comment", "stupid"], ["crazy", "idiotic", "fumble"])` -> `["i don't like your idiotic", 'this is crazy']`
- `replace(["i don't like your comment", "this is stupid"], ["comment", "stupid"], ["crazy", "idiotic"], True)` -> `["i don't like your crazy", 'this is idiotic']`
- `replace(["i don't like your comment", "this is stupid"], ["comment", "stupid"], ["crazy", "idiotic", "fumble"], False)` -> `["i don't like your fumble", 'this is crazy']`

## add(input_list: List<String>, strings_to_add: List<String>)

This transformation adds one of the given strings in `strings_to_add` to each string in `input_list`. For each string in `input_list`, the string to add is chosen randomly. If `strings_to_add` is not given, we use BERT to add a word in randomly.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model
- `strings_to_add` (optional, default=None): list of strings to add in `input_list`

Examples:
- `add(["i don't like your comment", "here for the drama"], [", right?"])` -> `["i don't like your comment, right?", 'here for the drama, right?']`
- `add(["i don't like your comment", "here for the drama"], [", right?", " bet"])` -> `["i don't like your comment bet", 'here for the drama bet']`
- `add(["i like your comment", "here for the drama"], [", right?", " bet"])` -> `['i like in your comment', 'help here for the drama']`

## delete(input_list: List<String>, strings_to_delete: List<String>)

This transformation deletes all strings in `strings_to_delete` in each string in `input_list`.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model
- `strings_to_delete` (required): list of strings to delete in `input_list`

Examples:
- `delete(["i don't like your comment", "here for the drama", "i don't like pizza"], ["don't", "comment"])` -> `['i  like your ', 'here for the drama', 'i  like pizza']`
- `delete(["i like your comment", "here for the drama"])` -> `['i like your', 'here for drama']`

## keyboard_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by replacing a character with another one that is close to it in the keyboard, thus simulating a typed typo.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `keyboard_typo(["i like your comment", "here for the drama"])` -> `['i kike your comment', 'here for the drxma']`

## ocr_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by replacing a character with another one that looks similar to it.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `ocr_typo(["i don't like your comment", "here for the drama"])` -> `['i like yoor comment', 'here f0r the drama']`

## insert_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by adding a character to the word.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `insert_typo(["i don't like your comment", "here for the drama"])` -> `['i like yolur comment', 'herle for the drama']`

## substitute_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by replacing a character with another random one.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `substitute_typo(["i don't like your comment", "here for the drama"])` -> `['i sike your comment', 'heri for the drama']`

## swap_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by choosing two adjacent letters in the word to switch.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `swap_typo(["i don't like your comment", "here for the drama", "i don't like pizza"])` -> `["i odn't like your comment", 'hree for the drama', "i don't like pizaz"]`

## delete_typo(input_list: List<String>)

This transformation creates a typo in a randomly chosen word in each string in `input_list`. It creates this typo by removing a character in the word.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `delete_typo(["i don't like your comment", "here for the drama"])` -> `['i like your commet', 'hee for the drama']`

## synonym(input_list: List<String>, words_to_replace: List<String>)

This transformation replaces all words in `words_to_replace` with a synonym found in the [Pattern library](https://github.com/clips/pattern). If `words_to_replace` is not specified, the function takes a random word from each string in `input_list` to make `words_to_replace`.

Parameters: 
- `input_list` (required): list of strings meant to be data inputted into the model
- `words_to_replace` (optional, default is `None`): list of strings to replace with their synonyms. If unspecified, `words_to_replace` becomes a list of one random word from each input in `input_list`

Examples:
- `synonym(["i don't like your comment", "here for the drama", "i don't like pizza"], ["drama", "like"])` -> `["i don't comparable your comment", 'here for the play', "i don't care pizza"]`
  - Notice how the synonyms are not perfect.
  - If the program cannot find a synonym, the word stays the same.

## antonym(input_list: List<String>, words_to_replace: List<String>)

This transformation replaces all words in `words_to_replace` with an antonym found in the [Pattern library](https://github.com/clips/pattern). If `words_to_replace` is not specified, the function takes a random word from each string in `input_list` to make `words_to_replace`.

Parameters: 
- `input_list` (required): list of strings meant to be data inputted into the model
- `words_to_replace` (optional, default is `None`): list of strings to replace with their antonyms. If unspecified, `words_to_replace` becomes a list of one random word from each input in `input_list`

Examples:
- `antonym(["i don't like your comment", "here for the drama", "i don't like pizza"], ["drama", "like"])` -> `["i don't different your comment", 'here for the drama', "i don't dislike pizza"]`
  - If the program cannot find an antonym, the word stays the same.

## hypernym(input_list: List<String>, words_to_replace: List<String>)

This transformation replaces all words in `words_to_replace` with a hypernym found in the [Pattern library](https://github.com/clips/pattern). If `words_to_replace` is not specified, the function takes a random word from each string in `input_list` to make `words_to_replace`.

Parameters: 
- `input_list` (required): list of strings meant to be data inputted into the model
- `words_to_replace` (optional, default is `None`): list of strings to replace with their hypernyms. If unspecified, `words_to_replace` becomes a list of one random word from each input in `input_list`

Examples:
- `hypernym(["i don't like your comment", "here for the drama", "i don't like pizza"], ["drama", "like"])` -> `["i don't form your comment", 'here for the trait', "i don't conceive pizza"]`
  - Notice how the hypernyms are not perfect.
  - If the program cannot find a hypernym, the word stays the same.

## hyponym(input_list: List<String>, words_to_replace: List<String>)

This transformation replaces all words in `words_to_replace` with a hyponym found in the [Pattern library](https://github.com/clips/pattern). If `words_to_replace` is not specified, the function takes a random word from each string in `input_list` to make `words_to_replace`.

Parameters: 
- `input_list` (required): list of strings meant to be data inputted into the model
- `words_to_replace` (optional, default is `None`): list of strings to replace with their hyponyms. If unspecified, `words_to_replace` becomes a list of one random word from each input in `input_list`

Examples:
- `hyponym(["i don't like your comment", "here for the drama", "i don't like pizza"], ["drama", "like"])` -> `["i don't prefer your comment", 'here for the slapstick', "i don't please pizza"]`
  - Notice how the hyponyms are not perfect.
  - If the program cannot find a hyponym, the word stays the same.

## names(input_list: List<String>)

This transformation replaces all names (e.g. Blake, Rebecca) in all strings in `input_list` with randomly chosen names of the same perceived gender/location. For example, typically female names are replaced with typically female names, typically male names are replaced with typically male names, and typically last names are replaced with typically last names.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `names(["haven't seen trista lately", "Have i seen Daniel?", "The Johnson family needs a break", "this comment sucks"])` -> `["haven't seen Katerina lately", 'Have i seen Mario', 'The Marciano family needs a break', 'this comment sucks']`

## cities(input_list: List<String>)

This transformation replaces all cities (e.g. York) in all strings in `input_list` with randomly chosen cities.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `cities(["haven't seen boston lately", "Have i seen york?", "I need a break", "russia is great"])` -> `["haven't seen Atlantic City lately", 'Have i seen Cupertino', 'I need a break', 'russia is great']`

## countries(input_list: List<String>)

This transformation replaces all cities (e.g. York) in all strings in `input_list` with randomly chosen cities.

Parameters:
- `input_list` (required): list of strings meant to be data inputted into the model

Examples:
- `countries(["haven't seen France lately", "Have i seen china?", "I need a break", "boston is great"])` -> `["haven't seen Botswana lately", 'Have i seen Mali', 'I need a break', 'boston is great']`