import praw
import pdb
import requests
import json
import csv
import time
import datetime
import os
from datetime import datetime, timezone
import sys

print('Subreddit:', str(sys.argv[1]))

client_id = "m2aV_KYvlkXvPQ"
client_secret = "kR_AUdHQWIzbbhkNZPePExZA-R21kQ"
reddit = praw.Reddit(
    user_agent="Comment Extraction",
    client_id=client_id,
    client_secret=client_secret,
)


begin = datetime(2016, 5, 30)
begin = begin.replace(tzinfo=timezone.utc).timestamp()
end = datetime(2017, 2, 28).replace(tzinfo=timezone.utc).timestamp()

reddit_name = str(sys.argv[1])
data_dir = 'data/reddit/' + reddit_name 
if not os.path.exists(data_dir):
	os.mkdir(data_dir)

base_url = "https://api.pushshift.io/reddit/search/comment/?subreddit=" + reddit_name + "&size=500"
# Put together timestamps for the last 5 years, in half year chunks

start = begin
i = 0
time_interval = (end-begin)/200
while start < end+1:
	time.sleep(1)
	url = base_url + "&after=" + str(int(start)) + "&before=" + str(int(start+time_interval))
	resp = requests.get(url)
	
	try:	
		dicts = json.loads(resp.content)
	except:
		pdb.set_trace()
	with open(data_dir + "/" + str(i) + ".data", "w") as outfile:
		outfile.write(json.dumps(dicts))
	
	start += time_interval
	i += 1
	print(i)
