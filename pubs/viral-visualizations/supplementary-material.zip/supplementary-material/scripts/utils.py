#!/usr/bin/env python3

# Functions for converting between tweets/media ids to system paths and back

import os
from urllib.parse import urlparse
MEDIA_DIR = '/data/visualization'

def id_to_path(id, chunk_size=7, root_path=MEDIA_DIR):
  """
  Given a tweet or media ID (typically 19 characters) and an existing String path (like Desktop/covid-vis/), generates
  a nesting path unique to the tweet ID. 
  - tweet_id: unique 19 character string ID of a tweet
  - chunk_size: how many digits to chunk by to nest paths
  - root_path: existing file path where you want the nesting of folders to occur
  - returns: full nested path from path with id
  ex) a tweet with id 1286055355282317313, given path of 'Desktop/covid-vis/', chunked by 3
  returns path 'Desktop/covid-vis/1/286/055/355/282/317/313'.
  """
  id_str = str(id)
  chunks = [id_str[i:i+chunk_size] for i in range(0, len(id_str), chunk_size)]
  path = os.path.join(root_path, "/".join(chunks))
  os.makedirs(path, exist_ok=True)
  return path

def media_tpl_to_path(tpl, chunk_size=7, root_path=MEDIA_DIR):
  media_id, url = tpl
  ext = os.path.splitext(urlparse(url).path)[1]
  path = id_to_path(media_id, chunk_size=chunk_size, root_path=root_path)
  return os.path.join(path, str(media_id) + ext)

# https://stackoverflow.com/a/312464
def chunks(lst, n):
  """Yield successive n-sized chunks from lst."""
  for i in range(0, len(lst), n):
      yield lst[i:i + n]

