#!/usr/bin/env python3

import os
import json
import sqlite3
import fileinput
import argparse
import time
import gzip
from urllib.parse import urlparse
from sqlite_utils import Database
from datetime import datetime
from dateutil.parser import parse as parse_datetime
from functools import reduce

RELATIONSHIP_TYPE = {
  'retweet': 1, 'quote': 2, 'reply': 3, 'mention': 4
}

def open_hook(filename, mode):
  ext = os.path.splitext(filename)[1]
  if ext == '.gz':
    return gzip.open(filename, 'rt', encoding='utf-8')
  else:
    return open(filename, 'rt', encoding='utf-8')

def append(records, tuple, chunk_size=100):
  if len(records) == 0 or len(records[-1]) == chunk_size:
    records.append([tuple])
  else:
    records[-1].append(tuple)

def ensure_tables(db):
  """
  While saving tweets in above functions automatically creates these tables,
  this function exists more so for documentation purposes.
  """
  table_names = set(db.table_names())

  if "tweets" not in table_names:
    db["tweets"].create({
      "id": int, # tweet id
      "user_id": int, 
      "user_name": str, 
      "created_at": datetime, # when tweet was tweeted
      "full_text": str, 
      "source": str, # how tweet got tweeted (mobile, web, etc.)
      "hashtags": str, # represented as a string, delim by space
      "media_count": int, # number of images attached to tweet (max 4)

      "quote_count": int,
      "reply_count": int,
      "retweet_count": int, 
      "favorite_count": int,

      # quote/retweets/replies
      "og_type": int, 
      "og_tweet_id": int, # id of original tweet
      "og_user_id": int,
      "og_user_name": str
    }, pk="id")

  # URLs + Media
  if "resources" not in table_names:
    db["resources"].create({ 
      "tweet_id": int, #tweet id
      "idx": int, # index into tweet's media/urls array
      "url": str, # url or media_url
      "media_id": int,
      "is_downloaded": bool, # have we downloaded the media
      "is_ocr": bool, # have we ocr'd the media
      "mark": str
    }, pk=("tweet_id", "idx", "media_id"))

  # Retweets, replies, and mentions
  if "relationships" not in table_names:
    db["relationships"].create({
      "tweet_id": int, 
      "user_id": int,
      "user_name": str, 
      
      # original tweet, nonexistent if mention
      "og_type": int, 
      "og_tweet_id": int,
      "og_user_id": int,
      "og_user_name": str
    }, pk=("tweet_id", "og_type", "og_tweet_id", "og_user_id"))

  #Users
  if "users" not in table_names:
    db["users"].create({
      "id": int,
      "user_name": str, 
      "name": str, 
      "description": str, # user bio
      "url": str, 
      "location": str,
      "created_at": datetime,
      "verified": bool,
      "friends_count": int,
      "followers_count": int,
      "favourites_count": int,
      "listed_count": int,
      "tweets_count": int
    }, pk="id")

def parse_hashtags(hashtags):
  """
  Takes hashtags and strings them together into one text body,
  delimited by spaces.
  - hashtags: list of hashtag dictionaries 
  - returns: string of hashtags
  """
  return " ".join([h["text"] for h in hashtags])

def parse_resources(entities, extended_entities, tweet_id, records=[]):
  """
  Saves urls from entities and media urls from extended_entities to database db
  for a particular tweet 
  - entities: dictionary of entities (hashtags, symbols, mentions, and urls)
  - extended_entities: dictionary of attached media (empty is tweet has no media)
  - tweet_id: specific int tweet ID
  """
  columns = [
    "tweet_id", "idx", "url", "media_id", "is_downloaded"
  ]

  for i, url in enumerate(entities.get("urls", [])):
    append(records, (tweet_id, i, url["expanded_url"], None, False))

  for i, pic in enumerate(extended_entities.get("media", [])):
    append(records, (tweet_id, i, pic["media_url"], pic["id"], False))

  return ("resources", columns, records)

def parse_user(user, records=[]):
  """
  Saves user information from a particular tweet of tweet_id to database db.
  - user: user dictionary from Tweet
  """
  append(records, (
    user["id"],
    user["screen_name"],
    user["name"],
    user["description"],
    user["url"],
    user["location"],
    user["created_at"],
    user["verified"],
    user["friends_count"],
    user["followers_count"],
    user["favourites_count"],
    user["listed_count"],
    user["statuses_count"],
  ))

  return ("users", [
    "id", "user_name", "name", "description",
    "url",  "location",  "created_at", "verified",
    "friends_count",  "followers_count",
    "favourites_count", "listed_count", "tweets_count",
  ], records)
  
def parse_mentions(mentions, tweet_id, user, records=[]):
  """
  - mentions: a list of mention dictionaries
  - tweet_id: int unique identifier for a tweet
  - user: author of tweet
  """
  columns = [
    "tweet_id", "user_id", "user_name", "og_type", 
    "og_tweet_id", "og_user_id", "og_user_name"
  ]

  for mention in mentions:
    append(records, (
      tweet_id, 
      user["id"], 
      user["screen_name"],
      RELATIONSHIP_TYPE['mention'], 
      -1, # mentions don't include an original tweet 
      mention["id"],
      mention["screen_name"], #username
    ))

  return ("relationships", columns, records)

def parse_tweets(input_tweets, input_json=True, 
  parsed_tweets=[], parsed_users=None, 
  parsed_resources=None, parsed_relationships=None,
  filterfn=None):
  """ Saves tweets from input_tweets to database db.
  - input_tweets: if input_json, input_tweets is a JSONL
  file of tweets (typically extracted from Twarc search queries).
  Otherwise, input_tweets is simply a list of tweet dictionaries.
  - input_json: Boolean to determine format of input_tweets
  """
  if input_json == True:
    print('Parsing', input_tweets)
    lines = fileinput.input(files=input_tweets, openhook=open_hook)
  else:
    lines = input_tweets

  columns = [
    "id", "user_id", "user_name", "created_at",
    "full_text", "source", "hashtags", "media_count", 
    "quote_count", "reply_count", "retweet_count",
    "favorite_count",
    "og_type", "og_tweet_id", "og_user_id", "og_user_name"
  ]

  insertions = []

  for line in lines:
    tweet = json.loads(line) if isinstance(line, str) else line
    tweet_id = tweet["id"]    
    user = tweet["user"]
    body = tweet.get("extended_tweet", tweet)
    entities = body["entities"]
    extended_entities = body.get("extended_entities", body["entities"])

    if filterfn is not None:
      if filterfn(tweet) == False:
        continue

    if tweet.get("lang", "en") != "en":
      continue

    p = parse_user(user, 
      records=(parsed_users[2] if parsed_users is not None else []))
    if parsed_users == None: parsed_users = p

    p = parse_resources(entities, extended_entities, tweet_id, 
      records=(parsed_resources[2] if parsed_resources is not None else []))
    if parsed_resources == None: parsed_resources = p

    p = parse_mentions(entities["user_mentions"], tweet_id, user, 
      records=(parsed_relationships[2] if parsed_relationships is not None else []))
    if parsed_relationships == None: parsed_relationships = p

    # retweets/quotes/replies
    if tweet.get("retweeted_status") or tweet.get("quoted_status") or tweet.get("in_reply_to_status_id"):
      og_type = RELATIONSHIP_TYPE['retweet'] if tweet.get("retweeted_status") else RELATIONSHIP_TYPE['quote'] if tweet.get("quoted_status") else RELATIONSHIP_TYPE['reply']
      og_tweet = tweet.get("retweeted_status") or tweet.get("quoted_status")
      og_tweet_id = tweet["in_reply_to_status_id"] or og_tweet["id"]
      og_user_id = tweet["in_reply_to_user_id"] or og_tweet["user"]["id"]
      og_user_name = tweet["in_reply_to_screen_name"] or og_tweet["user"]["screen_name"]

      rel_tpl = (tweet_id, user["id"], user["screen_name"],
          og_type, og_tweet_id, og_user_id, og_user_name)
      if parsed_relationships == None:
        parsed_relationships = ("relationships", [
          "tweet_id", "user_id", "user_name", "og_type",
          "og_tweet_id", "og_user_id", "og_user_name"
        ], [[rel_tpl]])
      else: 
        append(parsed_relationships[2], rel_tpl)

      if og_tweet:
        parse_tweets([og_tweet,], input_json=False, 
          parsed_tweets=parsed_tweets, parsed_users=parsed_users,
          parsed_resources=parsed_resources, parsed_relationships=parsed_relationships)

    # everything else
    append(parsed_tweets, (
      tweet_id,
      user["id"],
      user["screen_name"],
      parse_datetime(tweet['created_at']),
      body.get("full_text", body.get("text", tweet.get("full_text", tweet.get("text")))),
      tweet["source"], # flag 
      parse_hashtags(entities.get("hashtags", [])),
      len(extended_entities.get("media", [])),

      tweet.get("quote_count"),
      tweet.get("reply_count"),
      tweet["retweet_count"],
      tweet["favorite_count"],
        
      og_type if "og_type" in locals() else None,    
      og_tweet_id if "og_tweet_id" in locals() else None,    
      og_user_id if "og_user_id" in locals() else None,    
      og_user_name if "og_user_name" in locals() else None,    
    ))

  insertions.append(("tweets", columns, parsed_tweets))
  if parsed_users is not None: insertions.append(parsed_users)
  if parsed_resources is not None: insertions.append(parsed_resources)
  if parsed_relationships is not None: insertions.append(parsed_relationships)

  return insertions

def insert_all(db, table, columns, chunks):
  query = "INSERT OR IGNORE INTO {table}({columns}) VALUES({places})".format(
    table=table, 
    columns=", ".join(columns), 
    places=",".join(["?" for c in columns]))

  for chunk in chunks:
    db.conn.executemany(query, chunk)

  db.conn.commit() 

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('files', help='JSONL files containing tweets', nargs='*')
  parser.add_argument('--db', help='Database file', default='test.db')

  args = parser.parse_args()

  start = time.perf_counter()
  conn = sqlite3.connect(args.db, isolation_level=None)
  c = conn.cursor()
  c.execute('PRAGMA synchronous = OFF')
  c.execute('PRAGMA journal_mode = OFF')
  db = Database(conn)
  ensure_tables(db)
  print("Connect + Create\t", time.perf_counter() - start, '\n')

  start = time.perf_counter()
  json_files = args.files if len(args.files) > 0 else ('-',)
  insertions = parse_tweets(json_files)
  print("Parse\t", time.perf_counter() - start)

  start = time.perf_counter()

  for table, columns, chunks in insertions:
    if len(chunks) == 0: 
      continue
    insert_all(db, table, columns, chunks)

    count = reduce(lambda a, b: a + b, [len(x) for x in chunks])
    print('\tInserted {} into {}: {}'.format(count, table, time.perf_counter() - start))

  print("\nInserted All\t", time.perf_counter() - start)

