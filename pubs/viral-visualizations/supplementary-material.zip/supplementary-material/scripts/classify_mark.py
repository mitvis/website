#!/usr/bin/env python3

import sqlite3
import argparse
import skimage
import numpy as np
import multiprocessing as mp
import caffe
import gzip
from functools import partial

from utils import media_tpl_to_path, chunks

model = {
  'path': 'models/mark_classifier/charts5cats/',
  'model_file': 'deploy.prototxt',
  'weights_file': 'snapshots/model_iter_50000.caffemodel',
  'mean_file': 'ilsvrc_2012_mean.npy',
  'categories_file': 'categories.txt'
}

net = None
categories = None

def init():
  global net, categories

  net = caffe.Classifier(
    model_file=(model['path'] + model['model_file']),
    pretrained_file=(model['path'] + model['weights_file']),
    mean=np.load(model['path'] + model['mean_file']).mean(1).mean(1),
    channel_swap=(2, 1, 0),
    raw_scale=255
  )

  categories = np.genfromtxt(model['path'] + model['categories_file'], 
                              dtype=None, encoding=None)

# Correct as_grey -> as_gray bug in pycaffe
def load_image(filename, color=True):
    """
    Load an image converting from grayscale or alpha as needed.
    Parameters
    ----------
    filename : string
    color : boolean
        flag for color format. True (default) loads as RGB while False
        loads as intensity (if image is already grayscale).
    Returns
    -------
    image : an image with type np.float32 in range [0, 1]
        of size (H x W x 3) in RGB or
        of size (H x W x 1) in grayscale.
    """
    img = skimage.img_as_float(skimage.io.imread(filename, as_gray=not color)).astype(np.float32)
    if img.ndim == 2:
        img = img[:, :, np.newaxis]
        if color:
            img = np.tile(img, (1, 1, 3))
    elif img.shape[2] == 4:
        img = img[:, :, :3]
    return img

def classify(charts):
  media_ids = []
  inputs = []

  for media_id, filename in charts:
    try:
      chart = load_image(filename)
      inputs.append(chart)
      media_ids.append(media_id)
    except:
      print('\tCouldn\'t load file', media_id, filename)
      continue

  ############################
  # Copied from pycaffe classifier.py because we also want fc7 output

  # Scale to standardize input dimensions.
  input_ = np.zeros((len(inputs),
                      net.image_dims[0],
                      net.image_dims[1],
                      inputs[0].shape[2]),
                    dtype=np.float32)

  for ix, in_ in enumerate(inputs):
      input_[ix] = caffe.io.resize_image(in_, net.image_dims)

  # Generate center, corner, and mirrored crops.
  input_ = caffe.io.oversample(input_, net.crop_dims)

  # Classify
  caffe_in = np.zeros(np.array(input_.shape)[[0, 3, 1, 2]],
                      dtype=np.float32)
  for ix, in_ in enumerate(input_):
      caffe_in[ix] = net.transformer.preprocess(net.inputs[0], in_)
  
  out = net.forward_all(**{net.inputs[0]: caffe_in, 'blobs': ['fc7', 'prob']})
  
  # End pycaffe classifier.py
  ############################

  predictions = out['prob']
  predictions = predictions.reshape((len(predictions) // 10, 10, -1))
  predictions = predictions.mean(1).argmax(1)
  predictions = categories[predictions]

  fc7 = out['fc7']
  fc7 = fc7.reshape((len(fc7) // 10, 10, -1))
  fc7 = fc7.mean(1)

  for i, chart_embedding in enumerate(fc7):
    filename = charts[i][1].replace('.jpg', '.npy.gz').replace('.png', '.npy.gz')
    with gzip.open(filename, 'wb') as f:
      np.save(f, chart_embedding)

  return list(zip(list(predictions), media_ids))

if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument('db', help='Database containing tweets')
  args = parser.parse_args()

  conn = sqlite3.connect(args.db)
  c = conn.cursor()
  c.execute('''select distinct media_id, url from resources 
              where is_downloaded = 1 and mark is null
              order by media_id''')
  
  rows = c.fetchall()
  result_chunks = chunks([(_[0], media_tpl_to_path(_)) for _ in rows], 70)
  
  done = 0
  pool = mp.Pool(mp.cpu_count(), init)
  for results in pool.imap_unordered(classify, result_chunks):
    c.executemany('update resources set mark = ? where media_id = ?', results)
    conn.commit()
    print('Processed {}: {}-{}'.format(len(results), results[0], results[-1]))
    done += len(results)
    print('\tRemaining: ', len(rows) - done)

  pool.close()
  conn.close()

  
