#!/usr/bin/env python3
"""
Given a JSON file, downloads any media_urls in referenced tweets.
"""

import os
import json
import fileinput
import argparse
import requests
import sqlite3
from random import randint
from time import perf_counter, sleep
import multiprocessing as mp
from urllib.parse import urlparse
from utils import id_to_path, media_tpl_to_path

# your directory here
MEDIA_DIR = '/data/visualization'

def files(json_files, media_dir=MEDIA_DIR):
  for line in fileinput.input(files=json_files):
    tweet = json.loads(line)
    # extended_entities includes all images
    # https://developer.twitter.com/en/docs/twitter-api/v1/data-dictionary/object-model/extended-entities#extended-entities-object
    media = tweet.get('extended_entities', tweet['media']).get('media', []) 

    for m in media:
      get_media((m['id'], m['media_url']))

def database(name, media_dir=MEDIA_DIR):
  conn = sqlite3.connect(name)
  c = conn.cursor()
  c.execute('''select distinct media_id, url from resources 
              where media_id is not null and is_downloaded = 0 
              order by media_id''')
  results = c.fetchall()

  pool = mp.Pool(4)
  updates = []
  for media_id in pool.imap_unordered(get_media, results):
    updates.append((media_id,))

    if len(updates) == 10:
      c.executemany('''update resources set is_downloaded = 1
                       where media_id = ?''', updates)
      conn.commit()
      updates.clear()

  conn.commit()
  pool.close()
  conn.close()

def get_media(tpl, media_dir=MEDIA_DIR):
  media_id, url = tpl
  outfile = media_tpl_to_path(tpl)

  if not os.path.isfile(outfile):
    print('Downloading', url, outfile)
    response = requests.get(url, stream=True)
    with open(outfile, 'wb') as f:
      for chunk in response.iter_content(chunk_size=1024):
        if chunk:  # filter out keep-alive new chunks
          f.write(chunk)
          f.flush()
    
    sleep(randint(3, 5))

  return media_id

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', help='Directory to store media', default=MEDIA_DIR)
    parser.add_argument('input', help='JSONL files or database containing tweets')
    args = parser.parse_args()

    print(args)

    if '.db' in args.input:
      database(args.input, media_dir=args.d)
    else:
      json_files = args.input if len(args.input) > 0 else ('-',)
      files(json_files, media_dir=args.d)
