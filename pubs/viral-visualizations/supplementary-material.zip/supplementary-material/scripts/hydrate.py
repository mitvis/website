#!/usr/bin/env python3

#####
# This script will walk through all the tweet id files and
# hydrate them with twarc. The line oriented JSON files will
# be placed right next to each tweet id file.
#
# Note: you will need to install twarc, tqdm, and run twarc configure
# from the command line to tell it your Twitter API keys.
#####

import gzip
import json
import argparse

from tqdm import tqdm
from twarc import Twarc
from pathlib import Path
from itertools import cycle

twitter_profiles = []
data_dirs = ['2020-03', '2020-04', '2020-05', '2020-06', '2020-07']
output_path = '/data/visualization'

def main(profile):
  files = []
  for data_dir in data_dirs:
    for path in Path(data_dir).iterdir():
        if path.name.endswith('.txt'):
          files.append(path)

  zipped = list(zip(cycle(twitter_profiles), files))
  tasks = [z for z in zipped if z[0] == profile]
  hydrate(tasks)

def _reader_generator(reader):
  b = reader(1024 * 1024)
  while b:
    yield b
    b = reader(1024 * 1024)


def raw_newline_count(fname):
  """
  Counts number of lines in file
  """
  f = open(fname, 'rb')
  f_gen = _reader_generator(f.raw.read)
  return sum(buf.count(b'\n') for buf in f_gen)


def hydrate(tasks):
  for twitter_profile, id_file in tasks:
    print('hydrating {} with account {}'.format(id_file, twitter_profile))

    gzip_path = Path(output_path + str(id_file.with_suffix('.jsonl.gz')))
    if gzip_path.is_file():
      print('skipping json file already exists: {}'.format(gzip_path))
      continue

    twarc = Twarc(profile=twitter_profile)
    num_ids = raw_newline_count(id_file)

    with gzip.open(gzip_path, 'w') as output:
      with tqdm(total=num_ids) as pbar:
        for tweet in twarc.hydrate(id_file.open()):
          output.write(json.dumps(tweet).encode('utf8') + b"\n")
          pbar.update(1)


if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument('twitter_profile', help='Which twitter profile to run')

  args = parser.parse_args()
  main(args.twitter_profile)
