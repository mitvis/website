#!/usr/bin/env python3

import sqlite3
import argparse
import multiprocessing as mp
from pathlib import Path
from glob import glob
from functools import partial
from sqlite_utils import Database
from time import perf_counter
from functools import reduce
import re

import db_utils

DATA_DIR = '/data/visualization'

KEYWORDS = re.compile(r'\b({})\b'.format(
  '|'.join(['chart', 'charts', 'plot', 'plots',
            'map', 'maps', 'dashboard', 'dashboards',
            'vis', 'viz', 'visualization', 'visualizations']), 
))

MEDIA_WORDS = re.compile(r'\b({})\w*'.format('|'.join([
  'bar', 'line', 'trend', 'exponent', 'grow', 'peak',
  'data', 'number', 'case', 'death', 'rate'
])))

def filterfn(tweet): 
  full_text = tweet['full_text']
  media_count = len(tweet.get('extended_entities', {}).get('media', []))

  if KEYWORDS.search(full_text) is not None:
    return True
  # elif MEDIA_WORDS.search(full_text) is not None and media_count > 0:
  #   return True

  return False

if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('path', help='Path(s) containing .txt files', nargs='*')
  parser.add_argument('--db', help='Database file', default='test.db')

  args = parser.parse_args()

  start = perf_counter()
  conn = sqlite3.connect(args.db, isolation_level=None)
  c = conn.cursor()
  c.execute('''PRAGMA synchronous = OFF''')
  c.execute('''PRAGMA journal_mode = OFF''')
  db = Database(conn)
  db_utils.ensure_tables(db)
  print('Connect + Create: \t', perf_counter() - start, '\n')

  print(args)
  files = [DATA_DIR + str(Path(f).with_suffix('.jsonl.gz')) for p in args.path for f in glob(p + '/*.txt')]
  pool = mp.Pool(mp.cpu_count())
  func = partial(db_utils.parse_tweets, filterfn=filterfn)

  start0 = perf_counter()
  for insertions in pool.imap_unordered(func, files):
    for table, columns, chunks in insertions:
      if len(chunks) == 0:
        continue

      start1 = perf_counter()
      db_utils.insert_all(db, table, columns, chunks)
      count = reduce(lambda a, b: a + b, [len(x) for x in chunks])
      print('\tInserted {} into {}: {}'.format(count, table, perf_counter() - start1))

  pool.close()
  conn.close()
  print('\nInserted All {}: {}'.format(args.path, perf_counter() - start))



  

