#!/usr/bin/env python3

import pytesseract
import numpy as np
from functools import partial
from pytesseract import Output
import cv2
import os
import glob
import csv
import fileinput
import argparse
import multiprocessing as mp
from sqlite_utils import Database
from utils import id_to_path

MEDIA_DIR = '/data/visualization'

SKIP_RECOMPUTE = True
BLUR_F = 2
SCALE_F = 2.5
CONFIDENCE_THRESHOLD=75

def resize(img, scale):
  return cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

def grayscale(img):
  return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
 
def thresholding(img):
  w, h = img.shape[:2]
  thresh = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
  return thresh if cv2.countNonZero(thresh) > ((w*h)//2) else cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

def adaptive_thresholding(img):
  return cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)

def denoise(img):
  return cv2.fastNlMeansDenoising(img, None, 30, 7, 21)

def blur(img, f):
  return cv2.blur(img, (f, f))

def ocr(media_id, confidence_threshold=CONFIDENCE_THRESHOLD, 
        blur_f=BLUR_F, scale_f=SCALE_F, debug=False):
 
  if isinstance(media_id, str):
    file = media_id
  else:
    media_id = media_id[0]
    path = id_to_path(media_id, root_path=MEDIA_DIR)
    file = os.path.join(path, str(media_id) + '.jpg')
    if not os.path.isfile(file):
      file = os.path.join(path, str(media_id) + '.png')
      if not os.path.isfile(file):
        print('Cannot find file', media_id)
        return (media_id, [])

  img = cv2.imread(file)
  if img is None or img.size == 0:
    print('Corrupt', file)
    return (file, [])

  print('Processing', file)
  preprocessed = blur(thresholding(grayscale(resize(img, scale_f))), blur_f)
  config = '--psm 1 -c tessedit_write_images=1 -c enable_new_segsearch=1 -c language_model_penalty_non_freq_dict_word=1 -c language_model_penalty_non_dict_word=1'

  d = pytesseract.image_to_data(preprocessed, output_type=Output.DICT, config=config)
  rows = []
  for i in range(len(d['level'])):
    if d['text'][i].strip() == "" or int(d['conf'][i]) < confidence_threshold:
      continue
    
    row = (i, x, y, w, h, *_) = (i, d['left'][i], d['top'][i], d['width'][i], d['height'][i], d['text'][i], '', d['conf'][i])        
    
    # Sentence assembly: check current word w/prev word. 
    # If tesseract reports they're part of the same page, block, paragraph, and line,
    # check the pixel spacing between them to ensure they are
    # part of the same sentence (and not just along the same-ish x-position).
    # If they are part of the same sentence, expand the prev bounding box, and append text.
    # Otherwise, treat as a new sentence.
    id_fields = ['page_num', 'block_num', 'par_num', 'line_num']
    if i == 0 or len(rows) == 0 or any([d[f][i] != d[f][rows[-1][0]] for f in id_fields]):
      rows.append(list(row))
    else:
      prev = rows[-1]
      if prev[4] == 0:
        rows.append(list(row))
      else:
        horizontal = prev[3] / prev[4] >= 1
        interword_space = prev[4] * 2/3 if horizontal else prev[3] * 2/3

        if horizontal and d['left'][i] <= (prev[1] + prev[3] + interword_space): 
          prev[3] = d['left'][i] + d['width'][i] - prev[1]  # Expand the width
          prev[2] = min(prev[2], d['top'][i])               # Use top-most y-coordinate
          prev[4] = max(prev[4], d['height'][i])            # Use max height of any word
          prev[5] += " " + d['text'][i]                     # Append word to sentence
        elif not horizontal and (d['top'][i] + d['height'][i] + interword_space) >= prev[2]:
          prev[4] = prev[2] + prev[4] - d['top'][i]         # Expand the height
          prev[2] = d['top'][i]                             # Start sentence at top-most word
          prev[1] = min(prev[1], d['left'][i])              # Use the left-most x-coordinate
          prev[3] = max(prev[3], d['width'][i])             # Use max width of any word
          prev[5] += " " + d['text'][i]                     # Append word to sentence
        else:
          rows.append(list(row))

  if debug == True:
    dirname = os.path.dirname(file)
    filename, ext = os.path.splitext(os.path.basename(file))
    csvname = dirname + '-bb-csv/' + filename + '-texts.csv'

    with open(dirname + '-text/' + filename + '.txt', 'w') as outfile:
      outfile.write(pytesseract.image_to_string(preprocessed, config=config))

    with open(csvname, 'w', encoding='utf-8', newline='') as outfile:
      outfile.write("id,x,y,width,height,text,type,confidence\n")
      writer = csv.writer(outfile) 
      for row in rows:
        i, x, y, w, h, *_ = row
        cv2.rectangle(preprocessed, (x, y), (x + w, y + h), (0, 255, 0), 2)    
        writer.writerow(row)

    cv2.imwrite(dirname + '-bb/' + filename + ext, preprocessed)

  return (media_id, rows)

def files(args, func):
  path = os.getcwd() + '/' + args.input
  cpu  = mp.cpu_count()
  print(path, cpu)

  files = [path] if os.path.isfile(path) else glob.glob(path + "*.jpg") + glob.glob(path + "*.png")

  pool = mp.Pool(cpu)
  pool.map(func, files)

def database(args, func):
  db = Database(args.input)
  if 'ocr' not in db.table_names():
    db['ocr'].create({
      'media_id': int,
      'id': int,
      'x': float,
      'y': float,
      'width': float,
      'height': float,
      'text': str,
      'type': str,
      'conf': int
    }, pk=('media_id', 'id'))

  cols = list(db['ocr'].columns_dict.keys())
  c = db.conn.cursor()
  c.execute('''select distinct media_id from resources
                where media_id is not null and is_downloaded != 0
                and is_ocr is null order by media_id''')
  media_ids = c.fetchall()

  with mp.Pool(mp.cpu_count()) as pool:
    for media_id, rows in pool.imap_unordered(func, media_ids):
      print('Inserting', media_id, len(rows))
      rows = [(media_id, *_) for _ in rows]
      query = 'insert into ocr({cols}) values({places})'.format(
        cols=', '.join(cols),
        places=', '.join(['?' for c in cols])
      )

      c.executemany(query, rows)
      c.execute('update resources set is_ocr = 1 where media_id = ?', (media_id,))
      db.conn.commit()

if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument('-b', '--blur', help='The blur factor', type=int, default=BLUR_F)
  parser.add_argument('-s', '--scale', help='The scale factor', type=float, default=SCALE_F)
  parser.add_argument('-c', '--confidence', help='The confidence threshold', type=int, default=CONFIDENCE_THRESHOLD)
  parser.add_argument('-d', '--debug', action="store_true")
  parser.add_argument('input', help='Single image file, directory containing only image files, or database containing tweets')

  args = parser.parse_args()
  func = partial(ocr, confidence_threshold=args.confidence, 
                  blur_f=args.blur, scale_f=args.scale, 
                  debug=args.debug)

  print(args)
  if '.db' in args.input:
    database(args, func)
  else:
    files(args, func)
