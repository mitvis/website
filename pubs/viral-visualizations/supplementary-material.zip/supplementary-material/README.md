This repository contains the supplementary material for the quantitative analysis conducted in "Viral Visualizations: How Coronavirus Skeptics Use Orthodox Data Practices to Promote Unorthodox Science", a paper published at ACM CHI 2021.  

## Contents

1. tweetIDs.txt — a list of tweets that comprise the analyzed corpus, which can be rehydrated using the [twarc](https://github.com/DocNow/twarc) library by executing the command `twarc hydrate tweetIDs.txt > tweets.jsonl`.
2. scripts/ — a folder which contains the necessary scripts to build a SQLite database from the JSONL files (`import.py`), run the [Poco & Heer mark classification model](https://github.com/uwdata/rev) (`classify_mark.py`), and perform optical character recognition on images in the corpus (`ocr.py`).
3. notebooks/ — a folder containing two Jupyter notebooks that correspond to the two parts of the paper's quantitative analysis. `vis_cluster.ipynb` uses feature embeddings extracted with `scripts/classify_mark.py`, and clusters and visualizes them using k-means and UMAP. `network_analysis.ipynb` constructs a network graph of users participating in conversations, and outputs a `graphml` file for subsequent analysis using Gephi, or other similar graph analysis tools. 
