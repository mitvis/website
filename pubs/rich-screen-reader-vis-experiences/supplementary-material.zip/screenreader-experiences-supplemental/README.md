# Folder structure of supplementary material

- ./evaluation-plan.pdf - user study design
- ./preliminary-sketches - early sketches and design iteration
- ./protoypes - high fidelity prototypes, as described in Section 4 and 5
- ./videos - recordings of a screen reader user demonstrating the multi-view and targeted prototypes, and short clips of the chloropleth, stacked bar, and binary tree prototypes.

# To view prototypes

1. `cd` into folder e.g. `./prototypes/multiview`
2. start a web server in this directory e.g. `python3 -m http.server`
3. navigate to address of server e.g. `http://localhost:8000`

# Key bindings
- Multiview, targeted navigation, chloropleth, and stacked bar: Arrow Keys to navigate up/down the structure.
- Multiview, targeted navigation: when in the "grid" section of the tree, WASD to navigate spatially in the grid
- Multiview only: shift+left and shift+right to laterally move to the same position in the adjacent facet
- Targeted navigation only: R to open the targeted navigation dropdown menus. Esc to close these menus.
- Annotation and binary tree: WASD to navigate up/down and left/right in the structure

# Optional: Spoken text descriptions

To hear text descriptions read out as speech, use the prototypes with a screen reader (instructions below). The text will be the same as the text displayed on the page.

## Screen readers

MacOS has a built in screen reader called VoiceOver.

Apple's VoiceOver guide: https://www.apple.com/voiceover/info/guide/_1121.html

To use the prototypes with VoiceOver, ensure Quick Nav is off. To toggle Quick Nav, press left and right arrow keys at the same time.

Windows has a built in screen reader called Narrator.

To use the prototypes with Narrator, ensure Scan Mode is off. To toggle Scan Mode, press Caps Lock and Spacebar at the same time.

Microsoft's Narrator guide: https://support.microsoft.com/en-us/windows/complete-guide-to-narrator-e4397a0d-ef4f-b386-d8ae-c172f109bdb1
